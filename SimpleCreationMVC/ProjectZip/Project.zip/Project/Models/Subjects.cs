
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Subjects
     {
		[Key]
		public int? Id {get;set;}
		public string? SubjectName {get;set;}
		public DateTime CreatedAt {get;set;}
		public bool IsDeleted {get;set;}

     }
}
