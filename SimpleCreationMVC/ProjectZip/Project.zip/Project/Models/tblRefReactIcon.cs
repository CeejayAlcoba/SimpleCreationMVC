
using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class tblRefReactIcon
    {
		[Key]
		public int? Id {get;set;}
		public int? ReactIconFamilyId {get;set;}
		public string? Description {get;set;}
		public bool? IsDeleted {get;set;}

    }
}
