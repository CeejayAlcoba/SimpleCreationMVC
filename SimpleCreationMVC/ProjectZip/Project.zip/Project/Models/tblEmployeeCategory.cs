
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblEmployeeCategory
     {
		[Key]
		public int? Id {get;set;}
		public int? EmployeeId {get;set;}
		public int? CategoryTypeId {get;set;}
		public int? DepartmentId {get;set;}

     }
}
