
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Attendances
     {
		[Key]
		public int? Id {get;set;}
		public int StudentId {get;set;}
		public int ClassId {get;set;}
		public DateTime AttendanceDate {get;set;}
		public int? ClassId1 {get;set;}
		public DateTime CreatedAt {get;set;}
		public bool IsDeleted {get;set;}

     }
}
