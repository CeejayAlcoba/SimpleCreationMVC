
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblPayrollAccountNumber
     {
		[Key]
		public int? Id {get;set;}
		public int? EmployeeId {get;set;}
		public string? AccountNumber {get;set;}

     }
}
