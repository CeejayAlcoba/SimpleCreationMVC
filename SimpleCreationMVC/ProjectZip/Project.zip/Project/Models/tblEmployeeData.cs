
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblEmployeeData
     {
		[Key]
		public int? Id {get;set;}
		public string? LastName {get;set;}
		public string? FirstName {get;set;}
		public string? MiddleName {get;set;}
		public int? GenderId {get;set;}
		public int? CivilStatusId {get;set;}
		public int? ReligionId {get;set;}
		public string? PlaceOfBirth {get;set;}
		public string? NationalIdNumber {get;set;}
		public string? SSSNumber {get;set;}
		public string? HDMFNumber {get;set;}
		public string? PHICNumber {get;set;}
		public string? TIN {get;set;}
		public string? HMOCardNumber {get;set;}
		public string? HMOAccountNumber {get;set;}
		public bool? IsDeleted {get;set;}
		public DateTime? BirthDate {get;set;}
		public DateTime? DateHired {get;set;}

     }
}
