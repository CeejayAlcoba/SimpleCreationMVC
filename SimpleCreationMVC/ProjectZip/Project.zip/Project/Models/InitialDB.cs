
using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class InitialDB
    {
		[Key]
		public int? Id {get;set;}

    }
}
