
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblPromotionHistoryLog
     {
		[Key]
		public int? Id {get;set;}
		public int? EmployeeId {get;set;}
		public int? PositionId {get;set;}
		public int? DepartmentId {get;set;}
		public string? AlternativePosition {get;set;}
		public DateTime? PromotedDate {get;set;}

     }
}
