
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblRefProvince
     {
		[Key]
		public int? Id {get;set;}
		public string? Description {get;set;}
		public bool? IsDeleted {get;set;}
		public int? CountryId {get;set;}

     }
}
