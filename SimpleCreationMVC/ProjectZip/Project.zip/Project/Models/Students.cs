
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Students
     {
		[Key]
		public int? Id {get;set;}
		public string? FirstName {get;set;}
		public string? LastName {get;set;}
		public string? Gender {get;set;}
		public int? SubjectId {get;set;}
		public DateTime? CreatedAt {get;set;}
		public bool? IsDeleted {get;set;}

     }
}
