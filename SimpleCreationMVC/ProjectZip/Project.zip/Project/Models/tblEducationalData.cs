
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblEducationalData
     {
		[Key]
		public int? Id {get;set;}
		public int? EmployeeId {get;set;}
		public int? EducationalLevelId {get;set;}
		public string? School {get;set;}
		public string? YearGraduate {get;set;}
		public bool? IsDeleted {get;set;}
		public int? ApplicantId {get;set;}

     }
}
