
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblRefPresentAddress
     {
		[Key]
		public int? Id {get;set;}
		public int? EmployeeId {get;set;}
		public int? BarangayId {get;set;}
		public int? MunicipalityId {get;set;}
		public int? ProvinceId {get;set;}
		public int? CountryId {get;set;}
		public int? ZIPCodeId {get;set;}
		public bool? IsDeleted {get;set;}

     }
}
