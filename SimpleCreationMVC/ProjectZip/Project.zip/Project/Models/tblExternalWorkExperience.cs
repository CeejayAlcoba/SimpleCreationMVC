
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblExternalWorkExperience
     {
		[Key]
		public int? Id {get;set;}
		public string? Position {get;set;}
		public string? Employer {get;set;}
		public string? LengthOfService {get;set;}
		public string? ReasonOfLeaving {get;set;}
		public int? EmployeeId {get;set;}
		public bool? IsDeleted {get;set;}
		public int? ApplicantId {get;set;}

     }
}
