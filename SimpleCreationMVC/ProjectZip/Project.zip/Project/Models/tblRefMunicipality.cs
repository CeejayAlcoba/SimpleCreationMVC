
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblRefMunicipality
     {
		[Key]
		public int? Id {get;set;}
		public string? Description {get;set;}
		public bool? IsDeleted {get;set;}
		public int? ProvinceId {get;set;}

     }
}
