
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblInternalWorkExperience
     {
		[Key]
		public int? Id {get;set;}
		public string? Position {get;set;}
		public string? Department {get;set;}
		public DateTime? EffectivityDate {get;set;}
		public int? InternalCompanyId {get;set;}
		public int? JobLevelId {get;set;}
		public int? AppointmentId {get;set;}
		public int? EmployeeId {get;set;}
		public bool? IsDeleted {get;set;}
		public int? ApplicantId {get;set;}

     }
}
