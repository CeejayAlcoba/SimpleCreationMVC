
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Classes
     {
		[Key]
		public int? Id {get;set;}
		public int? SubjectId {get;set;}
		public DateTime? ClassDate {get;set;}
		public TimeSpan? StartTime {get;set;}
		public TimeSpan? EndTime {get;set;}
		public DateTime? CreatedAt {get;set;}
		public bool? IsDeleted {get;set;}

     }
}
