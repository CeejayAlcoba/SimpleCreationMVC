
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblEmployeeTimeInOut
     {
		[Key]
		public int? Id {get;set;}
		public int? EmployeeId {get;set;}
		public DateTime? Date {get;set;}
		public TimeSpan? CheckIn {get;set;}
		public TimeSpan? CheckOut {get;set;}
		public string? EmployeeNumber {get;set;}
		public int? DepartmentId {get;set;}
		public string? Department {get;set;}
		public int? UploadedBy {get;set;}
		public DateTime? UploadedDate {get;set;}
		public string? Note {get;set;}

     }
}
