
using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class tblRefReactIconFamily
    {
		[Key]
		public int? Id {get;set;}
		public string? Description {get;set;}
		public bool? IsDeleted {get;set;}

    }
}
