
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblRefChildren
     {
		[Key]
		public int? Id {get;set;}
		public int? FamilyId {get;set;}
		public string? Name {get;set;}
		public int? GradeLevelId {get;set;}
		public bool? IsDeleted {get;set;}
		public DateTime? Birthday {get;set;}

     }
}
