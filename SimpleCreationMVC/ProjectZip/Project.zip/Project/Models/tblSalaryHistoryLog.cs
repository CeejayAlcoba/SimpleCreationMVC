
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblSalaryHistoryLog
     {
		[Key]
		public int? Id {get;set;}
		public double? Amount {get;set;}
		public int? EmployeeId {get;set;}
		public int? SalaryTypeId {get;set;}
		public DateTime? Date {get;set;}
		public bool? IsDeleted {get;set;}
		public DateTime? CreatedDate {get;set;}
		public int? SalaryId {get;set;}

     }
}
