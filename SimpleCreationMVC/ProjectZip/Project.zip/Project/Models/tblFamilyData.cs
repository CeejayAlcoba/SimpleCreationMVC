
using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class tblFamilyData
     {
		[Key]
		public int? Id {get;set;}
		public int? EmployeeId {get;set;}
		public string? MotherMaidenName {get;set;}
		public string? FatherName {get;set;}
		public bool? IsDeleted {get;set;}
		public int? ApplicantId {get;set;}

     }
}
