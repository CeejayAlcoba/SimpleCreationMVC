
namespace Project.ProcedureEnums
{
    // Procedures for the tblEmployeeCorporateDataHistoryLog table
    public enum tblEmployeeCorporateDataHistoryLogProcedures
    {

        tblEmployeeCorporateDataHistoryLog_DeleteById,
        tblEmployeeCorporateDataHistoryLog_GetByEmployeeCorporateDataUniqueId,
        tblEmployeeCorporateDataHistoryLog_GetByEmployeeId,
        tblEmployeeCorporateDataHistoryLog_GetById,
        tblEmployeeCorporateDataHistoryLog_Insert,
        tblEmployeeCorporateDataHistoryLog_Update,

    }
}
