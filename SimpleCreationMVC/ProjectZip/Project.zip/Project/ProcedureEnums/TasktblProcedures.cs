
namespace Project.ProcedureEnums
{
    // Procedures for the Tasktbl table
    public enum TasktblProcedures
    {

        Tasktbl_BulkInsert,
        Tasktbl_BulkMerge,
        Tasktbl_BulkUpdate,
        Tasktbl_BulkUpsert,
        Tasktbl_DeleteById,
        Tasktbl_GetAll,
        Tasktbl_GetById,
        Tasktbl_Insert,
        Tasktbl_Update,

    }
}
