
namespace Project.ProcedureEnums
{
    // Procedures for the Subjects table
    public enum SubjectsProcedures
    {

        Subjects_DeleteById,
        Subjects_GetAll,
        Subjects_GetById,
        Subjects_Insert,
        Subjects_Update,

    }
}
