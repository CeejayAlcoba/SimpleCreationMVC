
namespace Project.ProcedureEnums
{
    // Procedures for the tblEmployeeCorporateData table
    public enum tblEmployeeCorporateDataProcedures
    {

        tblEmployeeCorporateData_DeleteByEmployeeId,
        tblEmployeeCorporateData_DeleteById,
        tblEmployeeCorporateData_GetAll,
        tblEmployeeCorporateData_GetByEmployeeId,
        tblEmployeeCorporateData_GetById,
        tblEmployeeCorporateData_Insert,
        tblEmployeeCorporateData_Update,
        tblEmployeeCorporateDataHistoryLog_DeleteById,
        tblEmployeeCorporateDataHistoryLog_GetByEmployeeCorporateDataUniqueId,
        tblEmployeeCorporateDataHistoryLog_GetByEmployeeId,
        tblEmployeeCorporateDataHistoryLog_GetById,
        tblEmployeeCorporateDataHistoryLog_Insert,
        tblEmployeeCorporateDataHistoryLog_Update,

    }
}
