
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefInternalCompany table
    public enum tblRefInternalCompanyProcedures
    {

        tblRefInternalCompany_DeleteById,
        tblRefInternalCompany_GetAll,
        tblRefInternalCompany_GetById,
        tblRefInternalCompany_Insert,
        tblRefInternalCompany_Update,

    }
}
