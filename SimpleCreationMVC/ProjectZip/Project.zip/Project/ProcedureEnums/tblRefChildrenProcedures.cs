
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefChildren table
    public enum tblRefChildrenProcedures
    {

        tblRefChildren_DeleteById,
        tblRefChildren_GetAll,
        tblRefChildren_GetByFamilyId,
        tblRefChildren_GetById,
        tblRefChildren_Insert,
        tblRefChildren_Update,

    }
}
