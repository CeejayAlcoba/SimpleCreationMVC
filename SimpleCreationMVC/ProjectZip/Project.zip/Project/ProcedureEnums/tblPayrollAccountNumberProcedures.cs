
namespace Project.ProcedureEnums
{
    // Procedures for the tblPayrollAccountNumber table
    public enum tblPayrollAccountNumberProcedures
    {

        tblPayrollAccountNumber_DeleteById,
        tblPayrollAccountNumber_GetAll,
        tblPayrollAccountNumber_GetById,
        tblPayrollAccountNumber_Insert,
        tblPayrollAccountNumber_Update,

    }
}
