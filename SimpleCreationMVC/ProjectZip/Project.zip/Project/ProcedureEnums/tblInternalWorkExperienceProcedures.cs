
namespace Project.ProcedureEnums
{
    // Procedures for the tblInternalWorkExperience table
    public enum tblInternalWorkExperienceProcedures
    {

        tblInternalWorkExperience_DeleteById,
        tblInternalWorkExperience_GetAll,
        tblInternalWorkExperience_GetByApplicantId,
        tblInternalWorkExperience_GetByEmployeeId,
        tblInternalWorkExperience_GetById,
        tblInternalWorkExperience_Insert,
        tblInternalWorkExperience_Update,

    }
}
