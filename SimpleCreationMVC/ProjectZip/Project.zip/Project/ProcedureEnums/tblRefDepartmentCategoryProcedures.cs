
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefDepartmentCategory table
    public enum tblRefDepartmentCategoryProcedures
    {

        tblRefDepartmentCategory_DeleteById,
        tblRefDepartmentCategory_GetAll,
        tblRefDepartmentCategory_GetById,
        tblRefDepartmentCategory_Insert,
        tblRefDepartmentCategory_Update,

    }
}
