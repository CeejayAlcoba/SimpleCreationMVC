
namespace Project.ProcedureEnums
{
    // Procedures for the tblSideBarMenuItem table
    public enum tblSideBarMenuItemProcedures
    {


    }
}
