
namespace Project.ProcedureEnums
{
    // Procedures for the Attendances table
    public enum AttendancesProcedures
    {

        Attendances_DeleteById,
        Attendances_GetAll,
        Attendances_GetById,
        Attendances_Insert,
        Attendances_Update,

    }
}
