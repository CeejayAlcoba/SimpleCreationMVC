
namespace Project.ProcedureEnums
{
    // Procedures for the tblEmployeeSchedule table
    public enum tblEmployeeScheduleProcedures
    {

        tblEmployeeSchedule_DeleteById,
        tblEmployeeSchedule_GetAll,
        tblEmployeeSchedule_GetByEmployeeId,
        tblEmployeeSchedule_GetById,
        tblEmployeeSchedule_Insert,
        tblEmployeeSchedule_Update,

    }
}
