
namespace Project.ProcedureEnums
{
    // Procedures for the Classes table
    public enum ClassesProcedures
    {

        Classes_DeleteById,
        Classes_GetAll,
        Classes_GetById,
        Classes_GetBySubjectId,
        Classes_GetStudentListByStubjectIdAndClassId,
        Classes_Insert,
        Classes_InsertMany,
        Classes_Update,
        Classes_UpdateMany,

    }
}
