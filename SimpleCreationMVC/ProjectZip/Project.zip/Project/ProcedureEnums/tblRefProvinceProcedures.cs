
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefProvince table
    public enum tblRefProvinceProcedures
    {

        tblRefProvince_DeleteById,
        tblRefProvince_GetAll,
        tblRefProvince_GetByCountryId,
        tblRefProvince_GetById,
        tblRefProvince_Insert,
        tblRefProvince_Update,

    }
}
