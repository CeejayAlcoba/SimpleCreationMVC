
namespace Project.ProcedureEnums
{
    // Procedures for the TestCheckEnum table
    public enum TestCheckEnumProcedures
    {


    }
}
