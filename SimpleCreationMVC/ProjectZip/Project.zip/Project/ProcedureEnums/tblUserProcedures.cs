
namespace Project.ProcedureEnums
{
    // Procedures for the tblUser table
    public enum tblUserProcedures
    {

        tblUser_DeleteById,
        tblUser_GetAll,
        tblUser_GetById,
        tblUser_GetByUsername,
        tblUser_Insert,
        tblUser_Update,
        tblUserRoleMapping_DeleteByUserId,
        tblUserRoleMapping_Insert,
        tblUserRoleMapping_InsertMany,

    }
}
