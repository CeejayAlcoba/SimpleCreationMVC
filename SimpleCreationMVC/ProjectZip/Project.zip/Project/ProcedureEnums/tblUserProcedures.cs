
namespace Project.ProcedureEnums
{
    // Procedures for the tblUser table
    public enum tblUserProcedures
    {


    }
}
