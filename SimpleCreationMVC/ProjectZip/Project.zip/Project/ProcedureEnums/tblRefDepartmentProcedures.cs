
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefDepartment table
    public enum tblRefDepartmentProcedures
    {

        tblRefDepartment_DeleteById,
        tblRefDepartment_GetAll,
        tblRefDepartment_GetByDepartmentCategoryId,
        tblRefDepartment_GetById,
        tblRefDepartment_Insert,
        tblRefDepartment_Update,
        tblRefDepartmentCategory_DeleteById,
        tblRefDepartmentCategory_GetAll,
        tblRefDepartmentCategory_GetById,
        tblRefDepartmentCategory_Insert,
        tblRefDepartmentCategory_Update,

    }
}
