
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefRole2 table
    public enum tblRefRole2Procedures
    {


    }
}
