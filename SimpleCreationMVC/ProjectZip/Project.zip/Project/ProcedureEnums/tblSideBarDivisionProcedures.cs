
namespace Project.ProcedureEnums
{
    // Procedures for the tblSideBarDivision table
    public enum tblSideBarDivisionProcedures
    {


    }
}
