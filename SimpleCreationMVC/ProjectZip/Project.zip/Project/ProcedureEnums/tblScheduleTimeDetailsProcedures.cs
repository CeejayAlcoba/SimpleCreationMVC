
namespace Project.ProcedureEnums
{
    // Procedures for the tblScheduleTimeDetails table
    public enum tblScheduleTimeDetailsProcedures
    {

        tblScheduleTimeDetails_DeleteById,
        tblScheduleTimeDetails_GetAll,
        tblScheduleTimeDetails_GetByEmployeeScheduleId,
        tblScheduleTimeDetails_GetById,
        tblScheduleTimeDetails_Insert,
        tblScheduleTimeDetails_Update,

    }
}
