
namespace Project.ProcedureEnums
{
    // Procedures for the tblSideBarMenuItemUserMapping table
    public enum tblSideBarMenuItemUserMappingProcedures
    {


    }
}
