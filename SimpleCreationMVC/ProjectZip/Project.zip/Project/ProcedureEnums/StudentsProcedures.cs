
namespace Project.ProcedureEnums
{
    // Procedures for the Students table
    public enum StudentsProcedures
    {

        Students_DeleteById,
        Students_GetAll,
        Students_GetById,
        Students_Insert,
        Students_Update,

    }
}
