
namespace Project.ProcedureEnums
{
    // Procedures for the Students table
    public enum StudentsProcedures
    {

        Students_DeleteById,
        Students_DeleteBySubjectId,
        Students_GetAll,
        Students_GetAttendanceReportBySubjectId,
        Students_GetById,
        Students_GetBySubjectId,
        Students_Insert,
        Students_InsertMany,
        Students_Update,
        Students_UpdateMany,

    }
}
