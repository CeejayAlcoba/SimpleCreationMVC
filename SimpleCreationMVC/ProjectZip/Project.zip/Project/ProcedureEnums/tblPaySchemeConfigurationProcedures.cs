
namespace Project.ProcedureEnums
{
    // Procedures for the tblPaySchemeConfiguration table
    public enum tblPaySchemeConfigurationProcedures
    {

        tblPaySchemeConfiguration_GetAll,

    }
}
