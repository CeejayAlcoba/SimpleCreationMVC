
namespace ProcedureEnums
{
    // Procedures for the tblRefReactIconFamily table
    public enum tblRefReactIconFamilyProcedures
    {

        tblRefReactIconFamily_BulkDeleteNotInTVP,
        tblRefReactIconFamily_BulkInsert,
        tblRefReactIconFamily_BulkUpdate,
        tblRefReactIconFamily_DeleteById,
        tblRefReactIconFamily_GetAllByFilters,
        tblRefReactIconFamily_GetById,
        tblRefReactIconFamily_Insert,
        tblRefReactIconFamily_Update,

    }
}
