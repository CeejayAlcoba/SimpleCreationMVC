
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefPermanentAddress table
    public enum tblRefPermanentAddressProcedures
    {

        tblRefPermanentAddress_DeleteById,
        tblRefPermanentAddress_GetAll,
        tblRefPermanentAddress_GetByApplicantId,
        tblRefPermanentAddress_GetByEmployeeId,
        tblRefPermanentAddress_GetById,
        tblRefPermanentAddress_Insert,
        tblRefPermanentAddress_Update,

    }
}
