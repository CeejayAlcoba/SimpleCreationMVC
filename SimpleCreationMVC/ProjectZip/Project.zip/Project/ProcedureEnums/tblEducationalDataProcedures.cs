
namespace Project.ProcedureEnums
{
    // Procedures for the tblEducationalData table
    public enum tblEducationalDataProcedures
    {

        tblEducationalData_DeleteById,
        tblEducationalData_GetAll,
        tblEducationalData_GetByApplicantId,
        tblEducationalData_GetByEmployeeId,
        tblEducationalData_GetById,
        tblEducationalData_Insert,
        tblEducationalData_Update,

    }
}
