
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefSalaryType table
    public enum tblRefSalaryTypeProcedures
    {

        tblRefSalaryType_DeleteById,
        tblRefSalaryType_GetAll,
        tblRefSalaryType_GetById,
        tblRefSalaryType_Insert,
        tblRefSalaryType_Update,

    }
}
