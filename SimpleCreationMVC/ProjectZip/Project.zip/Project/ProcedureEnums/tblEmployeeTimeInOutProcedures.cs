
namespace Project.ProcedureEnums
{
    // Procedures for the tblEmployeeTimeInOut table
    public enum tblEmployeeTimeInOutProcedures
    {

        tblEmployeeTimeInOut_DeleteById,
        tblEmployeeTimeInOut_GetAll,
        tblEmployeeTimeInOut_GetById,
        tblEmployeeTimeInOut_GetByPeriod,
        tblEmployeeTimeInOut_Insert,
        tblEmployeeTimeInOut_InsertMany,
        tblEmployeeTimeInOut_ReflectLeaves,
        tblEmployeeTimeInOut_Update,
        tblEmployeeTimeInOut_UpdateMany,

    }
}
