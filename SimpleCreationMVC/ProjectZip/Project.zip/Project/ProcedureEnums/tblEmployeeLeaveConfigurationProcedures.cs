
namespace Project.ProcedureEnums
{
    // Procedures for the tblEmployeeLeaveConfiguration table
    public enum tblEmployeeLeaveConfigurationProcedures
    {

        tblEmployeeLeaveConfiguration_DeleteById,
        tblEmployeeLeaveConfiguration_GetAll,
        tblEmployeeLeaveConfiguration_GetById,
        tblEmployeeLeaveConfiguration_Insert,
        tblEmployeeLeaveConfiguration_Update,

    }
}
