
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefCountry table
    public enum tblRefCountryProcedures
    {

        tblRefCountry_DeleteById,
        tblRefCountry_GetAll,
        tblRefCountry_GetById,
        tblRefCountry_Insert,
        tblRefCountry_Update,

    }
}
