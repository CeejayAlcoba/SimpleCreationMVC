
namespace Project.ProcedureEnums
{
    // Procedures for the tblSideBarMenuItemRoleMapping table
    public enum tblSideBarMenuItemRoleMappingProcedures
    {


    }
}
