
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefScheduleType table
    public enum tblRefScheduleTypeProcedures
    {

        tblRefScheduleType_DeleteById,
        tblRefScheduleType_GetAll,
        tblRefScheduleType_GetById,
        tblRefScheduleType_Insert,
        tblRefScheduleType_Update,

    }
}
