
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefReligion table
    public enum tblRefReligionProcedures
    {

        tblRefReligion_DeleteById,
        tblRefReligion_GetAll,
        tblRefReligion_GetById,
        tblRefReligion_Insert,
        tblRefReligion_Update,

    }
}
