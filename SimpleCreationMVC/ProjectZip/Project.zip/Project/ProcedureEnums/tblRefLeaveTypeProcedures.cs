
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefLeaveType table
    public enum tblRefLeaveTypeProcedures
    {

        tblRefLeaveType_DeleteById,
        tblRefLeaveType_GetAll,
        tblRefLeaveType_GetById,
        tblRefLeaveType_Insert,
        tblRefLeaveType_Update,

    }
}
