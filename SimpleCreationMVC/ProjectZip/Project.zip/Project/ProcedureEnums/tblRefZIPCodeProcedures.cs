
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefZIPCode table
    public enum tblRefZIPCodeProcedures
    {

        tblRefZIPCode_DeleteById,
        tblRefZIPCode_GetAll,
        tblRefZIPCode_GetById,
        tblRefZIPCode_GetByMunicipalityId,
        tblRefZIPCode_Insert,
        tblRefZIPCode_Update,

    }
}
