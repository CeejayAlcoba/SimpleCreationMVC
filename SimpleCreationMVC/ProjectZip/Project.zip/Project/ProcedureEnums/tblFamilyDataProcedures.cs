
namespace Project.ProcedureEnums
{
    // Procedures for the tblFamilyData table
    public enum tblFamilyDataProcedures
    {

        tblFamilyData_DeleteById,
        tblFamilyData_GetAll,
        tblFamilyData_GetByApplicantId,
        tblFamilyData_GetByEmployeeId,
        tblFamilyData_GetById,
        tblFamilyData_Insert,
        tblFamilyData_Update,

    }
}
