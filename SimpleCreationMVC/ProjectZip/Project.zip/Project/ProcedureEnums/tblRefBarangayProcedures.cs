
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefBarangay table
    public enum tblRefBarangayProcedures
    {

        tblRefBarangay_DeleteById,
        tblRefBarangay_GetAll,
        tblRefBarangay_GetById,
        tblRefBarangay_GetByMunicipalityId,
        tblRefBarangay_Insert,
        tblRefBarangay_Update,

    }
}
