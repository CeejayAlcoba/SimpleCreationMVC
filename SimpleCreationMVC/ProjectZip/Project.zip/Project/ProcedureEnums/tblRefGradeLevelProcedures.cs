
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefGradeLevel table
    public enum tblRefGradeLevelProcedures
    {

        tblRefGradeLevel_DeleteById,
        tblRefGradeLevel_GetAll,
        tblRefGradeLevel_GetById,
        tblRefGradeLevel_Insert,
        tblRefGradeLevel_Update,

    }
}
