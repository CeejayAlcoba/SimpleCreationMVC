
namespace Project.ProcedureEnums
{
    // Procedures for the tblExternalWorkExperience table
    public enum tblExternalWorkExperienceProcedures
    {

        tblExternalWorkExperience_DeleteById,
        tblExternalWorkExperience_GetAll,
        tblExternalWorkExperience_GetByApplicantId,
        tblExternalWorkExperience_GetByEmployeeId,
        tblExternalWorkExperience_GetById,
        tblExternalWorkExperience_Insert,
        tblExternalWorkExperience_Update,

    }
}
