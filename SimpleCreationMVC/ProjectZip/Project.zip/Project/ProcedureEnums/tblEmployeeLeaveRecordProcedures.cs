
namespace Project.ProcedureEnums
{
    // Procedures for the tblEmployeeLeaveRecord table
    public enum tblEmployeeLeaveRecordProcedures
    {

        tblEmployeeLeaveRecord_DeleteById,
        tblEmployeeLeaveRecord_GetAll,
        tblEmployeeLeaveRecord_GetById,
        tblEmployeeLeaveRecord_Insert,
        tblEmployeeLeaveRecord_Update,

    }
}
