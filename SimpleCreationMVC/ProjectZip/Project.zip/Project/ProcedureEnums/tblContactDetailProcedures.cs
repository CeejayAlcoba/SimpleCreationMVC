
namespace Project.ProcedureEnums
{
    // Procedures for the tblContactDetail table
    public enum tblContactDetailProcedures
    {

        tblContactDetail_GetByApplicantId,
        tblContactDetail_GetByEmployeeId,
        tblContactDetail_GetById,
        tblContactDetail_Insert,
        tblContactDetail_Update,

    }
}
