
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefAppointment table
    public enum tblRefAppointmentProcedures
    {

        tblRefAppointment_DeleteById,
        tblRefAppointment_GetAll,
        tblRefAppointment_GetById,
        tblRefAppointment_Insert,
        tblRefAppointment_Update,

    }
}
