
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefEmploymentType table
    public enum tblRefEmploymentTypeProcedures
    {

        tblRefEmploymentType_DeleteById,
        tblRefEmploymentType_GetAll,
        tblRefEmploymentType_GetById,
        tblRefEmploymentType_Insert,
        tblRefEmploymentType_Update,

    }
}
