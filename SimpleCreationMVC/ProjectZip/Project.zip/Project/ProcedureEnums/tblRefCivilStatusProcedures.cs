
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefCivilStatus table
    public enum tblRefCivilStatusProcedures
    {

        tblRefCivilStatus_DeleteById,
        tblRefCivilStatus_GetAll,
        tblRefCivilStatus_GetById,
        tblRefCivilStatus_Insert,
        tblRefCivilStatus_Update,

    }
}
