
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefPresentAddress table
    public enum tblRefPresentAddressProcedures
    {

        tblRefPresentAddress_DeleteById,
        tblRefPresentAddress_GetAll,
        tblRefPresentAddress_GetByApplicantId,
        tblRefPresentAddress_GetByEmployeeId,
        tblRefPresentAddress_GetById,
        tblRefPresentAddress_Insert,
        tblRefPresentAddress_Update,

    }
}
