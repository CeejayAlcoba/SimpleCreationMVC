
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefRole table
    public enum tblRefRoleProcedures
    {

        tblRefRole_DeleteById,
        tblRefRole_GetAll,
        tblRefRole_GetById,
        tblRefRole_GetByUserId,
        tblRefRole_Insert,
        tblRefRole_Update,

    }
}
