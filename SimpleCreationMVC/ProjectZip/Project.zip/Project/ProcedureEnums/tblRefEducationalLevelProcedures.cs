
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefEducationalLevel table
    public enum tblRefEducationalLevelProcedures
    {

        tblRefEducationalLevel_DeleteById,
        tblRefEducationalLevel_GetAll,
        tblRefEducationalLevel_GetById,
        tblRefEducationalLevel_Insert,
        tblRefEducationalLevel_Update,

    }
}
