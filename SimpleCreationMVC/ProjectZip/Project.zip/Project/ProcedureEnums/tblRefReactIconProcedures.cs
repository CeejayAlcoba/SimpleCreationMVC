
namespace ProcedureEnums
{
    // Procedures for the tblRefReactIcon table
    public enum tblRefReactIconProcedures
    {

        tblRefReactIconFamily_BulkDeleteNotInTVP,
        tblRefReactIconFamily_BulkInsert,
        tblRefReactIconFamily_BulkUpdate,
        tblRefReactIconFamily_DeleteById,
        tblRefReactIconFamily_GetAllByFilters,
        tblRefReactIconFamily_GetById,
        tblRefReactIconFamily_Insert,
        tblRefReactIconFamily_Update,

    }
}
