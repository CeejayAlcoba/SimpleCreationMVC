
namespace ProcedureEnums
{
    // Procedures for the tblRefReactIcon table
    public enum tblRefReactIconProcedures
    {


    }
}
