
namespace Project.ProcedureEnums
{
    // Procedures for the tblApplicantData table
    public enum tblApplicantDataProcedures
    {

        tblApplicantData_DeleteById,
        tblApplicantData_GetAll,
        tblApplicantData_GetById,
        tblApplicantData_Insert,
        tblApplicantData_SetHiredById,
        tblApplicantData_Update,

    }
}
