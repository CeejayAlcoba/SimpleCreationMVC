
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefPosition table
    public enum tblRefPositionProcedures
    {

        tblRefPosition_DeleteById,
        tblRefPosition_GetAll,
        tblRefPosition_GetById,
        tblRefPosition_Insert,
        tblRefPosition_Update,

    }
}
