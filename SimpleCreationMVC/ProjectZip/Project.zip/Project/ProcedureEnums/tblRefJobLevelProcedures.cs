
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefJobLevel table
    public enum tblRefJobLevelProcedures
    {

        tblRefJobLevel_DeleteById,
        tblRefJobLevel_GetAll,
        tblRefJobLevel_GetById,
        tblRefJobLevel_Insert,
        tblRefJobLevel_Update,

    }
}
