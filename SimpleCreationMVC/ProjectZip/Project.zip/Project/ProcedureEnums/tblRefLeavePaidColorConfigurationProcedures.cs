
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefLeavePaidColorConfiguration table
    public enum tblRefLeavePaidColorConfigurationProcedures
    {


    }
}
