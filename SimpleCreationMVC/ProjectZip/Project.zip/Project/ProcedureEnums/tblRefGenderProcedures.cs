
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefGender table
    public enum tblRefGenderProcedures
    {

        tblRefGender_DeleteById,
        tblRefGender_GetAll,
        tblRefGender_GetById,
        tblRefGender_Insert,
        tblRefGender_Update,

    }
}
