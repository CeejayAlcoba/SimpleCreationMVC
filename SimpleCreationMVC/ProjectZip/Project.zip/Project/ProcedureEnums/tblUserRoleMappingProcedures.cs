
namespace Project.ProcedureEnums
{
    // Procedures for the tblUserRoleMapping table
    public enum tblUserRoleMappingProcedures
    {


    }
}
