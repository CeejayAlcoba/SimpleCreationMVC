
namespace Project.ProcedureEnums
{
    // Procedures for the tblUserRoleMapping table
    public enum tblUserRoleMappingProcedures
    {

        tblUserRoleMapping_DeleteByUserId,
        tblUserRoleMapping_Insert,
        tblUserRoleMapping_InsertMany,

    }
}
