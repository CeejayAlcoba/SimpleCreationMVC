
namespace Project.ProcedureEnums
{
    // Procedures for the tblEmployeeData table
    public enum tblEmployeeDataProcedures
    {

        tblEmployeeData_DeleteById,
        tblEmployeeData_GetAll,
        tblEmployeeData_GetById,
        tblEmployeeData_GetLeaveDetailsById,
        tblEmployeeData_Insert,
        tblEmployeeData_Update,

    }
}
