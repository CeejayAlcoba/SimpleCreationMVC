
namespace Project.ProcedureEnums
{
    // Procedures for the tblSideBarMenu table
    public enum tblSideBarMenuProcedures
    {

        tblSideBarMenuItem_GetByUserId,

    }
}
