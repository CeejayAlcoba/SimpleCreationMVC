
namespace Project.ProcedureEnums
{
    // Procedures for the tblRefMunicipality table
    public enum tblRefMunicipalityProcedures
    {

        tblRefMunicipality_DeleteById,
        tblRefMunicipality_GetAll,
        tblRefMunicipality_GetById,
        tblRefMunicipality_GetByProvinceId,
        tblRefMunicipality_Insert,
        tblRefMunicipality_Update,

    }
}
