
namespace Project.ProcedureEnums
{
    // Procedures for the AdminCredentials table
    public enum AdminCredentialsProcedures
    {

        AdminCredentials_DeleteById,
        AdminCredentials_GetAll,
        AdminCredentials_GetByFields,
        AdminCredentials_GetById,
        AdminCredentials_Insert,
        AdminCredentials_InsertMany,
        AdminCredentials_Update,
        AdminCredentials_UpdateMany,

    }
}
