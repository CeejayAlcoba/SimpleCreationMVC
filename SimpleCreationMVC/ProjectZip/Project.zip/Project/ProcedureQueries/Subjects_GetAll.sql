
ALTER PROCEDURE Subjects_GetAll
AS
    SELECT * FROM Subjects
GO
