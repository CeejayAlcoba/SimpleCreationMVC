
ALTER PROCEDURE AdminCredentials_GetById
@Id INT
AS
   SELECT * FROM AdminCredentials
   WHERE Id = @Id
GO
            