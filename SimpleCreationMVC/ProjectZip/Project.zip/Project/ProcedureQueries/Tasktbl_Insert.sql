
ALTER PROCEDURE Tasktbl_Insert
    @Id int = NULL,
	@Description nvarchar(MAX)  = NULL,
	@Title nvarchar(MAX)  = NULL
AS
   INSERT INTO Tasktbl(
		Description,
		Title
        )
   VALUES (
		@Description,
		@Title
        )
   SELECT * FROM Tasktbl WHERE Id = SCOPE_IDENTITY()
GO
            