
ALTER PROCEDURE Attendances_GetById
@Id INT
AS
   SELECT * FROM Attendances
   WHERE Id = @Id
GO
            