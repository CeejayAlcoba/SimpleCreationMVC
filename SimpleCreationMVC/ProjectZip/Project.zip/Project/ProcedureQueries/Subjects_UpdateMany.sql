
ALTER PROCEDURE Subjects_UpdateMany
    @TVP TVP_Subjects READONLY
AS
   UPDATE tbl
   SET
		tbl.SubjectName = tvp.SubjectName,
		tbl.CreatedAt = tvp.CreatedAt,
		tbl.IsDeleted = tvp.IsDeleted
    FROM Subjects AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO
