
ALTER PROCEDURE Tasktbl_BulkMerge
    @TVP TVP_Tasktbl READONLY
    --@ForeignIdFilter INT (this is example for filtering deletes)
AS
BEGIN
    -- 1️ Update rows where Id matches
    UPDATE tbl
    SET tbl.Description = tvp.Description,
		tbl.Title = tvp.Title
    FROM Tasktbl AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    -- 2️ Delete rows in target that are NOT in TVP
    DELETE tbl
    FROM Tasktbl AS tbl
    LEFT JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE tvp.Id IS NULL;
    --AND tbl.ForeignIdFilter = @ForeignIdFilter (please change this if necessary)

    -- 3️ Insert rows where Id is NULL or 0
    INSERT INTO Tasktbl (Description, Title)
    SELECT tvp.Description, tvp.Title
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;
END
GO
