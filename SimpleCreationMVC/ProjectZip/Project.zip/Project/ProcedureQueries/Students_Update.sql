
ALTER PROCEDURE Students_Update
	@Id int ,
	@FirstName nvarchar(MAX) ,
	@LastName nvarchar(MAX) ,
	@Gender nvarchar(MAX)  = NULL,
	@SubjectId int  = NULL,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   UPDATE Students
   SET 
		FirstName=@FirstName,
		LastName=@LastName,
		Gender=@Gender,
		SubjectId=@SubjectId,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Students WHERE Id = @Id
 GO
            