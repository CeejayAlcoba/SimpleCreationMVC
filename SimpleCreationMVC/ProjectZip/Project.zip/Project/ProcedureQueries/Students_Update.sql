
ALTER PROCEDURE Students_Update
	@Id int ,
	@FirstName nvarchar(MAX)  = NULL,
	@LastName nvarchar(MAX)  = NULL,
	@Gender nvarchar(MAX)  = NULL,
	@SubjectId int  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE Students
   SET 
		FirstName=@FirstName,
		LastName=@LastName,
		Gender=@Gender,
		SubjectId=@SubjectId,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Students WHERE Id = @Id
 GO
            