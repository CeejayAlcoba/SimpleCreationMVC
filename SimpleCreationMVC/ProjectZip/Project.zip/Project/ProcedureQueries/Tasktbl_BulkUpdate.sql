
ALTER PROCEDURE Tasktbl_BulkUpdate
    @TVP TVP_Tasktbl READONLY
AS
   UPDATE tbl
   SET
		tbl.Description = tvp.Description,
		tbl.Title = tvp.Title
    FROM Tasktbl AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO
