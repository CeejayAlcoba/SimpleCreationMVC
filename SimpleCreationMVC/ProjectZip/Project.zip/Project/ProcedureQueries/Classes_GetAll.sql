
ALTER PROCEDURE Classes_GetAll
AS
    SELECT * FROM Classes
GO
