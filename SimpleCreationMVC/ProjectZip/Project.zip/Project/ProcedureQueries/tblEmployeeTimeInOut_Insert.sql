
ALTER PROCEDURE tblEmployeeTimeInOut_Insert
    @Id int = NULL,
	@EmployeeId int  = NULL,
	@Date datetime  = NULL,
	@CheckIn time  = NULL,
	@CheckOut time  = NULL,
	@EmployeeNumber nvarchar(MAX)  = NULL,
	@DepartmentId int  = NULL,
	@Department nvarchar(MAX)  = NULL,
	@UploadedBy int  = NULL,
	@UploadedDate datetime  = NULL,
	@Note nvarchar(MAX)  = NULL
AS
   INSERT INTO tblEmployeeTimeInOut(
		EmployeeId,
		Date,
		CheckIn,
		CheckOut,
		EmployeeNumber,
		DepartmentId,
		Department,
		UploadedBy,
		UploadedDate,
		Note
        )
   VALUES (
		@EmployeeId,
		@Date,
		@CheckIn,
		@CheckOut,
		@EmployeeNumber,
		@DepartmentId,
		@Department,
		@UploadedBy,
		@UploadedDate,
		@Note
        )
   SELECT * FROM tblEmployeeTimeInOut WHERE Id = SCOPE_IDENTITY()
GO
            