
CREATE PROCEDURE tblRefReactIcon_DeleteById
    @Id INT
AS
    
    DELETE FROM tblRefReactIcon
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            