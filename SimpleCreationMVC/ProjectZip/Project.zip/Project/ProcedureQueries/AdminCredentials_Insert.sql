
ALTER PROCEDURE AdminCredentials_Insert
    @Id int = NULL,
	@UserName nvarchar(MAX)  = NULL,
	@Password nvarchar(MAX)  = NULL
AS
   INSERT INTO AdminCredentials(
		UserName,
		Password
        )
   VALUES (
		@UserName,
		@Password
        )
   SELECT * FROM AdminCredentials WHERE Id = SCOPE_IDENTITY()
GO
            