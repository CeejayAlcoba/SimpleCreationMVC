
ALTER PROCEDURE Attendances_DeleteById
    @Id INT
AS
    
    DELETE FROM Attendances
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            