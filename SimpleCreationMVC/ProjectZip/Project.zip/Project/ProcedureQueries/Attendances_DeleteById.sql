
ALTER PROCEDURE Attendances_DeleteById
    @Id INT
AS
    
    DELETE FROM Attendances
    WHERE Id =  @Id
GO
            