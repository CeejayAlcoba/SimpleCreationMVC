
CREATE PROCEDURE tblRefReactIconFamily_BulkUpdate
    @TVP TVP_tblRefReactIconFamily READONLY
AS
   UPDATE tbl
   SET
		tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIconFamily AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO
