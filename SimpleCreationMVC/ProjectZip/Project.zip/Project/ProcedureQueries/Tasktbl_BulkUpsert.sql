
ALTER PROCEDURE Tasktbl_BulkUpsert
    @TVP TVP_Tasktbl READONLY
AS
BEGIN
    -- Insert rows where Id is NULL or 0
    INSERT INTO Tasktbl (Description, Title)
    SELECT tvp.Description, tvp.Title
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;

    -- Update rows where Id matches
    UPDATE tbl
    SET tbl.Description = tvp.Description,
		tbl.Title = tvp.Title
    FROM Tasktbl AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    SELECT * FROM @TVP
END
GO
