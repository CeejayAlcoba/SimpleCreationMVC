
ALTER PROCEDURE AdminCredentials_UpdateMany
    @TVP TVP_AdminCredentials READONLY
AS
   UPDATE tbl
   SET
		tbl.UserName = tvp.UserName,
		tbl.Password = tvp.Password
    FROM AdminCredentials AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO
