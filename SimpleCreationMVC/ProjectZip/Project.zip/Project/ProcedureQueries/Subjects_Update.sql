
ALTER PROCEDURE Subjects_Update
	@Id int ,
	@SubjectName nvarchar(MAX)  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE Subjects
   SET 
		SubjectName=@SubjectName,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Subjects WHERE Id = @Id
 GO
            