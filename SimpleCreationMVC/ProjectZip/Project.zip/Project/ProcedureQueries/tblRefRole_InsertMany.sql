
ALTER PROCEDURE tblRefRole_InsertMany
    @TVP TVP_tblRefRole READONLY
AS
   INSERT INTO tblRefRole(
		Description
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.Description
    FROM @TVP AS tvp
GO
