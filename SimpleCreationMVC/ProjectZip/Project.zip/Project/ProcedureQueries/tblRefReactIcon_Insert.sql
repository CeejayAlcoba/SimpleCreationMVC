
CREATE PROCEDURE tblRefReactIcon_Insert
    @Id int = NULL,
	@ReactIconFamilyId int  = NULL,
	@Description nvarchar(MAX)  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO tblRefReactIcon(
		ReactIconFamilyId,
		Description,
		IsDeleted
        )
   VALUES (
		@ReactIconFamilyId,
		@Description,
		@IsDeleted
        )
   SELECT * FROM tblRefReactIcon WHERE Id = SCOPE_IDENTITY()
GO
            