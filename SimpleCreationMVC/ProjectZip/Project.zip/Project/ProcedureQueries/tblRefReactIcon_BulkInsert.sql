
CREATE PROCEDURE tblRefReactIcon_BulkInsert
    @TVP TVP_tblRefReactIcon READONLY
AS
   INSERT INTO tblRefReactIcon(
		ReactIconFamilyId,
		Description,
		IsDeleted
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.ReactIconFamilyId,
		tvp.Description,
		tvp.IsDeleted
    FROM @TVP AS tvp
GO
