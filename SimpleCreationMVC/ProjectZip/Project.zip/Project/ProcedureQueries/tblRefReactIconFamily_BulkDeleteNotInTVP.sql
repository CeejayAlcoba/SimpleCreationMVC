
ALTER PROCEDURE tblRefReactIconFamily_BulkDeleteNotInTVP
    -- @FilterId INT,  -- change this filterId example (@EmployeeId)
    @TVP TVP_tblRefReactIconFamily READONLY
AS
    DELETE tbl
	FROM tblRefReactIconFamily AS tbl
	LEFT JOIN @TVP AS tvp ON tbl.Id = tvp.Id
	WHERE tvp.Id IS NULL
     --AND FilterId = @FilterId  -- change this example (EmployeeId = @EmployeeId)
       
GO
