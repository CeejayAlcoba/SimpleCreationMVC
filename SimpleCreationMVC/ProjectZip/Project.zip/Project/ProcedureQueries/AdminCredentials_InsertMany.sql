
ALTER PROCEDURE AdminCredentials_InsertMany
    @TVP TVP_AdminCredentials READONLY
AS
   INSERT INTO AdminCredentials(
		UserName,
		Password
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.UserName,
		tvp.Password
    FROM @TVP AS tvp
GO
