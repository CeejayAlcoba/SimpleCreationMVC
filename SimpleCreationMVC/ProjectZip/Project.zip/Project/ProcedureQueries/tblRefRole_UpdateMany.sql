
ALTER PROCEDURE tblRefRole_UpdateMany
    @TVP TVP_tblRefRole READONLY
AS
   UPDATE tbl
   SET
		tbl.Description = tvp.Description
    FROM tblRefRole AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO
