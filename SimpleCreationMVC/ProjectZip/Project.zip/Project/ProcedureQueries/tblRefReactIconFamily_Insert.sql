
ALTER PROCEDURE tblRefReactIconFamily_Insert
    @Id int = NULL,
	@Description nvarchar(10)  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO tblRefReactIconFamily(
		Description,
		IsDeleted
        )
   VALUES (
		@Description,
		@IsDeleted
        )
   SELECT * FROM tblRefReactIconFamily WHERE Id = SCOPE_IDENTITY()
GO
            