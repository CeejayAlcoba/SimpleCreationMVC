
ALTER PROCEDURE Classes_Insert
    @Id int = NULL,
	@SubjectId int ,
	@ClassDate datetime2 ,
	@StartTime time ,
	@EndTime time ,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   INSERT INTO Classes(
		SubjectId,
		ClassDate,
		StartTime,
		EndTime,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@SubjectId,
		@ClassDate,
		@StartTime,
		@EndTime,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Classes WHERE Id = SCOPE_IDENTITY()
GO
            