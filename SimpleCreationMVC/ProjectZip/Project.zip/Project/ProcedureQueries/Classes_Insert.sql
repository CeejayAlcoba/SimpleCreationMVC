
ALTER PROCEDURE Classes_Insert
    @Id int = NULL,
	@SubjectId int  = NULL,
	@ClassDate datetime2  = NULL,
	@StartTime time  = NULL,
	@EndTime time  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO Classes(
		SubjectId,
		ClassDate,
		StartTime,
		EndTime,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@SubjectId,
		@ClassDate,
		@StartTime,
		@EndTime,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Classes WHERE Id = SCOPE_IDENTITY()
GO
            