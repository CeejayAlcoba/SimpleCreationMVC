
ALTER PROCEDURE Subjects_DeleteById
    @Id INT
AS
    
    DELETE FROM Subjects
    WHERE Id =  @Id
GO
            