
ALTER PROCEDURE Subjects_DeleteById
    @Id INT
AS
    
    DELETE FROM Subjects
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            