
CREATE PROCEDURE tblRefReactIcon_GetById
@Id INT
AS
   SELECT * FROM tblRefReactIcon
   WHERE Id = @Id
GO
            