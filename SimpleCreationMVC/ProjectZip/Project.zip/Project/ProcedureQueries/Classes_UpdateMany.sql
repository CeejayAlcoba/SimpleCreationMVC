
ALTER PROCEDURE Classes_UpdateMany
    @TVP TVP_Classes READONLY
AS
   UPDATE tbl
   SET
		tbl.SubjectId = tvp.SubjectId,
		tbl.ClassDate = tvp.ClassDate,
		tbl.StartTime = tvp.StartTime,
		tbl.EndTime = tvp.EndTime,
		tbl.CreatedAt = tvp.CreatedAt,
		tbl.IsDeleted = tvp.IsDeleted
    FROM Classes AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO
