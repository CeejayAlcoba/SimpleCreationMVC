
ALTER PROCEDURE Classes_Update
	@Id int ,
	@SubjectId int  = NULL,
	@ClassDate datetime2  = NULL,
	@StartTime time  = NULL,
	@EndTime time  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE Classes
   SET 
		SubjectId=@SubjectId,
		ClassDate=@ClassDate,
		StartTime=@StartTime,
		EndTime=@EndTime,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Classes WHERE Id = @Id
 GO
            