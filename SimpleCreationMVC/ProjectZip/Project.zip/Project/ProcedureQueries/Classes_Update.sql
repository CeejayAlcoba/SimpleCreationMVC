
ALTER PROCEDURE Classes_Update
	@Id int ,
	@SubjectId int ,
	@ClassDate datetime2 ,
	@StartTime time ,
	@EndTime time ,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   UPDATE Classes
   SET 
		SubjectId=@SubjectId,
		ClassDate=@ClassDate,
		StartTime=@StartTime,
		EndTime=@EndTime,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Classes WHERE Id = @Id
 GO
            