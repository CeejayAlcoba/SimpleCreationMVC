
CREATE PROCEDURE tblRefReactIcon_GetAllByFilters
    @Id int = NULL,
	@ReactIconFamilyId int  = NULL,
	@Description nvarchar(MAX)  = NULL,
	@IsDeleted bit  = NULL
AS
BEGIN
    SELECT *
    FROM tblRefReactIcon
    WHERE (@Id IS NULL OR Id = @Id) AND 
	(@ReactIconFamilyId IS NULL OR ReactIconFamilyId = @ReactIconFamilyId) AND 
	(@Description IS NULL OR Description = @Description) AND 
	(@IsDeleted IS NULL OR IsDeleted = @IsDeleted)
END
GO
