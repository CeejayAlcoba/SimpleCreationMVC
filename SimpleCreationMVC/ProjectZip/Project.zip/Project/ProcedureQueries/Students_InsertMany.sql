
ALTER PROCEDURE Students_InsertMany
    @TVP TVP_Students READONLY
AS
   INSERT INTO Students(
		FirstName,
		LastName,
		Gender,
		SubjectId,
		CreatedAt,
		IsDeleted,
		MiddleName
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.FirstName,
		tvp.LastName,
		tvp.Gender,
		tvp.SubjectId,
		tvp.CreatedAt,
		tvp.IsDeleted,
		tvp.MiddleName
    FROM @TVP AS tvp
GO
