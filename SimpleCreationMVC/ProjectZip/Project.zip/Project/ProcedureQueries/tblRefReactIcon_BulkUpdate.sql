
CREATE PROCEDURE tblRefReactIcon_BulkUpdate
    @TVP TVP_tblRefReactIcon READONLY
AS
   UPDATE tbl
   SET
		tbl.ReactIconFamilyId = tvp.ReactIconFamilyId,
		tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIcon AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO
