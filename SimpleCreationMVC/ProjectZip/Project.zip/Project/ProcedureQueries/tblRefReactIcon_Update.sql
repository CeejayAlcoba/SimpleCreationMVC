
CREATE PROCEDURE tblRefReactIcon_Update
	@Id int ,
	@ReactIconFamilyId int  = NULL,
	@Description nvarchar(MAX)  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE tblRefReactIcon
   SET 
		ReactIconFamilyId=@ReactIconFamilyId,
		Description=@Description,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM tblRefReactIcon WHERE Id = @Id
 GO
            