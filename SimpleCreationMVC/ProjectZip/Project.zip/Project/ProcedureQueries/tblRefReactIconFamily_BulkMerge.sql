
CREATE PROCEDURE tblRefReactIconFamily_BulkMerge
    @TVP TVP_tblRefReactIconFamily READONLY
    --@ForeignIdFilter INT (this is example for filtering deletes)
AS
BEGIN
    -- 1️ Update rows where Id matches
    UPDATE tbl
    SET tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIconFamily AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    -- 2️ Delete rows in target that are NOT in TVP
    DELETE tbl
    FROM tblRefReactIconFamily AS tbl
    LEFT JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE tvp.Id IS NULL;
    --AND tbl.ForeignIdFilter = @ForeignIdFilter (please change this if necessary)

    -- 3️ Insert rows where Id is NULL or 0
    INSERT INTO tblRefReactIconFamily (Description, IsDeleted)
    SELECT tvp.Description, tvp.IsDeleted
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;

    SELECT * FROM @TVP
END
GO
