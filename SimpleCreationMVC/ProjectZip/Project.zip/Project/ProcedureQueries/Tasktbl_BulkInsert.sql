
ALTER PROCEDURE Tasktbl_BulkInsert
    @TVP TVP_Tasktbl READONLY
AS
   INSERT INTO Tasktbl(
		Description,
		Title
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.Description,
		tvp.Title
    FROM @TVP AS tvp
GO
