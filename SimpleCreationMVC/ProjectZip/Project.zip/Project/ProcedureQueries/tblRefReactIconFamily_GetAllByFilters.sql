
ALTER PROCEDURE tblRefReactIconFamily_GetAllByFilters
    @Id int = NULL,
	@Description nvarchar(10)  = NULL,
	@IsDeleted bit  = NULL
AS
BEGIN
    SELECT *
    FROM tblRefReactIconFamily
    WHERE (@Id IS NULL OR Id = @Id) AND 
	(@Description IS NULL OR Description = @Description) AND 
	(@IsDeleted IS NULL OR IsDeleted = @IsDeleted)
END
GO
