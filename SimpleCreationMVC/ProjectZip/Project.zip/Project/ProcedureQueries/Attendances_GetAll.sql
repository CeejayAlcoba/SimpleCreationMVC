
ALTER PROCEDURE Attendances_GetAll
AS
    SELECT * FROM Attendances
GO
