
ALTER PROCEDURE Tasktbl_Update
	@Id int ,
	@Description nvarchar(MAX)  = NULL,
	@Title nvarchar(MAX)  = NULL
AS
   UPDATE Tasktbl
   SET 
		Description=@Description,
		Title=@Title
    WHERE Id = @Id
    SELECT * FROM Tasktbl WHERE Id = @Id
 GO
            