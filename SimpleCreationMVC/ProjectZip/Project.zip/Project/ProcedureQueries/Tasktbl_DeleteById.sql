
ALTER PROCEDURE Tasktbl_DeleteById
    @Id INT
AS
    
    DELETE FROM Tasktbl
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            