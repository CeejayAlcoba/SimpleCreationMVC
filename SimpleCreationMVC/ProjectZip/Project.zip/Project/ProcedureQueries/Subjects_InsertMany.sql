
ALTER PROCEDURE Subjects_InsertMany
    @TVP TVP_Subjects READONLY
AS
   INSERT INTO Subjects(
		SubjectName,
		CreatedAt,
		IsDeleted
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.SubjectName,
		tvp.CreatedAt,
		tvp.IsDeleted
    FROM @TVP AS tvp
GO
