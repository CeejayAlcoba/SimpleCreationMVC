
ALTER PROCEDURE tblEmployeeTimeInOut_UpdateMany
    @TVP TVP_tblEmployeeTimeInOut READONLY
AS
   UPDATE tbl
   SET
		tbl.EmployeeId = tvp.EmployeeId,
		tbl.Date = tvp.Date,
		tbl.CheckIn = tvp.CheckIn,
		tbl.CheckOut = tvp.CheckOut,
		tbl.EmployeeNumber = tvp.EmployeeNumber,
		tbl.DepartmentId = tvp.DepartmentId,
		tbl.Department = tvp.Department,
		tbl.UploadedBy = tvp.UploadedBy,
		tbl.UploadedDate = tvp.UploadedDate,
		tbl.Note = tvp.Note
    FROM tblEmployeeTimeInOut AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO
