
ALTER PROCEDURE tblRefRole_GetById
@Id INT
AS
   SELECT * FROM tblRefRole
   WHERE Id = @Id
GO
            