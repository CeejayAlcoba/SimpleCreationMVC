
ALTER PROCEDURE tblRefRole_Update
	@Id int ,
	@Description nvarchar(MAX)  = NULL
AS
   UPDATE tblRefRole
   SET 
		Description=@Description
    WHERE Id = @Id
    SELECT * FROM tblRefRole WHERE Id = @Id
 GO
            