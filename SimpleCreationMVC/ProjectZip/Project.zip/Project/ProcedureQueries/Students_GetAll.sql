
ALTER PROCEDURE Students_GetAll
AS
    SELECT * FROM Students
GO
