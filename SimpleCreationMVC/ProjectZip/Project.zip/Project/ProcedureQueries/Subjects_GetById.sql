
ALTER PROCEDURE Subjects_GetById
@Id INT
AS
   SELECT * FROM Subjects
   WHERE Id = @Id
GO
            