
CREATE PROCEDURE tblRefReactIconFamily_BulkInsert
    @TVP TVP_tblRefReactIconFamily READONLY
AS
   INSERT INTO tblRefReactIconFamily(
		Description,
		IsDeleted
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.Description,
		tvp.IsDeleted
    FROM @TVP AS tvp
GO
