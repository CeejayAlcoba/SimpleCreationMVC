
ALTER PROCEDURE tblRefReactIconFamily_BulkInsert
    @TVP TVP_tblRefReactIconFamily READONLY
AS
    CREATE TABLE #Inserted (Id INT);

   INSERT INTO tblRefReactIconFamily(
		Description,
		IsDeleted
        )
   OUTPUT INSERTED.Id INTO #Inserted
   SELECT 
		tvp.Description,
		tvp.IsDeleted
    FROM @TVP AS tvp

    SELECT tbl.*
    FROM tblRefReactIconFamily tbl
    INNER JOIN #Inserted i ON tbl.Id = i.Id;
GO
