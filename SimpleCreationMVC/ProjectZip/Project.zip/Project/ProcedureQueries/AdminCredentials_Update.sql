
ALTER PROCEDURE AdminCredentials_Update
	@Id int ,
	@UserName nvarchar(MAX)  = NULL,
	@Password nvarchar(MAX)  = NULL
AS
   UPDATE AdminCredentials
   SET 
		UserName=@UserName,
		Password=@Password
    WHERE Id = @Id
    SELECT * FROM AdminCredentials WHERE Id = @Id
 GO
            