
CREATE PROCEDURE tblRefReactIconFamily_GetById
@Id INT
AS
   SELECT * FROM tblRefReactIconFamily
   WHERE Id = @Id
GO
            