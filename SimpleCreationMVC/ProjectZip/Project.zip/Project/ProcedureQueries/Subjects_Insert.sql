
ALTER PROCEDURE Subjects_Insert
    @Id int = NULL,
	@SubjectName nvarchar(MAX)  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO Subjects(
		SubjectName,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@SubjectName,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Subjects WHERE Id = SCOPE_IDENTITY()
GO
            