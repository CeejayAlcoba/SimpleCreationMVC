
ALTER PROCEDURE Attendances_UpdateMany
    @TVP TVP_Attendances READONLY
AS
   UPDATE tbl
   SET
		tbl.StudentId = tvp.StudentId,
		tbl.ClassId = tvp.ClassId,
		tbl.AttendanceDate = tvp.AttendanceDate,
		tbl.CreatedAt = tvp.CreatedAt,
		tbl.IsDeleted = tvp.IsDeleted
    FROM Attendances AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO
