
CREATE PROCEDURE tblRefReactIcon_BulkUpsert
    @TVP TVP_tblRefReactIcon READONLY
AS
BEGIN
    -- Insert rows where Id is NULL or 0
    INSERT INTO tblRefReactIcon (ReactIconFamilyId, Description, IsDeleted)
    SELECT tvp.ReactIconFamilyId, tvp.Description, tvp.IsDeleted
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;

    -- Update rows where Id matches
    UPDATE tbl
    SET tbl.ReactIconFamilyId = tvp.ReactIconFamilyId,
		tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIcon AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    SELECT * FROM @TVP
END
GO
