
ALTER PROCEDURE Students_UpdateMany
    @TVP TVP_Students READONLY
AS
   UPDATE tbl
   SET
		tbl.FirstName = tvp.FirstName,
		tbl.LastName = tvp.LastName,
		tbl.Gender = tvp.Gender,
		tbl.SubjectId = tvp.SubjectId,
		tbl.CreatedAt = tvp.CreatedAt,
		tbl.IsDeleted = tvp.IsDeleted,
		tbl.MiddleName = tvp.MiddleName
    FROM Students AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO
