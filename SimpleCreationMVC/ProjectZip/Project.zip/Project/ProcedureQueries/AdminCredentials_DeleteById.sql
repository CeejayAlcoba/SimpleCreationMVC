
ALTER PROCEDURE AdminCredentials_DeleteById
    @Id INT
AS
    
    DELETE FROM AdminCredentials
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            