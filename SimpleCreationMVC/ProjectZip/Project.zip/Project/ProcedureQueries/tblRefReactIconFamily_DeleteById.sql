
CREATE PROCEDURE tblRefReactIconFamily_DeleteById
    @Id INT
AS
    
    DELETE FROM tblRefReactIconFamily
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            