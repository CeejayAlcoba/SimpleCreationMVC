
ALTER PROCEDURE tblRefReactIconFamily_DeleteById
    @Id INT
AS
    
    DELETE FROM tblRefReactIconFamily
    WHERE Id =  @Id
GO
            