
ALTER PROCEDURE Tasktbl_GetAll
AS
    SELECT * FROM Tasktbl
GO
