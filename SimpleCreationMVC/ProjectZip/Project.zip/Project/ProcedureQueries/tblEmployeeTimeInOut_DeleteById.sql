
ALTER PROCEDURE tblEmployeeTimeInOut_DeleteById
    @Id INT
AS
    
    DELETE FROM tblEmployeeTimeInOut
    WHERE Id =  @Id
GO
            