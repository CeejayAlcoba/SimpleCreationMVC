
ALTER PROCEDURE tblRefRole_DeleteById
    @Id INT
AS
    
    DELETE FROM tblRefRole
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            