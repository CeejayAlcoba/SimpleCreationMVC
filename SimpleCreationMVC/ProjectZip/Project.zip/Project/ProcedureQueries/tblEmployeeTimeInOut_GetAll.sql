
ALTER PROCEDURE tblEmployeeTimeInOut_GetAll
AS
    SELECT * FROM tblEmployeeTimeInOut
GO
