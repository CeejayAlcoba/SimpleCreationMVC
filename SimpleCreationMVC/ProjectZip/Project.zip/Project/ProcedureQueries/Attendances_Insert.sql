
ALTER PROCEDURE Attendances_Insert
    @Id int = NULL,
	@StudentId int  = NULL,
	@ClassId int  = NULL,
	@AttendanceDate datetime2  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO Attendances(
		StudentId,
		ClassId,
		AttendanceDate,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@StudentId,
		@ClassId,
		@AttendanceDate,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Attendances WHERE Id = SCOPE_IDENTITY()
GO
            