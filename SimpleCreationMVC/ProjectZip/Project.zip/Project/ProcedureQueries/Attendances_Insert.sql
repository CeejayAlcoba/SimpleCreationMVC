
ALTER PROCEDURE Attendances_Insert
    @Id int = NULL,
	@StudentId int ,
	@ClassId int ,
	@AttendanceDate datetime2 ,
	@ClassId1 int  = NULL,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   INSERT INTO Attendances(
		StudentId,
		ClassId,
		AttendanceDate,
		ClassId1,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@StudentId,
		@ClassId,
		@AttendanceDate,
		@ClassId1,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Attendances WHERE Id = SCOPE_IDENTITY()
GO
            