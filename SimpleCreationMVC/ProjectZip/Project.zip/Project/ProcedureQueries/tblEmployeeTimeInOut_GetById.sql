
ALTER PROCEDURE tblEmployeeTimeInOut_GetById
@Id INT
AS
   SELECT * FROM tblEmployeeTimeInOut
   WHERE Id = @Id
GO
            