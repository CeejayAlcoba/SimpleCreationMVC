
ALTER PROCEDURE Tasktbl_GetById
@Id INT
AS
   SELECT * FROM Tasktbl
   WHERE Id = @Id
GO
            