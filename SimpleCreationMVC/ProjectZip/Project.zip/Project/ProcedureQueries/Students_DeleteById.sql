
ALTER PROCEDURE Students_DeleteById
    @Id INT
AS
    
    DELETE FROM Students
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            