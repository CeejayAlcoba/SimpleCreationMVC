
ALTER PROCEDURE Students_DeleteById
    @Id INT
AS
    
    DELETE FROM Students
    WHERE Id =  @Id
GO
            