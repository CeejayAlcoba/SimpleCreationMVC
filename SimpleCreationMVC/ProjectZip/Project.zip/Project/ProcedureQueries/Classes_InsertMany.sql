
ALTER PROCEDURE Classes_InsertMany
    @TVP TVP_Classes READONLY
AS
   INSERT INTO Classes(
		SubjectId,
		ClassDate,
		StartTime,
		EndTime,
		CreatedAt,
		IsDeleted
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.SubjectId,
		tvp.ClassDate,
		tvp.StartTime,
		tvp.EndTime,
		tvp.CreatedAt,
		tvp.IsDeleted
    FROM @TVP AS tvp
GO
