
ALTER PROCEDURE tblRefRole_GetAll
AS
    SELECT * FROM tblRefRole
GO
