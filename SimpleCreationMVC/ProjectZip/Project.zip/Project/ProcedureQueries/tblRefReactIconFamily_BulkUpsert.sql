
CREATE PROCEDURE tblRefReactIconFamily_BulkUpsert
    @TVP TVP_tblRefReactIconFamily READONLY
AS
BEGIN
    -- Insert rows where Id is NULL or 0
    INSERT INTO tblRefReactIconFamily (Description, IsDeleted)
    SELECT tvp.Description, tvp.IsDeleted
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;

    -- Update rows where Id matches
    UPDATE tbl
    SET tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIconFamily AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    SELECT * FROM @TVP
END
GO
