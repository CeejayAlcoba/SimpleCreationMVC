
ALTER PROCEDURE Students_GetById
@Id INT
AS
   SELECT * FROM Students
   WHERE Id = @Id
GO
            