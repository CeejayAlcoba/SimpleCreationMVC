
ALTER PROCEDURE tblEmployeeTimeInOut_Update
	@Id int ,
	@EmployeeId int  = NULL,
	@Date datetime  = NULL,
	@CheckIn time  = NULL,
	@CheckOut time  = NULL,
	@EmployeeNumber nvarchar(MAX)  = NULL,
	@DepartmentId int  = NULL,
	@Department nvarchar(MAX)  = NULL,
	@UploadedBy int  = NULL,
	@UploadedDate datetime  = NULL,
	@Note nvarchar(MAX)  = NULL
AS
   UPDATE tblEmployeeTimeInOut
   SET 
		EmployeeId=@EmployeeId,
		Date=@Date,
		CheckIn=@CheckIn,
		CheckOut=@CheckOut,
		EmployeeNumber=@EmployeeNumber,
		DepartmentId=@DepartmentId,
		Department=@Department,
		UploadedBy=@UploadedBy,
		UploadedDate=@UploadedDate,
		Note=@Note
    WHERE Id = @Id
    SELECT * FROM tblEmployeeTimeInOut WHERE Id = @Id
 GO
            