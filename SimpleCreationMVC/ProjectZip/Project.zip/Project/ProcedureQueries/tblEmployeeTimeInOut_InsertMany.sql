
ALTER PROCEDURE tblEmployeeTimeInOut_InsertMany
    @TVP TVP_tblEmployeeTimeInOut READONLY
AS
   INSERT INTO tblEmployeeTimeInOut(
		EmployeeId,
		Date,
		CheckIn,
		CheckOut,
		EmployeeNumber,
		DepartmentId,
		Department,
		UploadedBy,
		UploadedDate,
		Note
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.EmployeeId,
		tvp.Date,
		tvp.CheckIn,
		tvp.CheckOut,
		tvp.EmployeeNumber,
		tvp.DepartmentId,
		tvp.Department,
		tvp.UploadedBy,
		tvp.UploadedDate,
		tvp.Note
    FROM @TVP AS tvp
GO
