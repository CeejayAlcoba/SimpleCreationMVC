
ALTER PROCEDURE Classes_DeleteById
    @Id INT
AS
    
    DELETE FROM Classes
    WHERE Id =  @Id
GO
            