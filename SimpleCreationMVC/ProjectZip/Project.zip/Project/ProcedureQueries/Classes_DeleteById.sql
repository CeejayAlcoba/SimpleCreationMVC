
ALTER PROCEDURE Classes_DeleteById
    @Id INT
AS
    
    DELETE FROM Classes
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            