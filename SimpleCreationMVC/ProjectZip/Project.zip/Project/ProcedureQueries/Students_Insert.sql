
ALTER PROCEDURE Students_Insert
    @Id int = NULL,
	@FirstName nvarchar(MAX) ,
	@LastName nvarchar(MAX) ,
	@Gender nvarchar(MAX)  = NULL,
	@SubjectId int  = NULL,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   INSERT INTO Students(
		FirstName,
		LastName,
		Gender,
		SubjectId,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@FirstName,
		@LastName,
		@Gender,
		@SubjectId,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Students WHERE Id = SCOPE_IDENTITY()
GO
            