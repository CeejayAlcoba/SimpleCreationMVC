
ALTER PROCEDURE Students_Insert
    @Id int = NULL,
	@FirstName nvarchar(MAX)  = NULL,
	@LastName nvarchar(MAX)  = NULL,
	@Gender nvarchar(MAX)  = NULL,
	@SubjectId int  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL,
	@MiddleName nvarchar(MAX)  = NULL
AS
   INSERT INTO Students(
		FirstName,
		LastName,
		Gender,
		SubjectId,
		CreatedAt,
		IsDeleted,
		MiddleName
        )
   VALUES (
		@FirstName,
		@LastName,
		@Gender,
		@SubjectId,
		@CreatedAt,
		@IsDeleted,
		@MiddleName
        )
   SELECT * FROM Students WHERE Id = SCOPE_IDENTITY()
GO
            