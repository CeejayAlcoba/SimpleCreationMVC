
CREATE PROCEDURE Tasktbl_GetAllByFilters
    @Id int = NULL,
	@Description nvarchar(MAX)  = NULL,
	@Title nvarchar(MAX)  = NULL
AS
BEGIN
    SELECT *
    FROM Tasktbl
    WHERE (@Id IS NULL OR Id = @Id) AND 
	(@Description IS NULL OR Description = @Description) AND 
	(@Title IS NULL OR Title = @Title)
END
GO
