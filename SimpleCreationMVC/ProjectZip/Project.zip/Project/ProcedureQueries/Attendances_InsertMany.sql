
ALTER PROCEDURE Attendances_InsertMany
    @TVP TVP_Attendances READONLY
AS
   INSERT INTO Attendances(
		StudentId,
		ClassId,
		AttendanceDate,
		CreatedAt,
		IsDeleted
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.StudentId,
		tvp.ClassId,
		tvp.AttendanceDate,
		tvp.CreatedAt,
		tvp.IsDeleted
    FROM @TVP AS tvp
GO
