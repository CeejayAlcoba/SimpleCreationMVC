
ALTER PROCEDURE tblRefRole_Insert
    @Id int = NULL,
	@Description nvarchar(MAX)  = NULL
AS
   INSERT INTO tblRefRole(
		Description
        )
   VALUES (
		@Description
        )
   SELECT * FROM tblRefRole WHERE Id = SCOPE_IDENTITY()
GO
            