
ALTER PROCEDURE AdminCredentials_GetAll
AS
    SELECT * FROM AdminCredentials
GO
