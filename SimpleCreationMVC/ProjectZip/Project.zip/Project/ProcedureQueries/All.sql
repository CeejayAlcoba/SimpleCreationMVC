
ALTER PROCEDURE tblEmployeeTimeInOut_GetAll
AS
    SELECT * FROM tblEmployeeTimeInOut
GO


ALTER PROCEDURE tblEmployeeTimeInOut_Insert
    @Id int = NULL,
	@EmployeeId int  = NULL,
	@Date datetime  = NULL,
	@CheckIn time  = NULL,
	@CheckOut time  = NULL,
	@EmployeeNumber nvarchar(MAX)  = NULL,
	@DepartmentId int  = NULL,
	@Department nvarchar(MAX)  = NULL,
	@UploadedBy int  = NULL,
	@UploadedDate datetime  = NULL,
	@Note nvarchar(MAX)  = NULL
AS
   INSERT INTO tblEmployeeTimeInOut(
		EmployeeId,
		Date,
		CheckIn,
		CheckOut,
		EmployeeNumber,
		DepartmentId,
		Department,
		UploadedBy,
		UploadedDate,
		Note
        )
   VALUES (
		@EmployeeId,
		@Date,
		@CheckIn,
		@CheckOut,
		@EmployeeNumber,
		@DepartmentId,
		@Department,
		@UploadedBy,
		@UploadedDate,
		@Note
        )
   SELECT * FROM tblEmployeeTimeInOut WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE tblEmployeeTimeInOut_Update
	@Id int ,
	@EmployeeId int  = NULL,
	@Date datetime  = NULL,
	@CheckIn time  = NULL,
	@CheckOut time  = NULL,
	@EmployeeNumber nvarchar(MAX)  = NULL,
	@DepartmentId int  = NULL,
	@Department nvarchar(MAX)  = NULL,
	@UploadedBy int  = NULL,
	@UploadedDate datetime  = NULL,
	@Note nvarchar(MAX)  = NULL
AS
   UPDATE tblEmployeeTimeInOut
   SET 
		EmployeeId=@EmployeeId,
		Date=@Date,
		CheckIn=@CheckIn,
		CheckOut=@CheckOut,
		EmployeeNumber=@EmployeeNumber,
		DepartmentId=@DepartmentId,
		Department=@Department,
		UploadedBy=@UploadedBy,
		UploadedDate=@UploadedDate,
		Note=@Note
    WHERE Id = @Id
    SELECT * FROM tblEmployeeTimeInOut WHERE Id = @Id
 GO
            

ALTER PROCEDURE tblEmployeeTimeInOut_GetById
@Id INT
AS
   SELECT * FROM tblEmployeeTimeInOut
   WHERE Id = @Id
GO
            

ALTER PROCEDURE tblEmployeeTimeInOut_DeleteById
    @Id INT
AS
    
    DELETE FROM tblEmployeeTimeInOut
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_tblEmployeeTimeInOut AS TABLE
(
	Id int,
	EmployeeId int,
	Date datetime,
	CheckIn time,
	CheckOut time,
	EmployeeNumber nvarchar(MAX),
	DepartmentId int,
	Department nvarchar(MAX),
	UploadedBy int,
	UploadedDate datetime,
	Note nvarchar(MAX)

)
GO


ALTER PROCEDURE tblEmployeeTimeInOut_InsertMany
    @TVP TVP_tblEmployeeTimeInOut READONLY
AS
   INSERT INTO tblEmployeeTimeInOut(
		EmployeeId,
		Date,
		CheckIn,
		CheckOut,
		EmployeeNumber,
		DepartmentId,
		Department,
		UploadedBy,
		UploadedDate,
		Note
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.EmployeeId,
		tvp.Date,
		tvp.CheckIn,
		tvp.CheckOut,
		tvp.EmployeeNumber,
		tvp.DepartmentId,
		tvp.Department,
		tvp.UploadedBy,
		tvp.UploadedDate,
		tvp.Note
    FROM @TVP AS tvp
GO


ALTER PROCEDURE tblEmployeeTimeInOut_UpdateMany
    @TVP TVP_tblEmployeeTimeInOut READONLY
AS
   UPDATE tbl
   SET
		tbl.EmployeeId = tvp.EmployeeId,
		tbl.Date = tvp.Date,
		tbl.CheckIn = tvp.CheckIn,
		tbl.CheckOut = tvp.CheckOut,
		tbl.EmployeeNumber = tvp.EmployeeNumber,
		tbl.DepartmentId = tvp.DepartmentId,
		tbl.Department = tvp.Department,
		tbl.UploadedBy = tvp.UploadedBy,
		tbl.UploadedDate = tvp.UploadedDate,
		tbl.Note = tvp.Note
    FROM tblEmployeeTimeInOut AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO

