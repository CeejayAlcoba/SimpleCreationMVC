
ALTER PROCEDURE AdminCredentials_GetAll
AS
    SELECT * FROM AdminCredentials
GO


ALTER PROCEDURE AdminCredentials_Insert
    @Id int = NULL,
	@UserName nvarchar(MAX)  = NULL,
	@Password nvarchar(MAX)  = NULL
AS
   INSERT INTO AdminCredentials(
		UserName,
		Password
        )
   VALUES (
		@UserName,
		@Password
        )
   SELECT * FROM AdminCredentials WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE AdminCredentials_Update
	@Id int ,
	@UserName nvarchar(MAX)  = NULL,
	@Password nvarchar(MAX)  = NULL
AS
   UPDATE AdminCredentials
   SET 
		UserName=@UserName,
		Password=@Password
    WHERE Id = @Id
    SELECT * FROM AdminCredentials WHERE Id = @Id
 GO
            

ALTER PROCEDURE AdminCredentials_GetById
@Id INT
AS
   SELECT * FROM AdminCredentials
   WHERE Id = @Id
GO
            

ALTER PROCEDURE AdminCredentials_DeleteById
    @Id INT
AS
    
    DELETE FROM AdminCredentials
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_AdminCredentials AS TABLE
(
	Id int,
	UserName nvarchar(MAX),
	Password nvarchar(MAX)

)
GO


ALTER PROCEDURE AdminCredentials_InsertMany
    @TVP TVP_AdminCredentials READONLY
AS
   INSERT INTO AdminCredentials(
		UserName,
		Password
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.UserName,
		tvp.Password
    FROM @TVP AS tvp
GO


ALTER PROCEDURE AdminCredentials_UpdateMany
    @TVP TVP_AdminCredentials READONLY
AS
   UPDATE tbl
   SET
		tbl.UserName = tvp.UserName,
		tbl.Password = tvp.Password
    FROM AdminCredentials AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO


ALTER PROCEDURE Attendances_GetAll
AS
    SELECT * FROM Attendances
GO


ALTER PROCEDURE Attendances_Insert
    @Id int = NULL,
	@StudentId int  = NULL,
	@ClassId int  = NULL,
	@AttendanceDate datetime2  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO Attendances(
		StudentId,
		ClassId,
		AttendanceDate,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@StudentId,
		@ClassId,
		@AttendanceDate,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Attendances WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE Attendances_Update
	@Id int ,
	@StudentId int  = NULL,
	@ClassId int  = NULL,
	@AttendanceDate datetime2  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE Attendances
   SET 
		StudentId=@StudentId,
		ClassId=@ClassId,
		AttendanceDate=@AttendanceDate,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Attendances WHERE Id = @Id
 GO
            

ALTER PROCEDURE Attendances_GetById
@Id INT
AS
   SELECT * FROM Attendances
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Attendances_DeleteById
    @Id INT
AS
    
    DELETE FROM Attendances
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_Attendances AS TABLE
(
	Id int,
	StudentId int,
	ClassId int,
	AttendanceDate datetime2,
	CreatedAt datetime2,
	IsDeleted bit

)
GO


ALTER PROCEDURE Attendances_InsertMany
    @TVP TVP_Attendances READONLY
AS
   INSERT INTO Attendances(
		StudentId,
		ClassId,
		AttendanceDate,
		CreatedAt,
		IsDeleted
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.StudentId,
		tvp.ClassId,
		tvp.AttendanceDate,
		tvp.CreatedAt,
		tvp.IsDeleted
    FROM @TVP AS tvp
GO


ALTER PROCEDURE Attendances_UpdateMany
    @TVP TVP_Attendances READONLY
AS
   UPDATE tbl
   SET
		tbl.StudentId = tvp.StudentId,
		tbl.ClassId = tvp.ClassId,
		tbl.AttendanceDate = tvp.AttendanceDate,
		tbl.CreatedAt = tvp.CreatedAt,
		tbl.IsDeleted = tvp.IsDeleted
    FROM Attendances AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO


ALTER PROCEDURE Classes_GetAll
AS
    SELECT * FROM Classes
GO


ALTER PROCEDURE Classes_Insert
    @Id int = NULL,
	@SubjectId int  = NULL,
	@ClassDate datetime2  = NULL,
	@StartTime time  = NULL,
	@EndTime time  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO Classes(
		SubjectId,
		ClassDate,
		StartTime,
		EndTime,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@SubjectId,
		@ClassDate,
		@StartTime,
		@EndTime,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Classes WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE Classes_Update
	@Id int ,
	@SubjectId int  = NULL,
	@ClassDate datetime2  = NULL,
	@StartTime time  = NULL,
	@EndTime time  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE Classes
   SET 
		SubjectId=@SubjectId,
		ClassDate=@ClassDate,
		StartTime=@StartTime,
		EndTime=@EndTime,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Classes WHERE Id = @Id
 GO
            

ALTER PROCEDURE Classes_GetById
@Id INT
AS
   SELECT * FROM Classes
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Classes_DeleteById
    @Id INT
AS
    
    DELETE FROM Classes
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_Classes AS TABLE
(
	Id int,
	SubjectId int,
	ClassDate datetime2,
	StartTime time,
	EndTime time,
	CreatedAt datetime2,
	IsDeleted bit

)
GO


ALTER PROCEDURE Classes_InsertMany
    @TVP TVP_Classes READONLY
AS
   INSERT INTO Classes(
		SubjectId,
		ClassDate,
		StartTime,
		EndTime,
		CreatedAt,
		IsDeleted
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.SubjectId,
		tvp.ClassDate,
		tvp.StartTime,
		tvp.EndTime,
		tvp.CreatedAt,
		tvp.IsDeleted
    FROM @TVP AS tvp
GO


ALTER PROCEDURE Classes_UpdateMany
    @TVP TVP_Classes READONLY
AS
   UPDATE tbl
   SET
		tbl.SubjectId = tvp.SubjectId,
		tbl.ClassDate = tvp.ClassDate,
		tbl.StartTime = tvp.StartTime,
		tbl.EndTime = tvp.EndTime,
		tbl.CreatedAt = tvp.CreatedAt,
		tbl.IsDeleted = tvp.IsDeleted
    FROM Classes AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO


ALTER PROCEDURE Students_GetAll
AS
    SELECT * FROM Students
GO


ALTER PROCEDURE Students_Insert
    @Id int = NULL,
	@FirstName nvarchar(MAX)  = NULL,
	@LastName nvarchar(MAX)  = NULL,
	@Gender nvarchar(MAX)  = NULL,
	@SubjectId int  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL,
	@MiddleName nvarchar(MAX)  = NULL
AS
   INSERT INTO Students(
		FirstName,
		LastName,
		Gender,
		SubjectId,
		CreatedAt,
		IsDeleted,
		MiddleName
        )
   VALUES (
		@FirstName,
		@LastName,
		@Gender,
		@SubjectId,
		@CreatedAt,
		@IsDeleted,
		@MiddleName
        )
   SELECT * FROM Students WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE Students_Update
	@Id int ,
	@FirstName nvarchar(MAX)  = NULL,
	@LastName nvarchar(MAX)  = NULL,
	@Gender nvarchar(MAX)  = NULL,
	@SubjectId int  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL,
	@MiddleName nvarchar(MAX)  = NULL
AS
   UPDATE Students
   SET 
		FirstName=@FirstName,
		LastName=@LastName,
		Gender=@Gender,
		SubjectId=@SubjectId,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted,
		MiddleName=@MiddleName
    WHERE Id = @Id
    SELECT * FROM Students WHERE Id = @Id
 GO
            

ALTER PROCEDURE Students_GetById
@Id INT
AS
   SELECT * FROM Students
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Students_DeleteById
    @Id INT
AS
    
    DELETE FROM Students
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_Students AS TABLE
(
	Id int,
	FirstName nvarchar(MAX),
	LastName nvarchar(MAX),
	Gender nvarchar(MAX),
	SubjectId int,
	CreatedAt datetime2,
	IsDeleted bit,
	MiddleName nvarchar(MAX)

)
GO


ALTER PROCEDURE Students_InsertMany
    @TVP TVP_Students READONLY
AS
   INSERT INTO Students(
		FirstName,
		LastName,
		Gender,
		SubjectId,
		CreatedAt,
		IsDeleted,
		MiddleName
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.FirstName,
		tvp.LastName,
		tvp.Gender,
		tvp.SubjectId,
		tvp.CreatedAt,
		tvp.IsDeleted,
		tvp.MiddleName
    FROM @TVP AS tvp
GO


ALTER PROCEDURE Students_UpdateMany
    @TVP TVP_Students READONLY
AS
   UPDATE tbl
   SET
		tbl.FirstName = tvp.FirstName,
		tbl.LastName = tvp.LastName,
		tbl.Gender = tvp.Gender,
		tbl.SubjectId = tvp.SubjectId,
		tbl.CreatedAt = tvp.CreatedAt,
		tbl.IsDeleted = tvp.IsDeleted,
		tbl.MiddleName = tvp.MiddleName
    FROM Students AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO


ALTER PROCEDURE Subjects_GetAll
AS
    SELECT * FROM Subjects
GO


ALTER PROCEDURE Subjects_Insert
    @Id int = NULL,
	@SubjectName nvarchar(MAX)  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO Subjects(
		SubjectName,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@SubjectName,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Subjects WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE Subjects_Update
	@Id int ,
	@SubjectName nvarchar(MAX)  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE Subjects
   SET 
		SubjectName=@SubjectName,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Subjects WHERE Id = @Id
 GO
            

ALTER PROCEDURE Subjects_GetById
@Id INT
AS
   SELECT * FROM Subjects
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Subjects_DeleteById
    @Id INT
AS
    
    DELETE FROM Subjects
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_Subjects AS TABLE
(
	Id int,
	SubjectName nvarchar(MAX),
	CreatedAt datetime2,
	IsDeleted bit

)
GO


ALTER PROCEDURE Subjects_InsertMany
    @TVP TVP_Subjects READONLY
AS
   INSERT INTO Subjects(
		SubjectName,
		CreatedAt,
		IsDeleted
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.SubjectName,
		tvp.CreatedAt,
		tvp.IsDeleted
    FROM @TVP AS tvp
GO


ALTER PROCEDURE Subjects_UpdateMany
    @TVP TVP_Subjects READONLY
AS
   UPDATE tbl
   SET
		tbl.SubjectName = tvp.SubjectName,
		tbl.CreatedAt = tvp.CreatedAt,
		tbl.IsDeleted = tvp.IsDeleted
    FROM Subjects AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO

