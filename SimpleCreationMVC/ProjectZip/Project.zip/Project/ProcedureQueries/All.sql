
ALTER PROCEDURE tblRefReactIconFamily_GetAllByFilters
    @Id int = NULL,
	@Description nvarchar(10)  = NULL,
	@IsDeleted bit  = NULL
AS
BEGIN
    SELECT *
    FROM tblRefReactIconFamily
    WHERE (@Id IS NULL OR Id = @Id) AND 
	(@Description IS NULL OR Description = @Description) AND 
	(@IsDeleted IS NULL OR IsDeleted = @IsDeleted)
END
GO


ALTER PROCEDURE tblRefReactIconFamily_Insert
    @Id int = NULL,
	@Description nvarchar(10)  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO tblRefReactIconFamily(
		Description,
		IsDeleted
        )
   VALUES (
		@Description,
		@IsDeleted
        )
   SELECT * FROM tblRefReactIconFamily WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE tblRefReactIconFamily_Update
	@Id int ,
	@Description nvarchar(10)  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE tblRefReactIconFamily
   SET 
		Description=@Description,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM tblRefReactIconFamily WHERE Id = @Id
 GO
            

ALTER PROCEDURE tblRefReactIconFamily_GetById
@Id INT
AS
   SELECT * FROM tblRefReactIconFamily
   WHERE Id = @Id
GO
            

ALTER PROCEDURE tblRefReactIconFamily_DeleteById
    @Id INT
AS
    
    DELETE FROM tblRefReactIconFamily
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_tblRefReactIconFamily AS TABLE
(
	Id int,
	Description nvarchar(10),
	IsDeleted bit

)
GO


ALTER PROCEDURE tblRefReactIconFamily_BulkInsert
    @TVP TVP_tblRefReactIconFamily READONLY
AS
    CREATE TABLE #Inserted (Id INT);

   INSERT INTO tblRefReactIconFamily(
		Description,
		IsDeleted
        )
   OUTPUT INSERTED.Id INTO #Inserted
   SELECT 
		tvp.Description,
		tvp.IsDeleted
    FROM @TVP AS tvp

    SELECT tbl.*
    FROM tblRefReactIconFamily tbl
    INNER JOIN #Inserted i ON tbl.Id = i.Id;
GO


ALTER PROCEDURE tblRefReactIconFamily_BulkUpdate
    @TVP TVP_tblRefReactIconFamily READONLY
AS
   UPDATE tbl
   SET
		tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIconFamily AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO


ALTER PROCEDURE tblRefReactIconFamily_BulkDeleteNotInTVP
    -- @FilterId INT,  -- change this filterId example (@EmployeeId)
    @TVP TVP_tblRefReactIconFamily READONLY
AS
    DELETE tbl
	FROM tblRefReactIconFamily AS tbl
	LEFT JOIN @TVP AS tvp ON tbl.Id = tvp.Id
	WHERE tvp.Id IS NULL
     --AND FilterId = @FilterId  -- change this example (EmployeeId = @EmployeeId)
       
GO

