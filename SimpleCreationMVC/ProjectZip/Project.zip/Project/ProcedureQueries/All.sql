
ALTER PROCEDURE Attendances_GetAll
AS
    SELECT * FROM Attendances
GO


ALTER PROCEDURE Attendances_Insert
    @Id int = NULL,
	@StudentId int ,
	@ClassId int ,
	@AttendanceDate datetime2 ,
	@ClassId1 int  = NULL,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   INSERT INTO Attendances(
		StudentId,
		ClassId,
		AttendanceDate,
		ClassId1,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@StudentId,
		@ClassId,
		@AttendanceDate,
		@ClassId1,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Attendances WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE Attendances_Update
	@Id int ,
	@StudentId int ,
	@ClassId int ,
	@AttendanceDate datetime2 ,
	@ClassId1 int  = NULL,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   UPDATE Attendances
   SET 
		StudentId=@StudentId,
		ClassId=@ClassId,
		AttendanceDate=@AttendanceDate,
		ClassId1=@ClassId1,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Attendances WHERE Id = @Id
 GO
            

ALTER PROCEDURE Attendances_GetById
@Id INT
AS
   SELECT * FROM Attendances
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Attendances_DeleteById
    @Id INT
AS
    
    DELETE FROM Attendances
    WHERE Id =  @Id
GO
            

ALTER PROCEDURE Classes_GetAll
AS
    SELECT * FROM Classes
GO


ALTER PROCEDURE Classes_Insert
    @Id int = NULL,
	@SubjectId int ,
	@ClassDate datetime2 ,
	@StartTime time ,
	@EndTime time ,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   INSERT INTO Classes(
		SubjectId,
		ClassDate,
		StartTime,
		EndTime,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@SubjectId,
		@ClassDate,
		@StartTime,
		@EndTime,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Classes WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE Classes_Update
	@Id int ,
	@SubjectId int ,
	@ClassDate datetime2 ,
	@StartTime time ,
	@EndTime time ,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   UPDATE Classes
   SET 
		SubjectId=@SubjectId,
		ClassDate=@ClassDate,
		StartTime=@StartTime,
		EndTime=@EndTime,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Classes WHERE Id = @Id
 GO
            

ALTER PROCEDURE Classes_GetById
@Id INT
AS
   SELECT * FROM Classes
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Classes_DeleteById
    @Id INT
AS
    
    DELETE FROM Classes
    WHERE Id =  @Id
GO
            

ALTER PROCEDURE Students_GetAll
AS
    SELECT * FROM Students
GO


ALTER PROCEDURE Students_Insert
    @Id int = NULL,
	@FirstName nvarchar(MAX) ,
	@LastName nvarchar(MAX) ,
	@Gender nvarchar(MAX)  = NULL,
	@SubjectId int  = NULL,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   INSERT INTO Students(
		FirstName,
		LastName,
		Gender,
		SubjectId,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@FirstName,
		@LastName,
		@Gender,
		@SubjectId,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Students WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE Students_Update
	@Id int ,
	@FirstName nvarchar(MAX) ,
	@LastName nvarchar(MAX) ,
	@Gender nvarchar(MAX)  = NULL,
	@SubjectId int  = NULL,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   UPDATE Students
   SET 
		FirstName=@FirstName,
		LastName=@LastName,
		Gender=@Gender,
		SubjectId=@SubjectId,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Students WHERE Id = @Id
 GO
            

ALTER PROCEDURE Students_GetById
@Id INT
AS
   SELECT * FROM Students
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Students_DeleteById
    @Id INT
AS
    
    DELETE FROM Students
    WHERE Id =  @Id
GO
            

ALTER PROCEDURE Subjects_GetAll
AS
    SELECT * FROM Subjects
GO


ALTER PROCEDURE Subjects_Insert
    @Id int = NULL,
	@SubjectName nvarchar(MAX)  = NULL,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   INSERT INTO Subjects(
		SubjectName,
		CreatedAt,
		IsDeleted
        )
   VALUES (
		@SubjectName,
		@CreatedAt,
		@IsDeleted
        )
   SELECT * FROM Subjects WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE Subjects_Update
	@Id int ,
	@SubjectName nvarchar(MAX)  = NULL,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   UPDATE Subjects
   SET 
		SubjectName=@SubjectName,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Subjects WHERE Id = @Id
 GO
            

ALTER PROCEDURE Subjects_GetById
@Id INT
AS
   SELECT * FROM Subjects
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Subjects_DeleteById
    @Id INT
AS
    
    DELETE FROM Subjects
    WHERE Id =  @Id
GO
            
