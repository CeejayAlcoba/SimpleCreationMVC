
CREATE PROCEDURE tblRefReactIcon_GetAllByFilters
    @Id int = NULL,
	@ReactIconFamilyId int  = NULL,
	@Description nvarchar(MAX)  = NULL,
	@IsDeleted bit  = NULL
AS
BEGIN
    SELECT *
    FROM tblRefReactIcon
    WHERE (@Id IS NULL OR Id = @Id) AND 
	(@ReactIconFamilyId IS NULL OR ReactIconFamilyId = @ReactIconFamilyId) AND 
	(@Description IS NULL OR Description = @Description) AND 
	(@IsDeleted IS NULL OR IsDeleted = @IsDeleted)
END
GO


CREATE PROCEDURE tblRefReactIcon_Insert
    @Id int = NULL,
	@ReactIconFamilyId int  = NULL,
	@Description nvarchar(MAX)  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO tblRefReactIcon(
		ReactIconFamilyId,
		Description,
		IsDeleted
        )
   VALUES (
		@ReactIconFamilyId,
		@Description,
		@IsDeleted
        )
   SELECT * FROM tblRefReactIcon WHERE Id = SCOPE_IDENTITY()
GO
            

CREATE PROCEDURE tblRefReactIcon_Update
	@Id int ,
	@ReactIconFamilyId int  = NULL,
	@Description nvarchar(MAX)  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE tblRefReactIcon
   SET 
		ReactIconFamilyId=@ReactIconFamilyId,
		Description=@Description,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM tblRefReactIcon WHERE Id = @Id
 GO
            

CREATE PROCEDURE tblRefReactIcon_GetById
@Id INT
AS
   SELECT * FROM tblRefReactIcon
   WHERE Id = @Id
GO
            

CREATE PROCEDURE tblRefReactIcon_DeleteById
    @Id INT
AS
    
    DELETE FROM tblRefReactIcon
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_tblRefReactIcon AS TABLE
(
	Id int,
	ReactIconFamilyId int,
	Description nvarchar(MAX),
	IsDeleted bit

)
GO


CREATE PROCEDURE tblRefReactIcon_BulkInsert
    @TVP TVP_tblRefReactIcon READONLY
AS
   INSERT INTO tblRefReactIcon(
		ReactIconFamilyId,
		Description,
		IsDeleted
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.ReactIconFamilyId,
		tvp.Description,
		tvp.IsDeleted
    FROM @TVP AS tvp
GO


CREATE PROCEDURE tblRefReactIcon_BulkUpdate
    @TVP TVP_tblRefReactIcon READONLY
AS
   UPDATE tbl
   SET
		tbl.ReactIconFamilyId = tvp.ReactIconFamilyId,
		tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIcon AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO


CREATE PROCEDURE tblRefReactIcon_BulkUpsert
    @TVP TVP_tblRefReactIcon READONLY
AS
BEGIN
    -- Insert rows where Id is NULL or 0
    INSERT INTO tblRefReactIcon (ReactIconFamilyId, Description, IsDeleted)
    SELECT tvp.ReactIconFamilyId, tvp.Description, tvp.IsDeleted
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;

    -- Update rows where Id matches
    UPDATE tbl
    SET tbl.ReactIconFamilyId = tvp.ReactIconFamilyId,
		tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIcon AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    SELECT * FROM @TVP
END
GO


CREATE PROCEDURE tblRefReactIcon_BulkMerge
    @TVP TVP_tblRefReactIcon READONLY
    --@ForeignIdFilter INT (this is example for filtering deletes)
AS
BEGIN
    -- 1️ Update rows where Id matches
    UPDATE tbl
    SET tbl.ReactIconFamilyId = tvp.ReactIconFamilyId,
		tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIcon AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    -- 2️ Delete rows in target that are NOT in TVP
    DELETE tbl
    FROM tblRefReactIcon AS tbl
    LEFT JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE tvp.Id IS NULL;
    --AND tbl.ForeignIdFilter = @ForeignIdFilter (please change this if necessary)

    -- 3️ Insert rows where Id is NULL or 0
    INSERT INTO tblRefReactIcon (ReactIconFamilyId, Description, IsDeleted)
    SELECT tvp.ReactIconFamilyId, tvp.Description, tvp.IsDeleted
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;

    SELECT * FROM @TVP
END
GO


CREATE PROCEDURE tblRefReactIconFamily_GetAllByFilters
    @Id int = NULL,
	@Description nvarchar(10)  = NULL,
	@IsDeleted bit  = NULL
AS
BEGIN
    SELECT *
    FROM tblRefReactIconFamily
    WHERE (@Id IS NULL OR Id = @Id) AND 
	(@Description IS NULL OR Description = @Description) AND 
	(@IsDeleted IS NULL OR IsDeleted = @IsDeleted)
END
GO


CREATE PROCEDURE tblRefReactIconFamily_Insert
    @Id int = NULL,
	@Description nvarchar(10)  = NULL,
	@IsDeleted bit  = NULL
AS
   INSERT INTO tblRefReactIconFamily(
		Description,
		IsDeleted
        )
   VALUES (
		@Description,
		@IsDeleted
        )
   SELECT * FROM tblRefReactIconFamily WHERE Id = SCOPE_IDENTITY()
GO
            

CREATE PROCEDURE tblRefReactIconFamily_Update
	@Id int ,
	@Description nvarchar(10)  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE tblRefReactIconFamily
   SET 
		Description=@Description,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM tblRefReactIconFamily WHERE Id = @Id
 GO
            

CREATE PROCEDURE tblRefReactIconFamily_GetById
@Id INT
AS
   SELECT * FROM tblRefReactIconFamily
   WHERE Id = @Id
GO
            

CREATE PROCEDURE tblRefReactIconFamily_DeleteById
    @Id INT
AS
    
    DELETE FROM tblRefReactIconFamily
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_tblRefReactIconFamily AS TABLE
(
	Id int,
	Description nvarchar(10),
	IsDeleted bit

)
GO


CREATE PROCEDURE tblRefReactIconFamily_BulkInsert
    @TVP TVP_tblRefReactIconFamily READONLY
AS
   INSERT INTO tblRefReactIconFamily(
		Description,
		IsDeleted
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.Description,
		tvp.IsDeleted
    FROM @TVP AS tvp
GO


CREATE PROCEDURE tblRefReactIconFamily_BulkUpdate
    @TVP TVP_tblRefReactIconFamily READONLY
AS
   UPDATE tbl
   SET
		tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIconFamily AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO


CREATE PROCEDURE tblRefReactIconFamily_BulkUpsert
    @TVP TVP_tblRefReactIconFamily READONLY
AS
BEGIN
    -- Insert rows where Id is NULL or 0
    INSERT INTO tblRefReactIconFamily (Description, IsDeleted)
    SELECT tvp.Description, tvp.IsDeleted
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;

    -- Update rows where Id matches
    UPDATE tbl
    SET tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIconFamily AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    SELECT * FROM @TVP
END
GO


CREATE PROCEDURE tblRefReactIconFamily_BulkMerge
    @TVP TVP_tblRefReactIconFamily READONLY
    --@ForeignIdFilter INT (this is example for filtering deletes)
AS
BEGIN
    -- 1️ Update rows where Id matches
    UPDATE tbl
    SET tbl.Description = tvp.Description,
		tbl.IsDeleted = tvp.IsDeleted
    FROM tblRefReactIconFamily AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    -- 2️ Delete rows in target that are NOT in TVP
    DELETE tbl
    FROM tblRefReactIconFamily AS tbl
    LEFT JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE tvp.Id IS NULL;
    --AND tbl.ForeignIdFilter = @ForeignIdFilter (please change this if necessary)

    -- 3️ Insert rows where Id is NULL or 0
    INSERT INTO tblRefReactIconFamily (Description, IsDeleted)
    SELECT tvp.Description, tvp.IsDeleted
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;

    SELECT * FROM @TVP
END
GO

