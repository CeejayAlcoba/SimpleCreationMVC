
ALTER PROCEDURE tblRefRole_GetAll
AS
    SELECT * FROM tblRefRole
GO


ALTER PROCEDURE tblRefRole_Insert
    @Id int = NULL,
	@Description nvarchar(MAX)  = NULL
AS
   INSERT INTO tblRefRole(
		Description
        )
   VALUES (
		@Description
        )
   SELECT * FROM tblRefRole WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE tblRefRole_Update
	@Id int ,
	@Description nvarchar(MAX)  = NULL
AS
   UPDATE tblRefRole
   SET 
		Description=@Description
    WHERE Id = @Id
    SELECT * FROM tblRefRole WHERE Id = @Id
 GO
            

ALTER PROCEDURE tblRefRole_GetById
@Id INT
AS
   SELECT * FROM tblRefRole
   WHERE Id = @Id
GO
            

ALTER PROCEDURE tblRefRole_DeleteById
    @Id INT
AS
    
    DELETE FROM tblRefRole
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_tblRefRole AS TABLE
(
	Id int,
	Description nvarchar(MAX)

)
GO


ALTER PROCEDURE tblRefRole_InsertMany
    @TVP TVP_tblRefRole READONLY
AS
   INSERT INTO tblRefRole(
		Description
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.Description
    FROM @TVP AS tvp
GO


ALTER PROCEDURE tblRefRole_UpdateMany
    @TVP TVP_tblRefRole READONLY
AS
   UPDATE tbl
   SET
		tbl.Description = tvp.Description
    FROM tblRefRole AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO

