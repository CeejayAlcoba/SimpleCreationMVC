
ALTER PROCEDURE Tasktbl_GetAll
AS
    SELECT * FROM Tasktbl
GO


ALTER PROCEDURE Tasktbl_Insert
    @Id int = NULL,
	@Description nvarchar(MAX)  = NULL,
	@Title nvarchar(MAX)  = NULL
AS
   INSERT INTO Tasktbl(
		Description,
		Title
        )
   VALUES (
		@Description,
		@Title
        )
   SELECT * FROM Tasktbl WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE Tasktbl_Update
	@Id int ,
	@Description nvarchar(MAX)  = NULL,
	@Title nvarchar(MAX)  = NULL
AS
   UPDATE Tasktbl
   SET 
		Description=@Description,
		Title=@Title
    WHERE Id = @Id
    SELECT * FROM Tasktbl WHERE Id = @Id
 GO
            

ALTER PROCEDURE Tasktbl_GetById
@Id INT
AS
   SELECT * FROM Tasktbl
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Tasktbl_DeleteById
    @Id INT
AS
    
    DELETE FROM Tasktbl
    OUTPUT deleted.*
    WHERE Id =  @Id
GO
            

CREATE TYPE TVP_Tasktbl AS TABLE
(
	Id int,
	Description nvarchar(MAX),
	Title nvarchar(MAX)

)
GO


ALTER PROCEDURE Tasktbl_BulkInsert
    @TVP TVP_Tasktbl READONLY
AS
   INSERT INTO Tasktbl(
		Description,
		Title
        )
   OUTPUT INSERTED.*
   SELECT 
		tvp.Description,
		tvp.Title
    FROM @TVP AS tvp
GO


ALTER PROCEDURE Tasktbl_BulkUpdate
    @TVP TVP_Tasktbl READONLY
AS
   UPDATE tbl
   SET
		tbl.Description = tvp.Description,
		tbl.Title = tvp.Title
    FROM Tasktbl AS tbl
    JOIN @TVP AS tvp ON tvp.Id = tbl.Id
    
    SELECT * FROM @TVP 
GO


ALTER PROCEDURE Tasktbl_BulkUpsert
    @TVP TVP_Tasktbl READONLY
AS
BEGIN
    -- Insert rows where Id is NULL or 0
    INSERT INTO Tasktbl (Description, Title)
    SELECT tvp.Description, tvp.Title
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;

    -- Update rows where Id matches
    UPDATE tbl
    SET tbl.Description = tvp.Description,
		tbl.Title = tvp.Title
    FROM Tasktbl AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    SELECT * FROM @TVP
END
GO


ALTER PROCEDURE Tasktbl_BulkMerge
    @TVP TVP_Tasktbl READONLY
    --@ForeignIdFilter INT (this is example for filtering deletes)
AS
BEGIN
    -- 1️ Update rows where Id matches
    UPDATE tbl
    SET tbl.Description = tvp.Description,
		tbl.Title = tvp.Title
    FROM Tasktbl AS tbl
    INNER JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE ISNULL(tvp.Id, 0) > 0;

    -- 2️ Delete rows in target that are NOT in TVP
    DELETE tbl
    FROM Tasktbl AS tbl
    LEFT JOIN @TVP AS tvp ON tbl.Id = tvp.Id
    WHERE tvp.Id IS NULL;
    --AND tbl.ForeignIdFilter = @ForeignIdFilter (please change this if necessary)

    -- 3️ Insert rows where Id is NULL or 0
    INSERT INTO Tasktbl (Description, Title)
    SELECT tvp.Description, tvp.Title
    FROM @TVP AS tvp
    WHERE ISNULL(tvp.Id, 0) = 0;

    SELECT * FROM @TVP
END
GO

