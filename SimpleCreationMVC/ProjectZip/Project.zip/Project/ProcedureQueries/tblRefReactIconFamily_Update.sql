
CREATE PROCEDURE tblRefReactIconFamily_Update
	@Id int ,
	@Description nvarchar(10)  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE tblRefReactIconFamily
   SET 
		Description=@Description,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM tblRefReactIconFamily WHERE Id = @Id
 GO
            