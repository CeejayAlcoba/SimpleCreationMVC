
ALTER PROCEDURE Classes_GetById
@Id INT
AS
   SELECT * FROM Classes
   WHERE Id = @Id
GO
            