
ALTER PROCEDURE Attendances_Update
	@Id int ,
	@StudentId int  = NULL,
	@ClassId int  = NULL,
	@AttendanceDate datetime2  = NULL,
	@CreatedAt datetime2  = NULL,
	@IsDeleted bit  = NULL
AS
   UPDATE Attendances
   SET 
		StudentId=@StudentId,
		ClassId=@ClassId,
		AttendanceDate=@AttendanceDate,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Attendances WHERE Id = @Id
 GO
            