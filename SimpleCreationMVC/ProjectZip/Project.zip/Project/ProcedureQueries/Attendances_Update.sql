
ALTER PROCEDURE Attendances_Update
	@Id int ,
	@StudentId int ,
	@ClassId int ,
	@AttendanceDate datetime2 ,
	@ClassId1 int  = NULL,
	@CreatedAt datetime2 ,
	@IsDeleted bit 
AS
   UPDATE Attendances
   SET 
		StudentId=@StudentId,
		ClassId=@ClassId,
		AttendanceDate=@AttendanceDate,
		ClassId1=@ClassId1,
		CreatedAt=@CreatedAt,
		IsDeleted=@IsDeleted
    WHERE Id = @Id
    SELECT * FROM Attendances WHERE Id = @Id
 GO
            