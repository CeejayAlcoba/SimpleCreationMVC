
             ALTER PROCEDURE tblEmployeeDeptCategoryPositionAndSalaryMapping_GetById
             @Id INT
             AS
                SELECT * FROM tblEmployeeDeptCategoryPositionAndSalaryMapping
                WHERE Id = @Id
             GO
            