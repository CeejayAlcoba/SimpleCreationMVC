
             ALTER PROCEDURE tblRefZIPCode_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefZIPCode
                WHERE Id =  @Id
             GO
            