
             ALTER PROCEDURE tblRefEmploymentCategoryType_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefEmploymentCategoryType
                WHERE Id =  @Id
             GO
            