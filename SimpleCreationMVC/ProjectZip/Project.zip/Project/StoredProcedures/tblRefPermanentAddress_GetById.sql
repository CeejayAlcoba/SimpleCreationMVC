
             ALTER PROCEDURE tblRefPermanentAddress_GetById
             @Id INT
             AS
                SELECT * FROM tblRefPermanentAddress
                WHERE Id = @Id
             GO
            