
ALTER PROCEDURE Developers_GetAll
AS
    SELECT * FROM Developers
GO
