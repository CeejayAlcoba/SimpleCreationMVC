
ALTER PROCEDURE Projects_GetById
@Id INT
AS
   SELECT * FROM Projects
   WHERE Id = @Id
GO
            