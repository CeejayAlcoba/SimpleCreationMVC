
             ALTER PROCEDURE tblRefGender_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefGender
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefGender WHERE Id = @Id
             GO
            