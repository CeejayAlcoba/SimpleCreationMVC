
             ALTER PROCEDURE tblPromotionHistoryLog_GetAll
             AS
                SELECT * FROM tblPromotionHistoryLog
             GO
            