
             ALTER PROCEDURE tblSalary_GetAll
             AS
                SELECT * FROM tblSalary
             GO
            