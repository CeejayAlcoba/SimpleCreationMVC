
             ALTER PROCEDURE tblEducationalData_GetById
             @Id INT
             AS
                SELECT * FROM tblEducationalData
                WHERE Id = @Id
             GO
            