
             ALTER PROCEDURE tblRefPermanentAddress_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@BarangayId int  = NULL,
		@MunicipalityId int  = NULL,
		@ProvinceId int  = NULL,
		@CountryId int  = NULL,
		@ZIPCodeId int  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefPermanentAddress(EmployeeId,BarangayId,MunicipalityId,ProvinceId,CountryId,ZIPCodeId,IsDeleted)
                VALUES (@EmployeeId,@BarangayId,@MunicipalityId,@ProvinceId,@CountryId,@ZIPCodeId,@IsDeleted)
                SELECT * FROM tblRefPermanentAddress WHERE Id = SCOPE_IDENTITY()
             GO
            