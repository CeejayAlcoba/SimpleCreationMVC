
             ALTER PROCEDURE tblPromotionHistoryLog_GetById
             @Id INT
             AS
                SELECT * FROM tblPromotionHistoryLog
                WHERE Id = @Id
             GO
            