
             ALTER PROCEDURE tblRefProvince_GetById
             @Id INT
             AS
                SELECT * FROM tblRefProvince
                WHERE Id = @Id
             GO
            