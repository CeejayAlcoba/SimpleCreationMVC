
             ALTER PROCEDURE tblRefAppointment_Insert
             @Id int = NULL,
             	@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefAppointment(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefAppointment WHERE Id = SCOPE_IDENTITY()
             GO
            