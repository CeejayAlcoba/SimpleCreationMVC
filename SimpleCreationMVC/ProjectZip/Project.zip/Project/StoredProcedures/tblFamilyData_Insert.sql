
             ALTER PROCEDURE tblFamilyData_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@MotherMaidenName nvarchar(MAX)  = NULL,
		@FatherName nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                INSERT INTO tblFamilyData(EmployeeId,MotherMaidenName,FatherName,IsDeleted,ApplicantId)
                VALUES (@EmployeeId,@MotherMaidenName,@FatherName,@IsDeleted,@ApplicantId)
                SELECT * FROM tblFamilyData WHERE Id = SCOPE_IDENTITY()
             GO
            