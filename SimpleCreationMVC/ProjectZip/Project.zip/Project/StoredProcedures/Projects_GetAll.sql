
ALTER PROCEDURE Projects_GetAll
AS
    SELECT * FROM Projects
GO
