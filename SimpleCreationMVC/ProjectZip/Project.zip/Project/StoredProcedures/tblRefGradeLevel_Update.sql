
             ALTER PROCEDURE tblRefGradeLevel_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefGradeLevel
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefGradeLevel WHERE Id = @Id
             GO
            