
             ALTER PROCEDURE tblRefSalaryType_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefSalaryType
                WHERE Id =  @Id
             GO
            