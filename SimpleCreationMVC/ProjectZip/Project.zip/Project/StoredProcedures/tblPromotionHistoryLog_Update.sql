
             ALTER PROCEDURE tblPromotionHistoryLog_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@PositionId int  = NULL,
		@DepartmentId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL,
		@PromotedDate date  = NULL
             AS
                UPDATE tblPromotionHistoryLog
                SET EmployeeId=@EmployeeId,PositionId=@PositionId,DepartmentId=@DepartmentId,AlternativePosition=@AlternativePosition,PromotedDate=@PromotedDate
                WHERE Id = @Id
                SELECT * FROM tblPromotionHistoryLog WHERE Id = @Id
             GO
            