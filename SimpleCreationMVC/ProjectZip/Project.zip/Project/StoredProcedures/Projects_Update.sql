
CREATE PROCEDURE Projects_Update
	@Id int ,
	@Description nvarchar(MAX)  = NULL
AS
   UPDATE Projects
   SET 
		Description=@Description
    WHERE Id = @Id
    SELECT * FROM Projects WHERE Id = @Id
 GO
            