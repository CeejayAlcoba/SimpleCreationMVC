
             ALTER PROCEDURE tblSalary_DeleteById
                @Id INT
             AS
                DELETE FROM tblSalary
                WHERE Id =  @Id
             GO
            