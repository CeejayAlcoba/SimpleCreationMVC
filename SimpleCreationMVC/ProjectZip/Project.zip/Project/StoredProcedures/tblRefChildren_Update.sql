
             ALTER PROCEDURE tblRefChildren_Update
             	@Id int ,
		@FamilyId int  = NULL,
		@Name nvarchar(MAX)  = NULL,
		@GradeLevelId int  = NULL,
		@IsDeleted bit  = NULL,
		@Birthday date  = NULL
             AS
                UPDATE tblRefChildren
                SET FamilyId=@FamilyId,Name=@Name,GradeLevelId=@GradeLevelId,IsDeleted=@IsDeleted,Birthday=@Birthday
                WHERE Id = @Id
                SELECT * FROM tblRefChildren WHERE Id = @Id
             GO
            