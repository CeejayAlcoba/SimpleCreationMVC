
             ALTER PROCEDURE tblRefDepartment_GetById
             @Id INT
             AS
                SELECT * FROM tblRefDepartment
                WHERE Id = @Id
             GO
            