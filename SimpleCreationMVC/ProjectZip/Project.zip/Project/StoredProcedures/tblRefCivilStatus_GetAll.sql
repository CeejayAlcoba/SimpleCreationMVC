
             ALTER PROCEDURE tblRefCivilStatus_GetAll
             AS
                SELECT * FROM tblRefCivilStatus
             GO
            