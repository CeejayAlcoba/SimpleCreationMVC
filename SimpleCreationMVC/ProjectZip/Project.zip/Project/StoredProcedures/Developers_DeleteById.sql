
ALTER PROCEDURE Developers_DeleteById
    @Id INT
AS
    DELETE FROM Developers
    WHERE Id =  @Id
GO
            