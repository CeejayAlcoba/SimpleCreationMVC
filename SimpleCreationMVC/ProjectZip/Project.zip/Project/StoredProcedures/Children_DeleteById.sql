
CREATE PROCEDURE Children_DeleteById
    @Id INT
AS
    DELETE FROM Children
    WHERE Id =  @Id
GO
            