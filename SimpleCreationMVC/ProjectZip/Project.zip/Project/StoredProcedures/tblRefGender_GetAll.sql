
             ALTER PROCEDURE tblRefGender_GetAll
             AS
                SELECT * FROM tblRefGender
             GO
            