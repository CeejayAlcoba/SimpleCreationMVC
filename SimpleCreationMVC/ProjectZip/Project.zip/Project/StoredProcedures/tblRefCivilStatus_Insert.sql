
             ALTER PROCEDURE tblRefCivilStatus_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefCivilStatus(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefCivilStatus WHERE Id = SCOPE_IDENTITY()
             GO
            