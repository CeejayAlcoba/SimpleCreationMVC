
             ALTER PROCEDURE tblRefEmploymentType_Insert
             @Id int = NULL,
             	@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefEmploymentType(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefEmploymentType WHERE Id = SCOPE_IDENTITY()
             GO
            