
             ALTER PROCEDURE tblRefCountry_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefCountry
                WHERE Id =  @Id
             GO
            