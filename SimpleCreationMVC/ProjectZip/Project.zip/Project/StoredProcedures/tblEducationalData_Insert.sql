
             ALTER PROCEDURE tblEducationalData_Insert
             @Id int = NULL,
             	@EmployeeId int  = NULL,
		@EducationalLevelId int  = NULL,
		@School nvarchar(MAX)  = NULL,
		@YearGraduate nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                INSERT INTO tblEducationalData(EmployeeId,EducationalLevelId,School,YearGraduate,IsDeleted,ApplicantId)
                VALUES (@EmployeeId,@EducationalLevelId,@School,@YearGraduate,@IsDeleted,@ApplicantId)
                SELECT * FROM tblEducationalData WHERE Id = SCOPE_IDENTITY()
             GO
            