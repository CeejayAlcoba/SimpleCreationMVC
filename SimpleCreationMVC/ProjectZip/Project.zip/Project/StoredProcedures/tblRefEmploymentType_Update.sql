
             ALTER PROCEDURE tblRefEmploymentType_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefEmploymentType
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefEmploymentType WHERE Id = @Id
             GO
            