
             ALTER PROCEDURE tblRefGradeLevel_GetById
             @Id INT
             AS
                SELECT * FROM tblRefGradeLevel
                WHERE Id = @Id
             GO
            