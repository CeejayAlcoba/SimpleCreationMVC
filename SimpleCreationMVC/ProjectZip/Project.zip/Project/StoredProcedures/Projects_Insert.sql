
CREATE PROCEDURE Projects_Insert
    @Id int = NULL,
	@Description nvarchar(MAX)  = NULL
AS
   INSERT INTO Projects(
		Description
        )
   VALUES (
		@Description
        )
   SELECT * FROM Projects WHERE Id = SCOPE_IDENTITY()
GO
            