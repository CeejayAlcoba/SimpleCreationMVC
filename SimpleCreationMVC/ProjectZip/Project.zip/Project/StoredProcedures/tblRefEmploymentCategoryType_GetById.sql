
             ALTER PROCEDURE tblRefEmploymentCategoryType_GetById
             @Id INT
             AS
                SELECT * FROM tblRefEmploymentCategoryType
                WHERE Id = @Id
             GO
            