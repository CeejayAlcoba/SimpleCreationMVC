
             ALTER PROCEDURE tblRefBarangay_GetById
             @Id INT
             AS
                SELECT * FROM tblRefBarangay
                WHERE Id = @Id
             GO
            