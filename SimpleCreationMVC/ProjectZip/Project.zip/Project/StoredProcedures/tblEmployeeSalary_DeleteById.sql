
             ALTER PROCEDURE tblEmployeeSalary_DeleteById
                @Id INT
             AS
                DELETE FROM tblEmployeeSalary
                WHERE Id =  @Id
             GO
            