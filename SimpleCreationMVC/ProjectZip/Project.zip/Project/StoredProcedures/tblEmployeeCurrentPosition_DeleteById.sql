
             ALTER PROCEDURE tblEmployeeCurrentPosition_DeleteById
                @Id INT
             AS
                DELETE FROM tblEmployeeCurrentPosition
                WHERE Id =  @Id
             GO
            