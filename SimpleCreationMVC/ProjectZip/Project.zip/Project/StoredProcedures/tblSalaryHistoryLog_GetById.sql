
             ALTER PROCEDURE tblSalaryHistoryLog_GetById
             @Id INT
             AS
                SELECT * FROM tblSalaryHistoryLog
                WHERE Id = @Id
             GO
            