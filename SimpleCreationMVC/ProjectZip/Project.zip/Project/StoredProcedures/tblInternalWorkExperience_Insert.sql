
             ALTER PROCEDURE tblInternalWorkExperience_Insert
             	@Id int ,
		@Position nvarchar(MAX)  = NULL,
		@Department nvarchar(MAX)  = NULL,
		@EffectivityDate datetime  = NULL,
		@InternalCompanyId int  = NULL,
		@JobLevelId int  = NULL,
		@AppointmentId int  = NULL,
		@EmployeeId int  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                INSERT INTO tblInternalWorkExperience(Position,Department,EffectivityDate,InternalCompanyId,JobLevelId,AppointmentId,EmployeeId,IsDeleted,ApplicantId)
                VALUES (@Position,@Department,@EffectivityDate,@InternalCompanyId,@JobLevelId,@AppointmentId,@EmployeeId,@IsDeleted,@ApplicantId)
                SELECT * FROM tblInternalWorkExperience WHERE Id = SCOPE_IDENTITY()
             GO
            