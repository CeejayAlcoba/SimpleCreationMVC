
             ALTER PROCEDURE tblRefReligion_GetAll
             AS
                SELECT * FROM tblRefReligion
             GO
            