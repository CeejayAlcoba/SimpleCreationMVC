
CREATE PROCEDURE Children_GetById
@Id INT
AS
   SELECT * FROM Children
   WHERE Id = @Id
GO
            