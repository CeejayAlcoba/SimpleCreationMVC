
             ALTER PROCEDURE tblInternalWorkExperience_GetById
             @Id INT
             AS
                SELECT * FROM tblInternalWorkExperience
                WHERE Id = @Id
             GO
            