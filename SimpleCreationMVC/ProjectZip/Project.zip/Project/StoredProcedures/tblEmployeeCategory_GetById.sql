
             ALTER PROCEDURE tblEmployeeCategory_GetById
             @Id INT
             AS
                SELECT * FROM tblEmployeeCategory
                WHERE Id = @Id
             GO
            