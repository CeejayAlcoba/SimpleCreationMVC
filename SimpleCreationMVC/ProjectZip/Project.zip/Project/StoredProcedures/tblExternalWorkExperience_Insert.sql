
             ALTER PROCEDURE tblExternalWorkExperience_Insert
             @Id int = NULL,
             	@Position nvarchar(MAX)  = NULL,
		@Employer nvarchar(MAX)  = NULL,
		@LengthOfService nvarchar(MAX)  = NULL,
		@ReasonOfLeaving nvarchar(MAX)  = NULL,
		@EmployeeId int  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                INSERT INTO tblExternalWorkExperience(Position,Employer,LengthOfService,ReasonOfLeaving,EmployeeId,IsDeleted,ApplicantId)
                VALUES (@Position,@Employer,@LengthOfService,@ReasonOfLeaving,@EmployeeId,@IsDeleted,@ApplicantId)
                SELECT * FROM tblExternalWorkExperience WHERE Id = SCOPE_IDENTITY()
             GO
            