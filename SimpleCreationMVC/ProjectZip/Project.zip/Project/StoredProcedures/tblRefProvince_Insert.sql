
             ALTER PROCEDURE tblRefProvince_Insert
             @Id int = NULL,
             	@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@CountryId int  = NULL
             AS
                INSERT INTO tblRefProvince(Description,IsDeleted,CountryId)
                VALUES (@Description,@IsDeleted,@CountryId)
                SELECT * FROM tblRefProvince WHERE Id = SCOPE_IDENTITY()
             GO
            