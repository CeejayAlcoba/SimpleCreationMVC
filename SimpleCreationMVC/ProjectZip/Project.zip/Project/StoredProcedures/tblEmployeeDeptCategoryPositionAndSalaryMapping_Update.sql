
             ALTER PROCEDURE tblEmployeeDeptCategoryPositionAndSalaryMapping_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@DepartmentId int  = NULL,
		@EmploymentTypeId int  = NULL,
		@EmployeeCurrentPositionId int  = NULL,
		@EmployeeSalaryId int  = NULL
             AS
                UPDATE tblEmployeeDeptCategoryPositionAndSalaryMapping
                SET EmployeeId=@EmployeeId,DepartmentId=@DepartmentId,EmploymentTypeId=@EmploymentTypeId,EmployeeCurrentPositionId=@EmployeeCurrentPositionId,EmployeeSalaryId=@EmployeeSalaryId
                WHERE Id = @Id
                SELECT * FROM tblEmployeeDeptCategoryPositionAndSalaryMapping WHERE Id = @Id
             GO
            