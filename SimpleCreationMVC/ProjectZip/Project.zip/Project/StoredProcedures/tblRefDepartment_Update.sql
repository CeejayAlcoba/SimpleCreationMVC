
             ALTER PROCEDURE tblRefDepartment_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@DepartmentCategoryId int  = NULL
             AS
                UPDATE tblRefDepartment
                SET Description=@Description,IsDeleted=@IsDeleted,DepartmentCategoryId=@DepartmentCategoryId
                WHERE Id = @Id
                SELECT * FROM tblRefDepartment WHERE Id = @Id
             GO
            