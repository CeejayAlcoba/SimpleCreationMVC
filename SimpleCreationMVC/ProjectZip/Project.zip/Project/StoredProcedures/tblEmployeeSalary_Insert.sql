
             ALTER PROCEDURE tblEmployeeSalary_Insert
             @Id int = NULL,
             	@Amount float  = NULL,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@Date datetime  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblEmployeeSalary(Amount,EmployeeId,SalaryTypeId,Date,IsDeleted)
                VALUES (@Amount,@EmployeeId,@SalaryTypeId,@Date,@IsDeleted)
                SELECT * FROM tblEmployeeSalary WHERE Id = SCOPE_IDENTITY()
             GO
            