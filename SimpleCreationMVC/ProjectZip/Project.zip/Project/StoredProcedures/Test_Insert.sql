
CREATE PROCEDURE Test_Insert
    @Id int = NULL,
	@description nvarchar(MAX)  = NULL
AS
   INSERT INTO Test(
		description
        )
   VALUES (
		@description
        )
   SELECT * FROM Test WHERE Id = SCOPE_IDENTITY()
GO
            