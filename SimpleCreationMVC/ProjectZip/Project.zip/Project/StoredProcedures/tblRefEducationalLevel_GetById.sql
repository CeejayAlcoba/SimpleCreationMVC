
             ALTER PROCEDURE tblRefEducationalLevel_GetById
             @Id INT
             AS
                SELECT * FROM tblRefEducationalLevel
                WHERE Id = @Id
             GO
            