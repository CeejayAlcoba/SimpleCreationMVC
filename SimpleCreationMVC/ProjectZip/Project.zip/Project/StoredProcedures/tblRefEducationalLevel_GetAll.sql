
             ALTER PROCEDURE tblRefEducationalLevel_GetAll
             AS
                SELECT * FROM tblRefEducationalLevel
             GO
            