
             ALTER PROCEDURE tblRefGradeLevel_GetAll
             AS
                SELECT * FROM tblRefGradeLevel
             GO
            