
             ALTER PROCEDURE tblRefCountry_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@Code nvarchar(10)  = NULL
             AS
                UPDATE tblRefCountry
                SET Description=@Description,IsDeleted=@IsDeleted,Code=@Code
                WHERE Id = @Id
                SELECT * FROM tblRefCountry WHERE Id = @Id
             GO
            