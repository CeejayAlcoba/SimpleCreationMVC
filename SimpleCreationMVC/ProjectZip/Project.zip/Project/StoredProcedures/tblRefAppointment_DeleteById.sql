
             ALTER PROCEDURE tblRefAppointment_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefAppointment
                WHERE Id =  @Id
             GO
            