
             ALTER PROCEDURE tblRefSalaryType_GetAll
             AS
                SELECT * FROM tblRefSalaryType
             GO
            