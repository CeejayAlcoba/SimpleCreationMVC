
             ALTER PROCEDURE tblRefBarangay_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@MunicipalityId int  = NULL
             AS
                UPDATE tblRefBarangay
                SET Description=@Description,IsDeleted=@IsDeleted,MunicipalityId=@MunicipalityId
                WHERE Id = @Id
                SELECT * FROM tblRefBarangay WHERE Id = @Id
             GO
            