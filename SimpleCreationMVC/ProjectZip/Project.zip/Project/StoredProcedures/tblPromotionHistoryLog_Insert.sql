
             ALTER PROCEDURE tblPromotionHistoryLog_Insert
             @Id int = NULL,
             	@EmployeeId int  = NULL,
		@PositionId int  = NULL,
		@DepartmentId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL,
		@PromotedDate date  = NULL
             AS
                INSERT INTO tblPromotionHistoryLog(EmployeeId,PositionId,DepartmentId,AlternativePosition,PromotedDate)
                VALUES (@EmployeeId,@PositionId,@DepartmentId,@AlternativePosition,@PromotedDate)
                SELECT * FROM tblPromotionHistoryLog WHERE Id = SCOPE_IDENTITY()
             GO
            