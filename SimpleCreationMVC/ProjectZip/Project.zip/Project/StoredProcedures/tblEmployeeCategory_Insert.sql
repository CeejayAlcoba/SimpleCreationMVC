
             ALTER PROCEDURE tblEmployeeCategory_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@CategoryTypeId int  = NULL,
		@DepartmentId int  = NULL
             AS
                INSERT INTO tblEmployeeCategory(EmployeeId,CategoryTypeId,DepartmentId)
                VALUES (@EmployeeId,@CategoryTypeId,@DepartmentId)
                SELECT * FROM tblEmployeeCategory WHERE Id = SCOPE_IDENTITY()
             GO
            