
             ALTER PROCEDURE tblRefCountry_GetById
             @Id INT
             AS
                SELECT * FROM tblRefCountry
                WHERE Id = @Id
             GO
            