
             ALTER PROCEDURE tblExternalWorkExperience_DeleteById
                @Id INT
             AS
                DELETE FROM tblExternalWorkExperience
                WHERE Id =  @Id
             GO
            