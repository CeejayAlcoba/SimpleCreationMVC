
             ALTER PROCEDURE tblRefEmploymentType_GetById
             @Id INT
             AS
                SELECT * FROM tblRefEmploymentType
                WHERE Id = @Id
             GO
            