
             CREATE PROCEDURE tblEmployeeCorporateData_GetAll
             AS
                SELECT * FROM tblEmployeeCorporateData
             GO
            