
             ALTER PROCEDURE tblRefSalaryType_GetById
             @Id INT
             AS
                SELECT * FROM tblRefSalaryType
                WHERE Id = @Id
             GO
            