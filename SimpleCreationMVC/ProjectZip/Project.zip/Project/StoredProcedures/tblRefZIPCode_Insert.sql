
             ALTER PROCEDURE tblRefZIPCode_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@MunicipalityId int  = NULL
             AS
                INSERT INTO tblRefZIPCode(Description,IsDeleted,MunicipalityId)
                VALUES (@Description,@IsDeleted,@MunicipalityId)
                SELECT * FROM tblRefZIPCode WHERE Id = SCOPE_IDENTITY()
             GO
            