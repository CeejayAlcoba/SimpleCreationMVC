
             ALTER PROCEDURE tblRefJobLevel_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefJobLevel(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefJobLevel WHERE Id = SCOPE_IDENTITY()
             GO
            