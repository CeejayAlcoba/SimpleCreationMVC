
             ALTER PROCEDURE tblInternalWorkExperience_DeleteById
                @Id INT
             AS
                DELETE FROM tblInternalWorkExperience
                WHERE Id =  @Id
             GO
            