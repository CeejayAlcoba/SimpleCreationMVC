
             ALTER PROCEDURE tblRefMunicipality_GetAll
             AS
                SELECT * FROM tblRefMunicipality
             GO
            