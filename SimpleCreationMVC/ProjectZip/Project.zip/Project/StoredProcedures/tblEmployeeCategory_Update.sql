
             ALTER PROCEDURE tblEmployeeCategory_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@CategoryTypeId int  = NULL,
		@DepartmentId int  = NULL
             AS
                UPDATE tblEmployeeCategory
                SET EmployeeId=@EmployeeId,CategoryTypeId=@CategoryTypeId,DepartmentId=@DepartmentId
                WHERE Id = @Id
                SELECT * FROM tblEmployeeCategory WHERE Id = @Id
             GO
            