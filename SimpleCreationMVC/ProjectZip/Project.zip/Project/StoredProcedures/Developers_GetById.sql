
ALTER PROCEDURE Developers_GetById
@Id INT
AS
   SELECT * FROM Developers
   WHERE Id = @Id
GO
            