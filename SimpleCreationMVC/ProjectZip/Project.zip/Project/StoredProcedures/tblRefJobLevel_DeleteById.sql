
             ALTER PROCEDURE tblRefJobLevel_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefJobLevel
                WHERE Id =  @Id
             GO
            