
             ALTER PROCEDURE tblRefGender_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefGender
                WHERE Id =  @Id
             GO
            