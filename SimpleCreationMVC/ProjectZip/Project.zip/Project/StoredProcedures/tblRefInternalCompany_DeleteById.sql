
             ALTER PROCEDURE tblRefInternalCompany_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefInternalCompany
                WHERE Id =  @Id
             GO
            