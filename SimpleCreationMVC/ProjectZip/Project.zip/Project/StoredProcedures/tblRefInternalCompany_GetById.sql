
             ALTER PROCEDURE tblRefInternalCompany_GetById
             @Id INT
             AS
                SELECT * FROM tblRefInternalCompany
                WHERE Id = @Id
             GO
            