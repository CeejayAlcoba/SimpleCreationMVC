
             ALTER PROCEDURE tblFamilyData_GetById
             @Id INT
             AS
                SELECT * FROM tblFamilyData
                WHERE Id = @Id
             GO
            