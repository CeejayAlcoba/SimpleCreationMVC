
             ALTER PROCEDURE tblFamilyData_GetAll
             AS
                SELECT * FROM tblFamilyData
             GO
            