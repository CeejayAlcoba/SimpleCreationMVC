
             ALTER PROCEDURE tblSalaryHistoryLog_DeleteById
                @Id INT
             AS
                DELETE FROM tblSalaryHistoryLog
                WHERE Id =  @Id
             GO
            