
             ALTER PROCEDURE tblEmployeeSalary_GetById
             @Id INT
             AS
                SELECT * FROM tblEmployeeSalary
                WHERE Id = @Id
             GO
            