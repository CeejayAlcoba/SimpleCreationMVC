
             ALTER PROCEDURE tblRefEducationalLevel_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefEducationalLevel(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefEducationalLevel WHERE Id = SCOPE_IDENTITY()
             GO
            