
CREATE PROCEDURE Test_Update
	@Id int ,
	@description nvarchar(MAX)  = NULL
AS
   UPDATE Test
   SET 
		description=@description
    WHERE Id = @Id
    SELECT * FROM Test WHERE Id = @Id
 GO
            