
             CREATE PROCEDURE tblEmployeeCorporateData_GetById
             @Id INT
             AS
                SELECT * FROM tblEmployeeCorporateData
                WHERE Id = @Id
             GO
            