
             ALTER PROCEDURE tblEmployeeSalary_GetAll
             AS
                SELECT * FROM tblEmployeeSalary
             GO
            