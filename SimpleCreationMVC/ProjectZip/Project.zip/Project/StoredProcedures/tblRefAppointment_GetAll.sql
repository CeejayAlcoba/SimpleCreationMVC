
             ALTER PROCEDURE tblRefAppointment_GetAll
             AS
                SELECT * FROM tblRefAppointment
             GO
            