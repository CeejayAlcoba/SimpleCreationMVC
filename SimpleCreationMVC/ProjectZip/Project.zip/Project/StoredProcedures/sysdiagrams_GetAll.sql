
             CREATE PROCEDURE sysdiagrams_GetAll
             AS
                SELECT * FROM sysdiagrams
             GO
            