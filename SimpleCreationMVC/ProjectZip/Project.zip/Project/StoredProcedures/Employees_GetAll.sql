
             CREATE PROCEDURE Employees_GetAll
             AS
                SELECT * FROM Employees
             GO
            