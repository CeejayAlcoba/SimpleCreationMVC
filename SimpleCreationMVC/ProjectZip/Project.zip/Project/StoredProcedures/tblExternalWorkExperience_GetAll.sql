
             ALTER PROCEDURE tblExternalWorkExperience_GetAll
             AS
                SELECT * FROM tblExternalWorkExperience
             GO
            