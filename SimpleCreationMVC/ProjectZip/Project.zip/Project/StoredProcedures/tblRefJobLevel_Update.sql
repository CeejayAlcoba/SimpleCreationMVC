
             ALTER PROCEDURE tblRefJobLevel_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefJobLevel
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefJobLevel WHERE Id = @Id
             GO
            