
             ALTER PROCEDURE tblEmployeeCurrentPosition_GetAll
             AS
                SELECT * FROM tblEmployeeCurrentPosition
             GO
            