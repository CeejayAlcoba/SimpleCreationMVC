
             ALTER PROCEDURE tblPayrollAccountNumber_Insert
             @Id int = NULL,
             	@EmployeeId int  = NULL,
		@AccountNumber nvarchar(MAX)  = NULL
             AS
                INSERT INTO tblPayrollAccountNumber(EmployeeId,AccountNumber)
                VALUES (@EmployeeId,@AccountNumber)
                SELECT * FROM tblPayrollAccountNumber WHERE Id = SCOPE_IDENTITY()
             GO
            