
CREATE PROCEDURE Test_GetById
@Id INT
AS
   SELECT * FROM Test
   WHERE Id = @Id
GO
            