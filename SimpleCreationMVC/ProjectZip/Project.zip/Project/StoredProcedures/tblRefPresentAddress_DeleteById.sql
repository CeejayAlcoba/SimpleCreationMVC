
             ALTER PROCEDURE tblRefPresentAddress_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefPresentAddress
                WHERE Id =  @Id
             GO
            