
             CREATE PROCEDURE sysdiagrams_Update
             	@name nvarchar(128) ,
		@principal_id int ,
		@diagram_id int ,
		@version int  = NULL,
		@definition varbinary  = NULL
             AS
                UPDATE sysdiagrams
                SET name=@name,principal_id=@principal_id,version=@version,definition=@definition
                WHERE diagram_id = @diagram_id
                SELECT * FROM sysdiagrams WHERE diagram_id = @Id
             GO
            