
             ALTER PROCEDURE tblRefGender_Insert
             @Id int = NULL,
             	@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefGender(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefGender WHERE Id = SCOPE_IDENTITY()
             GO
            