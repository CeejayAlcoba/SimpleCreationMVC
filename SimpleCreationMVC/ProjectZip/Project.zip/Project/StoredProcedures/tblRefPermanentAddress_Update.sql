
             ALTER PROCEDURE tblRefPermanentAddress_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@BarangayId int  = NULL,
		@MunicipalityId int  = NULL,
		@ProvinceId int  = NULL,
		@CountryId int  = NULL,
		@ZIPCodeId int  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefPermanentAddress
                SET EmployeeId=@EmployeeId,BarangayId=@BarangayId,MunicipalityId=@MunicipalityId,ProvinceId=@ProvinceId,CountryId=@CountryId,ZIPCodeId=@ZIPCodeId,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefPermanentAddress WHERE Id = @Id
             GO
            