
             ALTER PROCEDURE tblFamilyData_DeleteById
                @Id INT
             AS
                DELETE FROM tblFamilyData
                WHERE Id =  @Id
             GO
            