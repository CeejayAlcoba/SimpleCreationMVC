
             ALTER PROCEDURE tblInternalWorkExperience_GetAll
             AS
                SELECT * FROM tblInternalWorkExperience
             GO
            