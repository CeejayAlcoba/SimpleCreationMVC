
             ALTER PROCEDURE tblRefBarangay_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefBarangay
                WHERE Id =  @Id
             GO
            