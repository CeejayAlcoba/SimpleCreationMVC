
ALTER PROCEDURE Developers_Insert
    @Id int = NULL,
	@Name nvarchar(MAX) ,
	@Folowers int 
AS
   INSERT INTO Developers(
		Name,
		Folowers
        )
   VALUES (
		@Name,
		@Folowers
        )
   SELECT * FROM Developers WHERE Id = SCOPE_IDENTITY()
GO
            