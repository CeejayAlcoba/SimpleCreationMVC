
             CREATE PROCEDURE tblEmployeeCorporateData_GetAll
             AS
                SELECT * FROM tblEmployeeCorporateData
             GO
            

             CREATE PROCEDURE tblEmployeeCorporateData_Insert
             @Id int = NULL,
             	@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@DepartmentId int  = NULL,
		@EmploymentTypeId int  = NULL,
		@PositionId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL,
		@SalaryAmount float  = NULL
             AS
                INSERT INTO tblEmployeeCorporateData(EmployeeId,SalaryTypeId,DepartmentId,EmploymentTypeId,PositionId,AlternativePosition,SalaryAmount)
                VALUES (@EmployeeId,@SalaryTypeId,@DepartmentId,@EmploymentTypeId,@PositionId,@AlternativePosition,@SalaryAmount)
                SELECT * FROM tblEmployeeCorporateData WHERE Id = SCOPE_IDENTITY()
             GO
            

             CREATE PROCEDURE tblEmployeeCorporateData_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@DepartmentId int  = NULL,
		@EmploymentTypeId int  = NULL,
		@PositionId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL,
		@SalaryAmount float  = NULL
             AS
                UPDATE tblEmployeeCorporateData
                SET EmployeeId=@EmployeeId,SalaryTypeId=@SalaryTypeId,DepartmentId=@DepartmentId,EmploymentTypeId=@EmploymentTypeId,PositionId=@PositionId,AlternativePosition=@AlternativePosition,SalaryAmount=@SalaryAmount
                WHERE Id = @Id
                SELECT * FROM tblEmployeeCorporateData WHERE Id = @Id
             GO
            

             CREATE PROCEDURE tblEmployeeCorporateData_GetById
             @Id INT
             AS
                SELECT * FROM tblEmployeeCorporateData
                WHERE Id = @Id
             GO
            

             CREATE PROCEDURE tblEmployeeCorporateData_DeleteById
                @Id INT
             AS
                DELETE FROM tblEmployeeCorporateData
                WHERE Id =  @Id
             GO
            
