
CREATE PROCEDURE Children_GetAll
AS
    SELECT * FROM Children
GO


CREATE PROCEDURE Children_Insert
    @Id int = NULL,
	@Name nvarchar(100)  = NULL,
	@Bday date  = NULL,
	@GradeLevel nvarchar(50)  = NULL,
	@FamilyId int 
AS
   INSERT INTO Children(
		Name,
		Bday,
		GradeLevel,
		FamilyId
        )
   VALUES (
		@Name,
		@Bday,
		@GradeLevel,
		@FamilyId
        )
   SELECT * FROM Children WHERE Id = SCOPE_IDENTITY()
GO
            

CREATE PROCEDURE Children_Update
	@Id int ,
	@Name nvarchar(100)  = NULL,
	@Bday date  = NULL,
	@GradeLevel nvarchar(50)  = NULL,
	@FamilyId int 
AS
   UPDATE Children
   SET 
		Name=@Name,
		Bday=@Bday,
		GradeLevel=@GradeLevel,
		FamilyId=@FamilyId
    WHERE Id = @Id
    SELECT * FROM Children WHERE Id = @Id
 GO
            

CREATE PROCEDURE Children_GetById
@Id INT
AS
   SELECT * FROM Children
   WHERE Id = @Id
GO
            

CREATE PROCEDURE Children_DeleteById
    @Id INT
AS
    DELETE FROM Children
    WHERE Id =  @Id
GO
            
