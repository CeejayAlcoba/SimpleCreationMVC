
ALTER PROCEDURE Developers_GetAll
AS
    SELECT * FROM Developers
GO


ALTER PROCEDURE Developers_Insert
    @Id int = NULL,
	@Name nvarchar(MAX) ,
	@Folowers int 
AS
   INSERT INTO Developers(
		Name,
		Folowers
        )
   VALUES (
		@Name,
		@Folowers
        )
   SELECT * FROM Developers WHERE Id = SCOPE_IDENTITY()
GO
            

ALTER PROCEDURE Developers_Update
	@Id int ,
	@Name nvarchar(MAX) ,
	@Folowers int 
AS
   UPDATE Developers
   SET 
		Name=@Name,
		Folowers=@Folowers
    WHERE Id = @Id
    SELECT * FROM Developers WHERE Id = @Id
 GO
            

ALTER PROCEDURE Developers_GetById
@Id INT
AS
   SELECT * FROM Developers
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Developers_DeleteById
    @Id INT
AS
    DELETE FROM Developers
    WHERE Id =  @Id
GO
            

ALTER PROCEDURE Projects_GetAll
AS
    SELECT * FROM Projects
GO


CREATE PROCEDURE Projects_Insert
    @Id int = NULL,
	@Description nvarchar(MAX)  = NULL
AS
   INSERT INTO Projects(
		Description
        )
   VALUES (
		@Description
        )
   SELECT * FROM Projects WHERE Id = SCOPE_IDENTITY()
GO
            

CREATE PROCEDURE Projects_Update
	@Id int ,
	@Description nvarchar(MAX)  = NULL
AS
   UPDATE Projects
   SET 
		Description=@Description
    WHERE Id = @Id
    SELECT * FROM Projects WHERE Id = @Id
 GO
            

ALTER PROCEDURE Projects_GetById
@Id INT
AS
   SELECT * FROM Projects
   WHERE Id = @Id
GO
            

ALTER PROCEDURE Projects_DeleteById
    @Id INT
AS
    DELETE FROM Projects
    WHERE Id =  @Id
GO
            

CREATE PROCEDURE Test_GetAll
AS
    SELECT * FROM Test
GO


CREATE PROCEDURE Test_Insert
    @Id int = NULL,
	@description nvarchar(MAX)  = NULL
AS
   INSERT INTO Test(
		description
        )
   VALUES (
		@description
        )
   SELECT * FROM Test WHERE Id = SCOPE_IDENTITY()
GO
            

CREATE PROCEDURE Test_Update
	@Id int ,
	@description nvarchar(MAX)  = NULL
AS
   UPDATE Test
   SET 
		description=@description
    WHERE Id = @Id
    SELECT * FROM Test WHERE Id = @Id
 GO
            

CREATE PROCEDURE Test_GetById
@Id INT
AS
   SELECT * FROM Test
   WHERE Id = @Id
GO
            

CREATE PROCEDURE Test_DeleteById
    @Id INT
AS
    DELETE FROM Test
    WHERE Id =  @Id
GO
            
