
             ALTER PROCEDURE tblRefPosition_GetAll
             AS
                SELECT * FROM tblRefPosition
             GO
            

             ALTER PROCEDURE tblRefPosition_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefPosition(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefPosition WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefPosition_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefPosition
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefPosition WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefPosition_GetById
             @Id INT
             AS
                SELECT * FROM tblRefPosition
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefPosition_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefPosition
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefDepartment_GetAll
             AS
                SELECT * FROM tblRefDepartment
             GO
            

             ALTER PROCEDURE tblRefDepartment_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefDepartment(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefDepartment WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefDepartment_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefDepartment
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefDepartment WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefDepartment_GetById
             @Id INT
             AS
                SELECT * FROM tblRefDepartment
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefDepartment_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefDepartment
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblPromotionHistoryLog_GetAll
             AS
                SELECT * FROM tblPromotionHistoryLog
             GO
            

             ALTER PROCEDURE tblPromotionHistoryLog_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@PositionId int  = NULL,
		@DepartmentId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL,
		@PromotedDate date  = NULL
             AS
                INSERT INTO tblPromotionHistoryLog(EmployeeId,PositionId,DepartmentId,AlternativePosition,PromotedDate)
                VALUES (@EmployeeId,@PositionId,@DepartmentId,@AlternativePosition,@PromotedDate)
                SELECT * FROM tblPromotionHistoryLog WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblPromotionHistoryLog_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@PositionId int  = NULL,
		@DepartmentId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL,
		@PromotedDate date  = NULL
             AS
                UPDATE tblPromotionHistoryLog
                SET EmployeeId=@EmployeeId,PositionId=@PositionId,DepartmentId=@DepartmentId,AlternativePosition=@AlternativePosition,PromotedDate=@PromotedDate
                WHERE Id = @Id
                SELECT * FROM tblPromotionHistoryLog WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblPromotionHistoryLog_GetById
             @Id INT
             AS
                SELECT * FROM tblPromotionHistoryLog
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblPromotionHistoryLog_DeleteById
                @Id INT
             AS
                DELETE FROM tblPromotionHistoryLog
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblEmployeeCurrentPosition_GetAll
             AS
                SELECT * FROM tblEmployeeCurrentPosition
             GO
            

             ALTER PROCEDURE tblEmployeeCurrentPosition_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@PositionId int  = NULL,
		@DepartmentId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL
             AS
                INSERT INTO tblEmployeeCurrentPosition(EmployeeId,PositionId,DepartmentId,AlternativePosition)
                VALUES (@EmployeeId,@PositionId,@DepartmentId,@AlternativePosition)
                SELECT * FROM tblEmployeeCurrentPosition WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblEmployeeCurrentPosition_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@PositionId int  = NULL,
		@DepartmentId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL
             AS
                UPDATE tblEmployeeCurrentPosition
                SET EmployeeId=@EmployeeId,PositionId=@PositionId,DepartmentId=@DepartmentId,AlternativePosition=@AlternativePosition
                WHERE Id = @Id
                SELECT * FROM tblEmployeeCurrentPosition WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblEmployeeCurrentPosition_GetById
             @Id INT
             AS
                SELECT * FROM tblEmployeeCurrentPosition
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblEmployeeCurrentPosition_DeleteById
                @Id INT
             AS
                DELETE FROM tblEmployeeCurrentPosition
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefEducationalLevel_GetAll
             AS
                SELECT * FROM tblRefEducationalLevel
             GO
            

             ALTER PROCEDURE tblRefEducationalLevel_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefEducationalLevel(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefEducationalLevel WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefEducationalLevel_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefEducationalLevel
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefEducationalLevel WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefEducationalLevel_GetById
             @Id INT
             AS
                SELECT * FROM tblRefEducationalLevel
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefEducationalLevel_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefEducationalLevel
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblEducationalData_GetAll
             AS
                SELECT * FROM tblEducationalData
             GO
            

             ALTER PROCEDURE tblEducationalData_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@EducationalLevelId int  = NULL,
		@School nvarchar(MAX)  = NULL,
		@YearGraduate nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                INSERT INTO tblEducationalData(EmployeeId,EducationalLevelId,School,YearGraduate,IsDeleted,ApplicantId)
                VALUES (@EmployeeId,@EducationalLevelId,@School,@YearGraduate,@IsDeleted,@ApplicantId)
                SELECT * FROM tblEducationalData WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblEducationalData_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@EducationalLevelId int  = NULL,
		@School nvarchar(MAX)  = NULL,
		@YearGraduate nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                UPDATE tblEducationalData
                SET EmployeeId=@EmployeeId,EducationalLevelId=@EducationalLevelId,School=@School,YearGraduate=@YearGraduate,IsDeleted=@IsDeleted,ApplicantId=@ApplicantId
                WHERE Id = @Id
                SELECT * FROM tblEducationalData WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblEducationalData_GetById
             @Id INT
             AS
                SELECT * FROM tblEducationalData
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblEducationalData_DeleteById
                @Id INT
             AS
                DELETE FROM tblEducationalData
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblEmployeeData_GetAll
             AS
                SELECT * FROM tblEmployeeData
             GO
            

             ALTER PROCEDURE tblEmployeeData_Insert
             	@Id int ,
		@LastName nvarchar(100)  = NULL,
		@FirstName nvarchar(100)  = NULL,
		@MiddleName nvarchar(100)  = NULL,
		@GenderId int  = NULL,
		@CivilStatusId int  = NULL,
		@ReligionId int  = NULL,
		@PlaceOfBirth nvarchar(MAX)  = NULL,
		@NationalIdNumber nvarchar(MAX)  = NULL,
		@SSSNumber nvarchar(MAX)  = NULL,
		@HDMFNumber nvarchar(MAX)  = NULL,
		@PHICNumber nvarchar(MAX)  = NULL,
		@TIN nvarchar(MAX)  = NULL,
		@HMOCardNumber nvarchar(MAX)  = NULL,
		@HMOAccountNumber nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@BirthDate date  = NULL,
		@DateHired date  = NULL
             AS
                INSERT INTO tblEmployeeData(LastName,FirstName,MiddleName,GenderId,CivilStatusId,ReligionId,PlaceOfBirth,NationalIdNumber,SSSNumber,HDMFNumber,PHICNumber,TIN,HMOCardNumber,HMOAccountNumber,IsDeleted,BirthDate,DateHired)
                VALUES (@LastName,@FirstName,@MiddleName,@GenderId,@CivilStatusId,@ReligionId,@PlaceOfBirth,@NationalIdNumber,@SSSNumber,@HDMFNumber,@PHICNumber,@TIN,@HMOCardNumber,@HMOAccountNumber,@IsDeleted,@BirthDate,@DateHired)
                SELECT * FROM tblEmployeeData WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblEmployeeData_Update
             	@Id int ,
		@LastName nvarchar(100)  = NULL,
		@FirstName nvarchar(100)  = NULL,
		@MiddleName nvarchar(100)  = NULL,
		@GenderId int  = NULL,
		@CivilStatusId int  = NULL,
		@ReligionId int  = NULL,
		@PlaceOfBirth nvarchar(MAX)  = NULL,
		@NationalIdNumber nvarchar(MAX)  = NULL,
		@SSSNumber nvarchar(MAX)  = NULL,
		@HDMFNumber nvarchar(MAX)  = NULL,
		@PHICNumber nvarchar(MAX)  = NULL,
		@TIN nvarchar(MAX)  = NULL,
		@HMOCardNumber nvarchar(MAX)  = NULL,
		@HMOAccountNumber nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@BirthDate date  = NULL,
		@DateHired date  = NULL
             AS
                UPDATE tblEmployeeData
                SET LastName=@LastName,FirstName=@FirstName,MiddleName=@MiddleName,GenderId=@GenderId,CivilStatusId=@CivilStatusId,ReligionId=@ReligionId,PlaceOfBirth=@PlaceOfBirth,NationalIdNumber=@NationalIdNumber,SSSNumber=@SSSNumber,HDMFNumber=@HDMFNumber,PHICNumber=@PHICNumber,TIN=@TIN,HMOCardNumber=@HMOCardNumber,HMOAccountNumber=@HMOAccountNumber,IsDeleted=@IsDeleted,BirthDate=@BirthDate,DateHired=@DateHired
                WHERE Id = @Id
                SELECT * FROM tblEmployeeData WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblEmployeeData_GetById
             @Id INT
             AS
                SELECT * FROM tblEmployeeData
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblEmployeeData_DeleteById
                @Id INT
             AS
                DELETE FROM tblEmployeeData
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblFamilyData_GetAll
             AS
                SELECT * FROM tblFamilyData
             GO
            

             ALTER PROCEDURE tblFamilyData_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@MotherMaidenName nvarchar(MAX)  = NULL,
		@FatherName nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                INSERT INTO tblFamilyData(EmployeeId,MotherMaidenName,FatherName,IsDeleted,ApplicantId)
                VALUES (@EmployeeId,@MotherMaidenName,@FatherName,@IsDeleted,@ApplicantId)
                SELECT * FROM tblFamilyData WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblFamilyData_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@MotherMaidenName nvarchar(MAX)  = NULL,
		@FatherName nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                UPDATE tblFamilyData
                SET EmployeeId=@EmployeeId,MotherMaidenName=@MotherMaidenName,FatherName=@FatherName,IsDeleted=@IsDeleted,ApplicantId=@ApplicantId
                WHERE Id = @Id
                SELECT * FROM tblFamilyData WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblFamilyData_GetById
             @Id INT
             AS
                SELECT * FROM tblFamilyData
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblFamilyData_DeleteById
                @Id INT
             AS
                DELETE FROM tblFamilyData
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblApplicantData_GetAll
             AS
                SELECT * FROM tblApplicantData
             GO
            

             ALTER PROCEDURE tblApplicantData_Insert
             	@Id int ,
		@GenderId int  = NULL,
		@CivilStatusId int  = NULL,
		@ReligionId int  = NULL,
		@PlaceOfBirth nvarchar(MAX)  = NULL,
		@NationalIdNumber nvarchar(MAX)  = NULL,
		@SSSNumber nvarchar(MAX)  = NULL,
		@HDMFNumber nvarchar(MAX)  = NULL,
		@PHICNUmber nvarchar(MAX)  = NULL,
		@TIN nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@BirthDate date  = NULL,
		@LastName nvarchar(100)  = NULL,
		@FirstName nvarchar(100)  = NULL,
		@MiddleName nvarchar(100)  = NULL,
		@AppliedDate date  = NULL,
		@HMOCardNumber nvarchar(MAX)  = NULL,
		@HMOAccountNumber nvarchar(MAX)  = NULL
             AS
                INSERT INTO tblApplicantData(GenderId,CivilStatusId,ReligionId,PlaceOfBirth,NationalIdNumber,SSSNumber,HDMFNumber,PHICNUmber,TIN,IsDeleted,BirthDate,LastName,FirstName,MiddleName,AppliedDate,HMOCardNumber,HMOAccountNumber)
                VALUES (@GenderId,@CivilStatusId,@ReligionId,@PlaceOfBirth,@NationalIdNumber,@SSSNumber,@HDMFNumber,@PHICNUmber,@TIN,@IsDeleted,@BirthDate,@LastName,@FirstName,@MiddleName,@AppliedDate,@HMOCardNumber,@HMOAccountNumber)
                SELECT * FROM tblApplicantData WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblApplicantData_Update
             	@Id int ,
		@GenderId int  = NULL,
		@CivilStatusId int  = NULL,
		@ReligionId int  = NULL,
		@PlaceOfBirth nvarchar(MAX)  = NULL,
		@NationalIdNumber nvarchar(MAX)  = NULL,
		@SSSNumber nvarchar(MAX)  = NULL,
		@HDMFNumber nvarchar(MAX)  = NULL,
		@PHICNUmber nvarchar(MAX)  = NULL,
		@TIN nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@BirthDate date  = NULL,
		@LastName nvarchar(100)  = NULL,
		@FirstName nvarchar(100)  = NULL,
		@MiddleName nvarchar(100)  = NULL,
		@AppliedDate date  = NULL,
		@HMOCardNumber nvarchar(MAX)  = NULL,
		@HMOAccountNumber nvarchar(MAX)  = NULL
             AS
                UPDATE tblApplicantData
                SET GenderId=@GenderId,CivilStatusId=@CivilStatusId,ReligionId=@ReligionId,PlaceOfBirth=@PlaceOfBirth,NationalIdNumber=@NationalIdNumber,SSSNumber=@SSSNumber,HDMFNumber=@HDMFNumber,PHICNUmber=@PHICNUmber,TIN=@TIN,IsDeleted=@IsDeleted,BirthDate=@BirthDate,LastName=@LastName,FirstName=@FirstName,MiddleName=@MiddleName,AppliedDate=@AppliedDate,HMOCardNumber=@HMOCardNumber,HMOAccountNumber=@HMOAccountNumber
                WHERE Id = @Id
                SELECT * FROM tblApplicantData WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblApplicantData_GetById
             @Id INT
             AS
                SELECT * FROM tblApplicantData
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblApplicantData_DeleteById
                @Id INT
             AS
                DELETE FROM tblApplicantData
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefBarangay_GetAll
             AS
                SELECT * FROM tblRefBarangay
             GO
            

             ALTER PROCEDURE tblRefBarangay_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@MunicipalityId int  = NULL
             AS
                INSERT INTO tblRefBarangay(Description,IsDeleted,MunicipalityId)
                VALUES (@Description,@IsDeleted,@MunicipalityId)
                SELECT * FROM tblRefBarangay WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefBarangay_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@MunicipalityId int  = NULL
             AS
                UPDATE tblRefBarangay
                SET Description=@Description,IsDeleted=@IsDeleted,MunicipalityId=@MunicipalityId
                WHERE Id = @Id
                SELECT * FROM tblRefBarangay WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefBarangay_GetById
             @Id INT
             AS
                SELECT * FROM tblRefBarangay
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefBarangay_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefBarangay
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefChildren_GetAll
             AS
                SELECT * FROM tblRefChildren
             GO
            

             ALTER PROCEDURE tblRefChildren_Insert
             	@Id int ,
		@FamilyId int  = NULL,
		@Name nvarchar(MAX)  = NULL,
		@GradeLevelId int  = NULL,
		@IsDeleted bit  = NULL,
		@Birthday date  = NULL
             AS
                INSERT INTO tblRefChildren(FamilyId,Name,GradeLevelId,IsDeleted,Birthday)
                VALUES (@FamilyId,@Name,@GradeLevelId,@IsDeleted,@Birthday)
                SELECT * FROM tblRefChildren WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefChildren_Update
             	@Id int ,
		@FamilyId int  = NULL,
		@Name nvarchar(MAX)  = NULL,
		@GradeLevelId int  = NULL,
		@IsDeleted bit  = NULL,
		@Birthday date  = NULL
             AS
                UPDATE tblRefChildren
                SET FamilyId=@FamilyId,Name=@Name,GradeLevelId=@GradeLevelId,IsDeleted=@IsDeleted,Birthday=@Birthday
                WHERE Id = @Id
                SELECT * FROM tblRefChildren WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefChildren_GetById
             @Id INT
             AS
                SELECT * FROM tblRefChildren
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefChildren_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefChildren
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefCivilStatus_GetAll
             AS
                SELECT * FROM tblRefCivilStatus
             GO
            

             ALTER PROCEDURE tblRefCivilStatus_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefCivilStatus(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefCivilStatus WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefCivilStatus_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefCivilStatus
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefCivilStatus WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefCivilStatus_GetById
             @Id INT
             AS
                SELECT * FROM tblRefCivilStatus
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefCivilStatus_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefCivilStatus
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefCountry_GetAll
             AS
                SELECT * FROM tblRefCountry
             GO
            

             ALTER PROCEDURE tblRefCountry_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@Code nvarchar(10)  = NULL
             AS
                INSERT INTO tblRefCountry(Description,IsDeleted,Code)
                VALUES (@Description,@IsDeleted,@Code)
                SELECT * FROM tblRefCountry WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefCountry_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@Code nvarchar(10)  = NULL
             AS
                UPDATE tblRefCountry
                SET Description=@Description,IsDeleted=@IsDeleted,Code=@Code
                WHERE Id = @Id
                SELECT * FROM tblRefCountry WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefCountry_GetById
             @Id INT
             AS
                SELECT * FROM tblRefCountry
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefCountry_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefCountry
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefGender_GetAll
             AS
                SELECT * FROM tblRefGender
             GO
            

             ALTER PROCEDURE tblRefGender_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefGender(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefGender WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefGender_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefGender
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefGender WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefGender_GetById
             @Id INT
             AS
                SELECT * FROM tblRefGender
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefGender_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefGender
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefGradeLevel_GetAll
             AS
                SELECT * FROM tblRefGradeLevel
             GO
            

             ALTER PROCEDURE tblRefGradeLevel_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefGradeLevel(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefGradeLevel WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefGradeLevel_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefGradeLevel
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefGradeLevel WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefGradeLevel_GetById
             @Id INT
             AS
                SELECT * FROM tblRefGradeLevel
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefGradeLevel_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefGradeLevel
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefMunicipality_GetAll
             AS
                SELECT * FROM tblRefMunicipality
             GO
            

             ALTER PROCEDURE tblRefMunicipality_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@ProvinceId int  = NULL
             AS
                INSERT INTO tblRefMunicipality(Description,IsDeleted,ProvinceId)
                VALUES (@Description,@IsDeleted,@ProvinceId)
                SELECT * FROM tblRefMunicipality WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefMunicipality_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@ProvinceId int  = NULL
             AS
                UPDATE tblRefMunicipality
                SET Description=@Description,IsDeleted=@IsDeleted,ProvinceId=@ProvinceId
                WHERE Id = @Id
                SELECT * FROM tblRefMunicipality WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefMunicipality_GetById
             @Id INT
             AS
                SELECT * FROM tblRefMunicipality
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefMunicipality_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefMunicipality
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefPermanentAddress_GetAll
             AS
                SELECT * FROM tblRefPermanentAddress
             GO
            

             ALTER PROCEDURE tblRefPermanentAddress_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@BarangayId int  = NULL,
		@MunicipalityId int  = NULL,
		@ProvinceId int  = NULL,
		@CountryId int  = NULL,
		@ZIPCodeId int  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefPermanentAddress(EmployeeId,BarangayId,MunicipalityId,ProvinceId,CountryId,ZIPCodeId,IsDeleted)
                VALUES (@EmployeeId,@BarangayId,@MunicipalityId,@ProvinceId,@CountryId,@ZIPCodeId,@IsDeleted)
                SELECT * FROM tblRefPermanentAddress WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefPermanentAddress_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@BarangayId int  = NULL,
		@MunicipalityId int  = NULL,
		@ProvinceId int  = NULL,
		@CountryId int  = NULL,
		@ZIPCodeId int  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefPermanentAddress
                SET EmployeeId=@EmployeeId,BarangayId=@BarangayId,MunicipalityId=@MunicipalityId,ProvinceId=@ProvinceId,CountryId=@CountryId,ZIPCodeId=@ZIPCodeId,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefPermanentAddress WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefPermanentAddress_GetById
             @Id INT
             AS
                SELECT * FROM tblRefPermanentAddress
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefPermanentAddress_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefPermanentAddress
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefPresentAddress_GetAll
             AS
                SELECT * FROM tblRefPresentAddress
             GO
            

             ALTER PROCEDURE tblRefPresentAddress_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@BarangayId int  = NULL,
		@MunicipalityId int  = NULL,
		@ProvinceId int  = NULL,
		@CountryId int  = NULL,
		@ZIPCodeId int  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefPresentAddress(EmployeeId,BarangayId,MunicipalityId,ProvinceId,CountryId,ZIPCodeId,IsDeleted)
                VALUES (@EmployeeId,@BarangayId,@MunicipalityId,@ProvinceId,@CountryId,@ZIPCodeId,@IsDeleted)
                SELECT * FROM tblRefPresentAddress WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefPresentAddress_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@BarangayId int  = NULL,
		@MunicipalityId int  = NULL,
		@ProvinceId int  = NULL,
		@CountryId int  = NULL,
		@ZIPCodeId int  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefPresentAddress
                SET EmployeeId=@EmployeeId,BarangayId=@BarangayId,MunicipalityId=@MunicipalityId,ProvinceId=@ProvinceId,CountryId=@CountryId,ZIPCodeId=@ZIPCodeId,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefPresentAddress WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefPresentAddress_GetById
             @Id INT
             AS
                SELECT * FROM tblRefPresentAddress
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefPresentAddress_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefPresentAddress
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefProvince_GetAll
             AS
                SELECT * FROM tblRefProvince
             GO
            

             ALTER PROCEDURE tblRefProvince_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@CountryId int  = NULL
             AS
                INSERT INTO tblRefProvince(Description,IsDeleted,CountryId)
                VALUES (@Description,@IsDeleted,@CountryId)
                SELECT * FROM tblRefProvince WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefProvince_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@CountryId int  = NULL
             AS
                UPDATE tblRefProvince
                SET Description=@Description,IsDeleted=@IsDeleted,CountryId=@CountryId
                WHERE Id = @Id
                SELECT * FROM tblRefProvince WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefProvince_GetById
             @Id INT
             AS
                SELECT * FROM tblRefProvince
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefProvince_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefProvince
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefReligion_GetAll
             AS
                SELECT * FROM tblRefReligion
             GO
            

             ALTER PROCEDURE tblRefReligion_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefReligion(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefReligion WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefReligion_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefReligion
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefReligion WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefReligion_GetById
             @Id INT
             AS
                SELECT * FROM tblRefReligion
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefReligion_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefReligion
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblExternalWorkExperience_GetAll
             AS
                SELECT * FROM tblExternalWorkExperience
             GO
            

             ALTER PROCEDURE tblExternalWorkExperience_Insert
             	@Id int ,
		@Position nvarchar(MAX)  = NULL,
		@Employer nvarchar(MAX)  = NULL,
		@LengthOfService nvarchar(MAX)  = NULL,
		@ReasonOfLeaving nvarchar(MAX)  = NULL,
		@EmployeeId int  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                INSERT INTO tblExternalWorkExperience(Position,Employer,LengthOfService,ReasonOfLeaving,EmployeeId,IsDeleted,ApplicantId)
                VALUES (@Position,@Employer,@LengthOfService,@ReasonOfLeaving,@EmployeeId,@IsDeleted,@ApplicantId)
                SELECT * FROM tblExternalWorkExperience WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblExternalWorkExperience_Update
             	@Id int ,
		@Position nvarchar(MAX)  = NULL,
		@Employer nvarchar(MAX)  = NULL,
		@LengthOfService nvarchar(MAX)  = NULL,
		@ReasonOfLeaving nvarchar(MAX)  = NULL,
		@EmployeeId int  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                UPDATE tblExternalWorkExperience
                SET Position=@Position,Employer=@Employer,LengthOfService=@LengthOfService,ReasonOfLeaving=@ReasonOfLeaving,EmployeeId=@EmployeeId,IsDeleted=@IsDeleted,ApplicantId=@ApplicantId
                WHERE Id = @Id
                SELECT * FROM tblExternalWorkExperience WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblExternalWorkExperience_GetById
             @Id INT
             AS
                SELECT * FROM tblExternalWorkExperience
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblExternalWorkExperience_DeleteById
                @Id INT
             AS
                DELETE FROM tblExternalWorkExperience
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefZIPCode_GetAll
             AS
                SELECT * FROM tblRefZIPCode
             GO
            

             ALTER PROCEDURE tblRefZIPCode_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@MunicipalityId int  = NULL
             AS
                INSERT INTO tblRefZIPCode(Description,IsDeleted,MunicipalityId)
                VALUES (@Description,@IsDeleted,@MunicipalityId)
                SELECT * FROM tblRefZIPCode WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefZIPCode_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@MunicipalityId int  = NULL
             AS
                UPDATE tblRefZIPCode
                SET Description=@Description,IsDeleted=@IsDeleted,MunicipalityId=@MunicipalityId
                WHERE Id = @Id
                SELECT * FROM tblRefZIPCode WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefZIPCode_GetById
             @Id INT
             AS
                SELECT * FROM tblRefZIPCode
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefZIPCode_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefZIPCode
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefJobLevel_GetAll
             AS
                SELECT * FROM tblRefJobLevel
             GO
            

             ALTER PROCEDURE tblRefJobLevel_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefJobLevel(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefJobLevel WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefJobLevel_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefJobLevel
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefJobLevel WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefJobLevel_GetById
             @Id INT
             AS
                SELECT * FROM tblRefJobLevel
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefJobLevel_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefJobLevel
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefInternalCompany_GetAll
             AS
                SELECT * FROM tblRefInternalCompany
             GO
            

             ALTER PROCEDURE tblRefInternalCompany_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefInternalCompany(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefInternalCompany WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefInternalCompany_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefInternalCompany
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefInternalCompany WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefInternalCompany_GetById
             @Id INT
             AS
                SELECT * FROM tblRefInternalCompany
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefInternalCompany_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefInternalCompany
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefAppointment_GetAll
             AS
                SELECT * FROM tblRefAppointment
             GO
            

             ALTER PROCEDURE tblRefAppointment_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefAppointment(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefAppointment WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefAppointment_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefAppointment
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefAppointment WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefAppointment_GetById
             @Id INT
             AS
                SELECT * FROM tblRefAppointment
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefAppointment_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefAppointment
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblInternalWorkExperience_GetAll
             AS
                SELECT * FROM tblInternalWorkExperience
             GO
            

             ALTER PROCEDURE tblInternalWorkExperience_Insert
             	@Id int ,
		@Position nvarchar(MAX)  = NULL,
		@Department nvarchar(MAX)  = NULL,
		@EffectivityDate datetime  = NULL,
		@InternalCompanyId int  = NULL,
		@JobLevelId int  = NULL,
		@AppointmentId int  = NULL,
		@EmployeeId int  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                INSERT INTO tblInternalWorkExperience(Position,Department,EffectivityDate,InternalCompanyId,JobLevelId,AppointmentId,EmployeeId,IsDeleted,ApplicantId)
                VALUES (@Position,@Department,@EffectivityDate,@InternalCompanyId,@JobLevelId,@AppointmentId,@EmployeeId,@IsDeleted,@ApplicantId)
                SELECT * FROM tblInternalWorkExperience WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblInternalWorkExperience_Update
             	@Id int ,
		@Position nvarchar(MAX)  = NULL,
		@Department nvarchar(MAX)  = NULL,
		@EffectivityDate datetime  = NULL,
		@InternalCompanyId int  = NULL,
		@JobLevelId int  = NULL,
		@AppointmentId int  = NULL,
		@EmployeeId int  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                UPDATE tblInternalWorkExperience
                SET Position=@Position,Department=@Department,EffectivityDate=@EffectivityDate,InternalCompanyId=@InternalCompanyId,JobLevelId=@JobLevelId,AppointmentId=@AppointmentId,EmployeeId=@EmployeeId,IsDeleted=@IsDeleted,ApplicantId=@ApplicantId
                WHERE Id = @Id
                SELECT * FROM tblInternalWorkExperience WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblInternalWorkExperience_GetById
             @Id INT
             AS
                SELECT * FROM tblInternalWorkExperience
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblInternalWorkExperience_DeleteById
                @Id INT
             AS
                DELETE FROM tblInternalWorkExperience
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblSalaryHistoryLog_GetAll
             AS
                SELECT * FROM tblSalaryHistoryLog
             GO
            

             ALTER PROCEDURE tblSalaryHistoryLog_Insert
             	@Id int ,
		@Amount float  = NULL,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@Date datetime  = NULL,
		@IsDeleted bit  = NULL,
		@CreatedDate date  = NULL,
		@SalaryId int  = NULL
             AS
                INSERT INTO tblSalaryHistoryLog(Amount,EmployeeId,SalaryTypeId,Date,IsDeleted,CreatedDate,SalaryId)
                VALUES (@Amount,@EmployeeId,@SalaryTypeId,@Date,@IsDeleted,@CreatedDate,@SalaryId)
                SELECT * FROM tblSalaryHistoryLog WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblSalaryHistoryLog_Update
             	@Id int ,
		@Amount float  = NULL,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@Date datetime  = NULL,
		@IsDeleted bit  = NULL,
		@CreatedDate date  = NULL,
		@SalaryId int  = NULL
             AS
                UPDATE tblSalaryHistoryLog
                SET Amount=@Amount,EmployeeId=@EmployeeId,SalaryTypeId=@SalaryTypeId,Date=@Date,IsDeleted=@IsDeleted,CreatedDate=@CreatedDate,SalaryId=@SalaryId
                WHERE Id = @Id
                SELECT * FROM tblSalaryHistoryLog WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblSalaryHistoryLog_GetById
             @Id INT
             AS
                SELECT * FROM tblSalaryHistoryLog
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblSalaryHistoryLog_DeleteById
                @Id INT
             AS
                DELETE FROM tblSalaryHistoryLog
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefSalaryType_GetAll
             AS
                SELECT * FROM tblRefSalaryType
             GO
            

             ALTER PROCEDURE tblRefSalaryType_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefSalaryType(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefSalaryType WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefSalaryType_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefSalaryType
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefSalaryType WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefSalaryType_GetById
             @Id INT
             AS
                SELECT * FROM tblRefSalaryType
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefSalaryType_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefSalaryType
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblSalary_GetAll
             AS
                SELECT * FROM tblSalary
             GO
            

             ALTER PROCEDURE tblSalary_Insert
             	@Id int ,
		@Amount float  = NULL,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@Date datetime  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblSalary(Amount,EmployeeId,SalaryTypeId,Date,IsDeleted)
                VALUES (@Amount,@EmployeeId,@SalaryTypeId,@Date,@IsDeleted)
                SELECT * FROM tblSalary WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblSalary_Update
             	@Id int ,
		@Amount float  = NULL,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@Date datetime  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblSalary
                SET Amount=@Amount,EmployeeId=@EmployeeId,SalaryTypeId=@SalaryTypeId,Date=@Date,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblSalary WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblSalary_GetById
             @Id INT
             AS
                SELECT * FROM tblSalary
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblSalary_DeleteById
                @Id INT
             AS
                DELETE FROM tblSalary
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblPayrollAccountNumber_GetAll
             AS
                SELECT * FROM tblPayrollAccountNumber
             GO
            

             ALTER PROCEDURE tblPayrollAccountNumber_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@AccountNumber nvarchar(MAX)  = NULL
             AS
                INSERT INTO tblPayrollAccountNumber(EmployeeId,AccountNumber)
                VALUES (@EmployeeId,@AccountNumber)
                SELECT * FROM tblPayrollAccountNumber WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblPayrollAccountNumber_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@AccountNumber nvarchar(MAX)  = NULL
             AS
                UPDATE tblPayrollAccountNumber
                SET EmployeeId=@EmployeeId,AccountNumber=@AccountNumber
                WHERE Id = @Id
                SELECT * FROM tblPayrollAccountNumber WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblPayrollAccountNumber_GetById
             @Id INT
             AS
                SELECT * FROM tblPayrollAccountNumber
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblPayrollAccountNumber_DeleteById
                @Id INT
             AS
                DELETE FROM tblPayrollAccountNumber
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblRefEmploymentCategoryType_GetAll
             AS
                SELECT * FROM tblRefEmploymentCategoryType
             GO
            

             ALTER PROCEDURE tblRefEmploymentCategoryType_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefEmploymentCategoryType(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefEmploymentCategoryType WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblRefEmploymentCategoryType_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefEmploymentCategoryType
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefEmploymentCategoryType WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefEmploymentCategoryType_GetById
             @Id INT
             AS
                SELECT * FROM tblRefEmploymentCategoryType
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblRefEmploymentCategoryType_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefEmploymentCategoryType
                WHERE Id =  @Id
             GO
            

             ALTER PROCEDURE tblEmployeeCategory_GetAll
             AS
                SELECT * FROM tblEmployeeCategory
             GO
            

             ALTER PROCEDURE tblEmployeeCategory_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@CategoryTypeId int  = NULL,
		@DepartmentId int  = NULL
             AS
                INSERT INTO tblEmployeeCategory(EmployeeId,CategoryTypeId,DepartmentId)
                VALUES (@EmployeeId,@CategoryTypeId,@DepartmentId)
                SELECT * FROM tblEmployeeCategory WHERE Id = SCOPE_IDENTITY()
             GO
            

             ALTER PROCEDURE tblEmployeeCategory_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@CategoryTypeId int  = NULL,
		@DepartmentId int  = NULL
             AS
                UPDATE tblEmployeeCategory
                SET EmployeeId=@EmployeeId,CategoryTypeId=@CategoryTypeId,DepartmentId=@DepartmentId
                WHERE Id = @Id
                SELECT * FROM tblEmployeeCategory WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblEmployeeCategory_GetById
             @Id INT
             AS
                SELECT * FROM tblEmployeeCategory
                WHERE Id = @Id
             GO
            

             ALTER PROCEDURE tblEmployeeCategory_DeleteById
                @Id INT
             AS
                DELETE FROM tblEmployeeCategory
                WHERE Id =  @Id
             GO
            
