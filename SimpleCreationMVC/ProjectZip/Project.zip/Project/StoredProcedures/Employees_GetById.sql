
             CREATE PROCEDURE Employees_GetById
             @Id INT
             AS
                SELECT * FROM Employees
                WHERE Id = @Id
             GO
            