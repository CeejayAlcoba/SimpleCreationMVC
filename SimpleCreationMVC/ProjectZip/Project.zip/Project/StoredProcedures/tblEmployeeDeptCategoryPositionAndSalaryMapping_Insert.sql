
             ALTER PROCEDURE tblEmployeeDeptCategoryPositionAndSalaryMapping_Insert
             @Id int = NULL,
             	@EmployeeId int  = NULL,
		@DepartmentId int  = NULL,
		@EmploymentTypeId int  = NULL,
		@EmployeeCurrentPositionId int  = NULL,
		@EmployeeSalaryId int  = NULL
             AS
                INSERT INTO tblEmployeeDeptCategoryPositionAndSalaryMapping(EmployeeId,DepartmentId,EmploymentTypeId,EmployeeCurrentPositionId,EmployeeSalaryId)
                VALUES (@EmployeeId,@DepartmentId,@EmploymentTypeId,@EmployeeCurrentPositionId,@EmployeeSalaryId)
                SELECT * FROM tblEmployeeDeptCategoryPositionAndSalaryMapping WHERE Id = SCOPE_IDENTITY()
             GO
            