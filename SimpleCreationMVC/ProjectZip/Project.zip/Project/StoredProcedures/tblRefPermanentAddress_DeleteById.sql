
             ALTER PROCEDURE tblRefPermanentAddress_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefPermanentAddress
                WHERE Id =  @Id
             GO
            