
CREATE PROCEDURE Test_DeleteById
    @Id INT
AS
    DELETE FROM Test
    WHERE Id =  @Id
GO
            