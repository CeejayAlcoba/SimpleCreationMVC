
             ALTER PROCEDURE tblSalaryHistoryLog_Insert
             	@Id int ,
		@Amount float  = NULL,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@Date datetime  = NULL,
		@IsDeleted bit  = NULL,
		@CreatedDate date  = NULL,
		@SalaryId int  = NULL
             AS
                INSERT INTO tblSalaryHistoryLog(Amount,EmployeeId,SalaryTypeId,Date,IsDeleted,CreatedDate,SalaryId)
                VALUES (@Amount,@EmployeeId,@SalaryTypeId,@Date,@IsDeleted,@CreatedDate,@SalaryId)
                SELECT * FROM tblSalaryHistoryLog WHERE Id = SCOPE_IDENTITY()
             GO
            