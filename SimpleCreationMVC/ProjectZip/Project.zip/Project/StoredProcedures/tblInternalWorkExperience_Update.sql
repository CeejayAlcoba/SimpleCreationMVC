
             ALTER PROCEDURE tblInternalWorkExperience_Update
             	@Id int ,
		@Position nvarchar(MAX)  = NULL,
		@Department nvarchar(MAX)  = NULL,
		@EffectivityDate datetime  = NULL,
		@InternalCompanyId int  = NULL,
		@JobLevelId int  = NULL,
		@AppointmentId int  = NULL,
		@EmployeeId int  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                UPDATE tblInternalWorkExperience
                SET Position=@Position,Department=@Department,EffectivityDate=@EffectivityDate,InternalCompanyId=@InternalCompanyId,JobLevelId=@JobLevelId,AppointmentId=@AppointmentId,EmployeeId=@EmployeeId,IsDeleted=@IsDeleted,ApplicantId=@ApplicantId
                WHERE Id = @Id
                SELECT * FROM tblInternalWorkExperience WHERE Id = @Id
             GO
            