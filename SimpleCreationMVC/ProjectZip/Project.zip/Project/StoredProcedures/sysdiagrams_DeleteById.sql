
             CREATE PROCEDURE sysdiagrams_DeleteById
                @Id INT
             AS
                DELETE FROM sysdiagrams
                WHERE diagram_id =  @Id
             GO
            