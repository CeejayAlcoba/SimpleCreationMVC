
             ALTER PROCEDURE tblRefDepartmentCategory_GetAll
             AS
                SELECT * FROM tblRefDepartmentCategory
             GO
            