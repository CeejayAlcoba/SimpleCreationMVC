
             ALTER PROCEDURE tblEmployeeCurrentPosition_GetById
             @Id INT
             AS
                SELECT * FROM tblEmployeeCurrentPosition
                WHERE Id = @Id
             GO
            