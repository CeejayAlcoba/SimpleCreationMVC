
             ALTER PROCEDURE tblRefChildren_Insert
             	@Id int ,
		@FamilyId int  = NULL,
		@Name nvarchar(MAX)  = NULL,
		@GradeLevelId int  = NULL,
		@IsDeleted bit  = NULL,
		@Birthday date  = NULL
             AS
                INSERT INTO tblRefChildren(FamilyId,Name,GradeLevelId,IsDeleted,Birthday)
                VALUES (@FamilyId,@Name,@GradeLevelId,@IsDeleted,@Birthday)
                SELECT * FROM tblRefChildren WHERE Id = SCOPE_IDENTITY()
             GO
            