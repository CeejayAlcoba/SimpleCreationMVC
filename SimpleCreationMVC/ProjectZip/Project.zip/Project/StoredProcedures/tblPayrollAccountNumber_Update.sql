
             ALTER PROCEDURE tblPayrollAccountNumber_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@AccountNumber nvarchar(MAX)  = NULL
             AS
                UPDATE tblPayrollAccountNumber
                SET EmployeeId=@EmployeeId,AccountNumber=@AccountNumber
                WHERE Id = @Id
                SELECT * FROM tblPayrollAccountNumber WHERE Id = @Id
             GO
            