
             ALTER PROCEDURE tblRefDepartment_GetAll
             AS
                SELECT * FROM tblRefDepartment
             GO
            