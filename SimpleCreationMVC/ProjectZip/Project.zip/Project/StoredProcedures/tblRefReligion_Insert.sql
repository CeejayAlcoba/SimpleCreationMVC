
             ALTER PROCEDURE tblRefReligion_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefReligion(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefReligion WHERE Id = SCOPE_IDENTITY()
             GO
            