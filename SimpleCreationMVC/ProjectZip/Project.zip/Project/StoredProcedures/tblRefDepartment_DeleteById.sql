
             ALTER PROCEDURE tblRefDepartment_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefDepartment
                WHERE Id =  @Id
             GO
            