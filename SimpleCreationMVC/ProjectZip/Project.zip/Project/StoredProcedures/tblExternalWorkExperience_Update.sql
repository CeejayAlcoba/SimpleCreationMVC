
             ALTER PROCEDURE tblExternalWorkExperience_Update
             	@Id int ,
		@Position nvarchar(MAX)  = NULL,
		@Employer nvarchar(MAX)  = NULL,
		@LengthOfService nvarchar(MAX)  = NULL,
		@ReasonOfLeaving nvarchar(MAX)  = NULL,
		@EmployeeId int  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                UPDATE tblExternalWorkExperience
                SET Position=@Position,Employer=@Employer,LengthOfService=@LengthOfService,ReasonOfLeaving=@ReasonOfLeaving,EmployeeId=@EmployeeId,IsDeleted=@IsDeleted,ApplicantId=@ApplicantId
                WHERE Id = @Id
                SELECT * FROM tblExternalWorkExperience WHERE Id = @Id
             GO
            