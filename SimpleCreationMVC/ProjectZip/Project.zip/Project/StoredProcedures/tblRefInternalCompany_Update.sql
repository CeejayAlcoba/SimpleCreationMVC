
             ALTER PROCEDURE tblRefInternalCompany_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefInternalCompany
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefInternalCompany WHERE Id = @Id
             GO
            