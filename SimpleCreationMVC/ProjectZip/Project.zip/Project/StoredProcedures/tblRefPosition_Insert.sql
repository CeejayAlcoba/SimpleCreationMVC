
             ALTER PROCEDURE tblRefPosition_Insert
             @Id int = NULL,
             	@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefPosition(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefPosition WHERE Id = SCOPE_IDENTITY()
             GO
            