
             ALTER PROCEDURE tblRefEmploymentCategoryType_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefEmploymentCategoryType
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefEmploymentCategoryType WHERE Id = @Id
             GO
            