
             ALTER PROCEDURE tblEducationalData_DeleteById
                @Id INT
             AS
                DELETE FROM tblEducationalData
                WHERE Id =  @Id
             GO
            