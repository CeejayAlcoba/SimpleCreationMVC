
             ALTER PROCEDURE tblRefCivilStatus_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefCivilStatus
                WHERE Id =  @Id
             GO
            