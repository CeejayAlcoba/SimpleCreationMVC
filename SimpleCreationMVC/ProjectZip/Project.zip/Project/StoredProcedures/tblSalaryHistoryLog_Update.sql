
             ALTER PROCEDURE tblSalaryHistoryLog_Update
             	@Id int ,
		@Amount float  = NULL,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@Date datetime  = NULL,
		@IsDeleted bit  = NULL,
		@CreatedDate date  = NULL,
		@SalaryId int  = NULL
             AS
                UPDATE tblSalaryHistoryLog
                SET Amount=@Amount,EmployeeId=@EmployeeId,SalaryTypeId=@SalaryTypeId,Date=@Date,IsDeleted=@IsDeleted,CreatedDate=@CreatedDate,SalaryId=@SalaryId
                WHERE Id = @Id
                SELECT * FROM tblSalaryHistoryLog WHERE Id = @Id
             GO
            