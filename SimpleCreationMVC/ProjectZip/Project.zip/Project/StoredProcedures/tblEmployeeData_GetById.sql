
             ALTER PROCEDURE tblEmployeeData_GetById
             @Id INT
             AS
                SELECT * FROM tblEmployeeData
                WHERE Id = @Id
             GO
            