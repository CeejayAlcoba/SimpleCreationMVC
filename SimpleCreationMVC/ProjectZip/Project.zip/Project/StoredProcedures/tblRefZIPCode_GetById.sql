
             ALTER PROCEDURE tblRefZIPCode_GetById
             @Id INT
             AS
                SELECT * FROM tblRefZIPCode
                WHERE Id = @Id
             GO
            