
             ALTER PROCEDURE tblPayrollAccountNumber_DeleteById
                @Id INT
             AS
                DELETE FROM tblPayrollAccountNumber
                WHERE Id =  @Id
             GO
            