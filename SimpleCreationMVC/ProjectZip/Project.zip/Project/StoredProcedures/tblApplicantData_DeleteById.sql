
             ALTER PROCEDURE tblApplicantData_DeleteById
                @Id INT
             AS
                DELETE FROM tblApplicantData
                WHERE Id =  @Id
             GO
            