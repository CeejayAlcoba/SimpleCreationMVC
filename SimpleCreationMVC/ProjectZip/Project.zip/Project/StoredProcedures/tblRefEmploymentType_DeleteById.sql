
             ALTER PROCEDURE tblRefEmploymentType_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefEmploymentType
                WHERE Id =  @Id
             GO
            