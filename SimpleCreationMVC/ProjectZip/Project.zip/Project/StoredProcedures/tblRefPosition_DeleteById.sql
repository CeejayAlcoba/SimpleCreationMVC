
             ALTER PROCEDURE tblRefPosition_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefPosition
                WHERE Id =  @Id
             GO
            