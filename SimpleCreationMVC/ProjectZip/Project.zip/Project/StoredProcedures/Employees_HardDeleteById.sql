
             CREATE PROCEDURE Employees_HardDeleteById
                @Id INT
             AS
                DELETE FROM Employees
                WHERE Id =  @Id
             GO
            