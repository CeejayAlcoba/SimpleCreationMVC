
             ALTER PROCEDURE tblPayrollAccountNumber_GetAll
             AS
                SELECT * FROM tblPayrollAccountNumber
             GO
            