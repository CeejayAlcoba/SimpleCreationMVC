
             ALTER PROCEDURE tblEmployeeData_Insert
             	@Id int ,
		@LastName nvarchar(100)  = NULL,
		@FirstName nvarchar(100)  = NULL,
		@MiddleName nvarchar(100)  = NULL,
		@GenderId int  = NULL,
		@CivilStatusId int  = NULL,
		@ReligionId int  = NULL,
		@PlaceOfBirth nvarchar(MAX)  = NULL,
		@NationalIdNumber nvarchar(MAX)  = NULL,
		@SSSNumber nvarchar(MAX)  = NULL,
		@HDMFNumber nvarchar(MAX)  = NULL,
		@PHICNumber nvarchar(MAX)  = NULL,
		@TIN nvarchar(MAX)  = NULL,
		@HMOCardNumber nvarchar(MAX)  = NULL,
		@HMOAccountNumber nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@BirthDate date  = NULL,
		@DateHired date  = NULL
             AS
                INSERT INTO tblEmployeeData(LastName,FirstName,MiddleName,GenderId,CivilStatusId,ReligionId,PlaceOfBirth,NationalIdNumber,SSSNumber,HDMFNumber,PHICNumber,TIN,HMOCardNumber,HMOAccountNumber,IsDeleted,BirthDate,DateHired)
                VALUES (@LastName,@FirstName,@MiddleName,@GenderId,@CivilStatusId,@ReligionId,@PlaceOfBirth,@NationalIdNumber,@SSSNumber,@HDMFNumber,@PHICNumber,@TIN,@HMOCardNumber,@HMOAccountNumber,@IsDeleted,@BirthDate,@DateHired)
                SELECT * FROM tblEmployeeData WHERE Id = SCOPE_IDENTITY()
             GO
            