
             ALTER PROCEDURE tblRefCivilStatus_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefCivilStatus
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefCivilStatus WHERE Id = @Id
             GO
            