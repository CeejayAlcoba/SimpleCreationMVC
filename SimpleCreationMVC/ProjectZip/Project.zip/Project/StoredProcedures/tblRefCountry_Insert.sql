
             ALTER PROCEDURE tblRefCountry_Insert
             @Id int = NULL,
             	@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@Code nvarchar(10)  = NULL
             AS
                INSERT INTO tblRefCountry(Description,IsDeleted,Code)
                VALUES (@Description,@IsDeleted,@Code)
                SELECT * FROM tblRefCountry WHERE Id = SCOPE_IDENTITY()
             GO
            