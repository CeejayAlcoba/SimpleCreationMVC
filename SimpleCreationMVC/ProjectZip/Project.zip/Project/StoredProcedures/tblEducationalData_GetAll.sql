
             ALTER PROCEDURE tblEducationalData_GetAll
             AS
                SELECT * FROM tblEducationalData
             GO
            