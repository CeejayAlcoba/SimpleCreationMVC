
ALTER PROCEDURE Projects_DeleteById
    @Id INT
AS
    DELETE FROM Projects
    WHERE Id =  @Id
GO
            