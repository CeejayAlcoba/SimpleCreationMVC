
             ALTER PROCEDURE tblSalary_Insert
             	@Id int ,
		@Amount float  = NULL,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@Date datetime  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblSalary(Amount,EmployeeId,SalaryTypeId,Date,IsDeleted)
                VALUES (@Amount,@EmployeeId,@SalaryTypeId,@Date,@IsDeleted)
                SELECT * FROM tblSalary WHERE Id = SCOPE_IDENTITY()
             GO
            