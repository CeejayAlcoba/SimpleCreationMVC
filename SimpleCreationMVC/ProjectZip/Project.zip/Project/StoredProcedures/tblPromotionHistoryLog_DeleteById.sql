
             ALTER PROCEDURE tblPromotionHistoryLog_DeleteById
                @Id INT
             AS
                DELETE FROM tblPromotionHistoryLog
                WHERE Id =  @Id
             GO
            