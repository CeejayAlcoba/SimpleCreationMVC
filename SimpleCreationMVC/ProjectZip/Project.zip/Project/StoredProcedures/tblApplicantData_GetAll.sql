
             ALTER PROCEDURE tblApplicantData_GetAll
             AS
                SELECT * FROM tblApplicantData
             GO
            