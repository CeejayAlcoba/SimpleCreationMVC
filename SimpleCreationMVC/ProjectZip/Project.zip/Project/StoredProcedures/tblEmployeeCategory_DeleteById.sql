
             ALTER PROCEDURE tblEmployeeCategory_DeleteById
                @Id INT
             AS
                DELETE FROM tblEmployeeCategory
                WHERE Id =  @Id
             GO
            