
             ALTER PROCEDURE tblRefAppointment_GetById
             @Id INT
             AS
                SELECT * FROM tblRefAppointment
                WHERE Id = @Id
             GO
            