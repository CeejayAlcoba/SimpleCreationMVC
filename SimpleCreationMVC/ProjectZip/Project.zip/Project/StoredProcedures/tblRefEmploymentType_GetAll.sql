
             ALTER PROCEDURE tblRefEmploymentType_GetAll
             AS
                SELECT * FROM tblRefEmploymentType
             GO
            