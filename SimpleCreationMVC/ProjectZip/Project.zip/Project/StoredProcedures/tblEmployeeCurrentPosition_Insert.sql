
             ALTER PROCEDURE tblEmployeeCurrentPosition_Insert
             	@Id int ,
		@EmployeeId int  = NULL,
		@PositionId int  = NULL,
		@DepartmentId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL
             AS
                INSERT INTO tblEmployeeCurrentPosition(EmployeeId,PositionId,DepartmentId,AlternativePosition)
                VALUES (@EmployeeId,@PositionId,@DepartmentId,@AlternativePosition)
                SELECT * FROM tblEmployeeCurrentPosition WHERE Id = SCOPE_IDENTITY()
             GO
            