
             CREATE PROCEDURE tblEmployeeCorporateData_Insert
             @Id int = NULL,
             	@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@DepartmentId int  = NULL,
		@EmploymentTypeId int  = NULL,
		@PositionId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL,
		@SalaryAmount float  = NULL
             AS
                INSERT INTO tblEmployeeCorporateData(EmployeeId,SalaryTypeId,DepartmentId,EmploymentTypeId,PositionId,AlternativePosition,SalaryAmount)
                VALUES (@EmployeeId,@SalaryTypeId,@DepartmentId,@EmploymentTypeId,@PositionId,@AlternativePosition,@SalaryAmount)
                SELECT * FROM tblEmployeeCorporateData WHERE Id = SCOPE_IDENTITY()
             GO
            