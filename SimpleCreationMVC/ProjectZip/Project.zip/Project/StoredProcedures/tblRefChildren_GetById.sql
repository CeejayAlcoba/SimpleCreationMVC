
             ALTER PROCEDURE tblRefChildren_GetById
             @Id INT
             AS
                SELECT * FROM tblRefChildren
                WHERE Id = @Id
             GO
            