
             ALTER PROCEDURE tblRefDepartmentCategory_Insert
             @Id int = NULL,
             	@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefDepartmentCategory(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefDepartmentCategory WHERE Id = SCOPE_IDENTITY()
             GO
            