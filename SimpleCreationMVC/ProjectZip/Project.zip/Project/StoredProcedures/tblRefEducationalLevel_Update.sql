
             ALTER PROCEDURE tblRefEducationalLevel_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefEducationalLevel
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefEducationalLevel WHERE Id = @Id
             GO
            