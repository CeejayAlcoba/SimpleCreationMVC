
             ALTER PROCEDURE tblRefMunicipality_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@ProvinceId int  = NULL
             AS
                UPDATE tblRefMunicipality
                SET Description=@Description,IsDeleted=@IsDeleted,ProvinceId=@ProvinceId
                WHERE Id = @Id
                SELECT * FROM tblRefMunicipality WHERE Id = @Id
             GO
            