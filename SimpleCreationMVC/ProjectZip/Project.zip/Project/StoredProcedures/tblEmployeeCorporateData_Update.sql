
             CREATE PROCEDURE tblEmployeeCorporateData_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@DepartmentId int  = NULL,
		@EmploymentTypeId int  = NULL,
		@PositionId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL,
		@SalaryAmount float  = NULL
             AS
                UPDATE tblEmployeeCorporateData
                SET EmployeeId=@EmployeeId,SalaryTypeId=@SalaryTypeId,DepartmentId=@DepartmentId,EmploymentTypeId=@EmploymentTypeId,PositionId=@PositionId,AlternativePosition=@AlternativePosition,SalaryAmount=@SalaryAmount
                WHERE Id = @Id
                SELECT * FROM tblEmployeeCorporateData WHERE Id = @Id
             GO
            