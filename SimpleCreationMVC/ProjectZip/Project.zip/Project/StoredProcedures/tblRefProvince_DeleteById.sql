
             ALTER PROCEDURE tblRefProvince_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefProvince
                WHERE Id =  @Id
             GO
            