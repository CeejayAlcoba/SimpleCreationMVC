
             ALTER PROCEDURE tblRefReligion_GetById
             @Id INT
             AS
                SELECT * FROM tblRefReligion
                WHERE Id = @Id
             GO
            