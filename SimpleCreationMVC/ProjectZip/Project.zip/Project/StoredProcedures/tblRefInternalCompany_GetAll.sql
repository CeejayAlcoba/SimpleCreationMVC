
             ALTER PROCEDURE tblRefInternalCompany_GetAll
             AS
                SELECT * FROM tblRefInternalCompany
             GO
            