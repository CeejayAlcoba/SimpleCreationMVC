
             CREATE PROCEDURE sysdiagrams_Insert
             @diagram_id int = NULL,
             	@name nvarchar(128) ,
		@principal_id int ,
		@version int  = NULL,
		@definition varbinary  = NULL
             AS
                INSERT INTO sysdiagrams(name,principal_id,version,definition)
                VALUES (@name,@principal_id,@version,@definition)
                SELECT * FROM sysdiagrams WHERE diagram_id = SCOPE_IDENTITY()
             GO
            