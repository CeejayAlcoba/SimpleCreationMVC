
CREATE PROCEDURE Children_Insert
    @Id int = NULL,
	@Name nvarchar(100)  = NULL,
	@Bday date  = NULL,
	@GradeLevel nvarchar(50)  = NULL,
	@FamilyId int 
AS
   INSERT INTO Children(
		Name,
		Bday,
		GradeLevel,
		FamilyId
        )
   VALUES (
		@Name,
		@Bday,
		@GradeLevel,
		@FamilyId
        )
   SELECT * FROM Children WHERE Id = SCOPE_IDENTITY()
GO
            