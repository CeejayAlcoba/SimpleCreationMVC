
             CREATE PROCEDURE tblEmployeeCorporateData_DeleteById
                @Id INT
             AS
                DELETE FROM tblEmployeeCorporateData
                WHERE Id =  @Id
             GO
            