
             ALTER PROCEDURE tblRefChildren_GetAll
             AS
                SELECT * FROM tblRefChildren
             GO
            