
             ALTER PROCEDURE tblRefPermanentAddress_GetAll
             AS
                SELECT * FROM tblRefPermanentAddress
             GO
            