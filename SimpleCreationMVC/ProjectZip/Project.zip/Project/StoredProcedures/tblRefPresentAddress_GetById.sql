
             ALTER PROCEDURE tblRefPresentAddress_GetById
             @Id INT
             AS
                SELECT * FROM tblRefPresentAddress
                WHERE Id = @Id
             GO
            