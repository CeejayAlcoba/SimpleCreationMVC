
             ALTER PROCEDURE tblEmployeeCurrentPosition_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@PositionId int  = NULL,
		@DepartmentId int  = NULL,
		@AlternativePosition nvarchar(MAX)  = NULL
             AS
                UPDATE tblEmployeeCurrentPosition
                SET EmployeeId=@EmployeeId,PositionId=@PositionId,DepartmentId=@DepartmentId,AlternativePosition=@AlternativePosition
                WHERE Id = @Id
                SELECT * FROM tblEmployeeCurrentPosition WHERE Id = @Id
             GO
            