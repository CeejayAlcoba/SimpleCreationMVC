
             ALTER PROCEDURE tblRefChildren_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefChildren
                WHERE Id =  @Id
             GO
            