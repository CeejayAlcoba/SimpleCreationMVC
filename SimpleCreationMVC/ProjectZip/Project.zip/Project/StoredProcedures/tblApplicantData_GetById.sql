
             ALTER PROCEDURE tblApplicantData_GetById
             @Id INT
             AS
                SELECT * FROM tblApplicantData
                WHERE Id = @Id
             GO
            