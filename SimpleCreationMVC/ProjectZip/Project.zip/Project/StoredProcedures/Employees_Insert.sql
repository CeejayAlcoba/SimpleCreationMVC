
             CREATE PROCEDURE Employees_Insert
             	@Id int ,
		@FirstName nvarchar(50) ,
		@MiddleName nvarchar(50)  = NULL,
		@LastName nvarchar(50) ,
		@DateHire date  = NULL,
		@Gender nvarchar(10)  = NULL,
		@CivilStatus nvarchar(20)  = NULL,
		@Religion nvarchar(50)  = NULL,
		@Birthdate date  = NULL,
		@PlaceOfBirth nvarchar(100)  = NULL,
		@PresentAddress nvarchar(200)  = NULL,
		@PermanentAddress nvarchar(200)  = NULL,
		@NationalIDNumber nvarchar(20)  = NULL,
		@SSSNumber nvarchar(20)  = NULL,
		@HDMFNumber nvarchar(20)  = NULL,
		@PHICNumber nvarchar(20)  = NULL,
		@TIN nvarchar(20)  = NULL,
		@HMOCardNumber nvarchar(20)  = NULL,
		@HMOAccountNumber nvarchar(20)  = NULL
             AS
                INSERT INTO Employees(FirstName,MiddleName,LastName,DateHire,Gender,CivilStatus,Religion,Birthdate,PlaceOfBirth,PresentAddress,PermanentAddress,NationalIDNumber,SSSNumber,HDMFNumber,PHICNumber,TIN,HMOCardNumber,HMOAccountNumber)
                VALUES (@FirstName,@MiddleName,@LastName,@DateHire,@Gender,@CivilStatus,@Religion,@Birthdate,@PlaceOfBirth,@PresentAddress,@PermanentAddress,@NationalIDNumber,@SSSNumber,@HDMFNumber,@PHICNumber,@TIN,@HMOCardNumber,@HMOAccountNumber)
                SELECT * FROM Employees WHERE Id = SCOPE_IDENTITY()
             GO
            