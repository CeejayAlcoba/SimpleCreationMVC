
             ALTER PROCEDURE tblRefMunicipality_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@ProvinceId int  = NULL
             AS
                INSERT INTO tblRefMunicipality(Description,IsDeleted,ProvinceId)
                VALUES (@Description,@IsDeleted,@ProvinceId)
                SELECT * FROM tblRefMunicipality WHERE Id = SCOPE_IDENTITY()
             GO
            