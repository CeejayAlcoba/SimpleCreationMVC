
             ALTER PROCEDURE tblRefGradeLevel_Insert
             @Id int = NULL,
             	@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefGradeLevel(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefGradeLevel WHERE Id = SCOPE_IDENTITY()
             GO
            