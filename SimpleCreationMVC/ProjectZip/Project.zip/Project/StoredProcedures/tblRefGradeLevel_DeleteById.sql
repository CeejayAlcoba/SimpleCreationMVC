
             ALTER PROCEDURE tblRefGradeLevel_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefGradeLevel
                WHERE Id =  @Id
             GO
            