
             ALTER PROCEDURE tblRefReligion_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefReligion
                WHERE Id =  @Id
             GO
            