
             ALTER PROCEDURE tblRefPresentAddress_GetAll
             AS
                SELECT * FROM tblRefPresentAddress
             GO
            