
             ALTER PROCEDURE tblEmployeeDeptCategoryPositionAndSalaryMapping_DeleteById
                @Id INT
             AS
                DELETE FROM tblEmployeeDeptCategoryPositionAndSalaryMapping
                WHERE Id =  @Id
             GO
            