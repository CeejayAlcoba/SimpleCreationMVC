
ALTER PROCEDURE Developers_Update
	@Id int ,
	@Name nvarchar(MAX) ,
	@Folowers int 
AS
   UPDATE Developers
   SET 
		Name=@Name,
		Folowers=@Folowers
    WHERE Id = @Id
    SELECT * FROM Developers WHERE Id = @Id
 GO
            