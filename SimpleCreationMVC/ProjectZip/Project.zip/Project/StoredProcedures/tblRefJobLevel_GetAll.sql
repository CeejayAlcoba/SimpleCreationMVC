
             ALTER PROCEDURE tblRefJobLevel_GetAll
             AS
                SELECT * FROM tblRefJobLevel
             GO
            