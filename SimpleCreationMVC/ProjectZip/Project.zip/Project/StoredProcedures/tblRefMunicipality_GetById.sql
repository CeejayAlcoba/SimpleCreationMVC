
             ALTER PROCEDURE tblRefMunicipality_GetById
             @Id INT
             AS
                SELECT * FROM tblRefMunicipality
                WHERE Id = @Id
             GO
            