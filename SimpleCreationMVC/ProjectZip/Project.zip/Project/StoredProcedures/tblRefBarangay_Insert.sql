
             ALTER PROCEDURE tblRefBarangay_Insert
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@MunicipalityId int  = NULL
             AS
                INSERT INTO tblRefBarangay(Description,IsDeleted,MunicipalityId)
                VALUES (@Description,@IsDeleted,@MunicipalityId)
                SELECT * FROM tblRefBarangay WHERE Id = SCOPE_IDENTITY()
             GO
            