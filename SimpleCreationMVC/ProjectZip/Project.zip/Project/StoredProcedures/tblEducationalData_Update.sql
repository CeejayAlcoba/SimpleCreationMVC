
             ALTER PROCEDURE tblEducationalData_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@EducationalLevelId int  = NULL,
		@School nvarchar(MAX)  = NULL,
		@YearGraduate nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                UPDATE tblEducationalData
                SET EmployeeId=@EmployeeId,EducationalLevelId=@EducationalLevelId,School=@School,YearGraduate=@YearGraduate,IsDeleted=@IsDeleted,ApplicantId=@ApplicantId
                WHERE Id = @Id
                SELECT * FROM tblEducationalData WHERE Id = @Id
             GO
            