
             ALTER PROCEDURE tblFamilyData_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@MotherMaidenName nvarchar(MAX)  = NULL,
		@FatherName nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@ApplicantId int  = NULL
             AS
                UPDATE tblFamilyData
                SET EmployeeId=@EmployeeId,MotherMaidenName=@MotherMaidenName,FatherName=@FatherName,IsDeleted=@IsDeleted,ApplicantId=@ApplicantId
                WHERE Id = @Id
                SELECT * FROM tblFamilyData WHERE Id = @Id
             GO
            