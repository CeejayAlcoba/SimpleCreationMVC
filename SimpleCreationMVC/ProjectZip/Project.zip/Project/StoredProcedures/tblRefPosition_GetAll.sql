
             ALTER PROCEDURE tblRefPosition_GetAll
             AS
                SELECT * FROM tblRefPosition
             GO
            