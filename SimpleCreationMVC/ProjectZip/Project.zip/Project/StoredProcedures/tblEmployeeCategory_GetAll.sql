
             ALTER PROCEDURE tblEmployeeCategory_GetAll
             AS
                SELECT * FROM tblEmployeeCategory
             GO
            