
             ALTER PROCEDURE tblRefDepartmentCategory_GetById
             @Id INT
             AS
                SELECT * FROM tblRefDepartmentCategory
                WHERE Id = @Id
             GO
            