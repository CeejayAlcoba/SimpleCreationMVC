
             ALTER PROCEDURE tblRefCivilStatus_GetById
             @Id INT
             AS
                SELECT * FROM tblRefCivilStatus
                WHERE Id = @Id
             GO
            