
             ALTER PROCEDURE tblRefCountry_GetAll
             AS
                SELECT * FROM tblRefCountry
             GO
            