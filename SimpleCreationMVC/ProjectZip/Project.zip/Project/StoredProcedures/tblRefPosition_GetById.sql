
             ALTER PROCEDURE tblRefPosition_GetById
             @Id INT
             AS
                SELECT * FROM tblRefPosition
                WHERE Id = @Id
             GO
            