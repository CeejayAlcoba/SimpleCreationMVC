
             ALTER PROCEDURE tblRefProvince_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@CountryId int  = NULL
             AS
                UPDATE tblRefProvince
                SET Description=@Description,IsDeleted=@IsDeleted,CountryId=@CountryId
                WHERE Id = @Id
                SELECT * FROM tblRefProvince WHERE Id = @Id
             GO
            