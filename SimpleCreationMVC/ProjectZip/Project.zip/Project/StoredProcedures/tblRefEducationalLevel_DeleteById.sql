
             ALTER PROCEDURE tblRefEducationalLevel_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefEducationalLevel
                WHERE Id =  @Id
             GO
            