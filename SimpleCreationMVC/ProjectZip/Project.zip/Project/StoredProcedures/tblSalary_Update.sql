
             ALTER PROCEDURE tblSalary_Update
             	@Id int ,
		@Amount float  = NULL,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@Date datetime  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblSalary
                SET Amount=@Amount,EmployeeId=@EmployeeId,SalaryTypeId=@SalaryTypeId,Date=@Date,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblSalary WHERE Id = @Id
             GO
            