
             ALTER PROCEDURE tblRefDepartment_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefDepartment(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefDepartment WHERE Id = SCOPE_IDENTITY()
             GO
            