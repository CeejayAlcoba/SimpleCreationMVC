
             ALTER PROCEDURE tblRefDepartment_Insert
             @Id int = NULL,
             	@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@DepartmentCategoryId int  = NULL
             AS
                INSERT INTO tblRefDepartment(Description,IsDeleted,DepartmentCategoryId)
                VALUES (@Description,@IsDeleted,@DepartmentCategoryId)
                SELECT * FROM tblRefDepartment WHERE Id = SCOPE_IDENTITY()
             GO
            