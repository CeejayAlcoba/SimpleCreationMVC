
             ALTER PROCEDURE tblSalary_GetById
             @Id INT
             AS
                SELECT * FROM tblSalary
                WHERE Id = @Id
             GO
            