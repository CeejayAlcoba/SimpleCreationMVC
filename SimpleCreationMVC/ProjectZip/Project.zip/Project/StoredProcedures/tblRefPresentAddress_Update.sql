
             ALTER PROCEDURE tblRefPresentAddress_Update
             	@Id int ,
		@EmployeeId int  = NULL,
		@BarangayId int  = NULL,
		@MunicipalityId int  = NULL,
		@ProvinceId int  = NULL,
		@CountryId int  = NULL,
		@ZIPCodeId int  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefPresentAddress
                SET EmployeeId=@EmployeeId,BarangayId=@BarangayId,MunicipalityId=@MunicipalityId,ProvinceId=@ProvinceId,CountryId=@CountryId,ZIPCodeId=@ZIPCodeId,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefPresentAddress WHERE Id = @Id
             GO
            