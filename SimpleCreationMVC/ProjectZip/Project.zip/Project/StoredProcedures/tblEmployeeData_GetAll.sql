
             ALTER PROCEDURE tblEmployeeData_GetAll
             AS
                SELECT * FROM tblEmployeeData
             GO
            