
CREATE PROCEDURE Children_GetAll
AS
    SELECT * FROM Children
GO
