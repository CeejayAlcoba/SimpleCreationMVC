
             ALTER PROCEDURE tblRefEmploymentCategoryType_GetAll
             AS
                SELECT * FROM tblRefEmploymentCategoryType
             GO
            