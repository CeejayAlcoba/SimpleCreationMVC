
             ALTER PROCEDURE tblRefZIPCode_GetAll
             AS
                SELECT * FROM tblRefZIPCode
             GO
            