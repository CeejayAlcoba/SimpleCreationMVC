
             ALTER PROCEDURE tblEmployeeDeptCategoryPositionAndSalaryMapping_GetAll
             AS
                SELECT * FROM tblEmployeeDeptCategoryPositionAndSalaryMapping
             GO
            