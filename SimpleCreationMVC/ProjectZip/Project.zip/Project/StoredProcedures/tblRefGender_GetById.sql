
             ALTER PROCEDURE tblRefGender_GetById
             @Id INT
             AS
                SELECT * FROM tblRefGender
                WHERE Id = @Id
             GO
            