
             ALTER PROCEDURE tblRefBarangay_GetAll
             AS
                SELECT * FROM tblRefBarangay
             GO
            