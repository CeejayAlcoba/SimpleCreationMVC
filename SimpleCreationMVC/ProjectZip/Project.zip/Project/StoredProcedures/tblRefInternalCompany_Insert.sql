
             ALTER PROCEDURE tblRefInternalCompany_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefInternalCompany(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefInternalCompany WHERE Id = SCOPE_IDENTITY()
             GO
            