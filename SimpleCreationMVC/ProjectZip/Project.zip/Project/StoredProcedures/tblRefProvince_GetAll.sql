
             ALTER PROCEDURE tblRefProvince_GetAll
             AS
                SELECT * FROM tblRefProvince
             GO
            