
             ALTER PROCEDURE tblEmployeeData_Update
             	@Id int ,
		@LastName nvarchar(100)  = NULL,
		@FirstName nvarchar(100)  = NULL,
		@MiddleName nvarchar(100)  = NULL,
		@GenderId int  = NULL,
		@CivilStatusId int  = NULL,
		@ReligionId int  = NULL,
		@PlaceOfBirth nvarchar(MAX)  = NULL,
		@NationalIdNumber nvarchar(MAX)  = NULL,
		@SSSNumber nvarchar(MAX)  = NULL,
		@HDMFNumber nvarchar(MAX)  = NULL,
		@PHICNumber nvarchar(MAX)  = NULL,
		@TIN nvarchar(MAX)  = NULL,
		@HMOCardNumber nvarchar(MAX)  = NULL,
		@HMOAccountNumber nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@BirthDate date  = NULL,
		@DateHired date  = NULL
             AS
                UPDATE tblEmployeeData
                SET LastName=@LastName,FirstName=@FirstName,MiddleName=@MiddleName,GenderId=@GenderId,CivilStatusId=@CivilStatusId,ReligionId=@ReligionId,PlaceOfBirth=@PlaceOfBirth,NationalIdNumber=@NationalIdNumber,SSSNumber=@SSSNumber,HDMFNumber=@HDMFNumber,PHICNumber=@PHICNumber,TIN=@TIN,HMOCardNumber=@HMOCardNumber,HMOAccountNumber=@HMOAccountNumber,IsDeleted=@IsDeleted,BirthDate=@BirthDate,DateHired=@DateHired
                WHERE Id = @Id
                SELECT * FROM tblEmployeeData WHERE Id = @Id
             GO
            