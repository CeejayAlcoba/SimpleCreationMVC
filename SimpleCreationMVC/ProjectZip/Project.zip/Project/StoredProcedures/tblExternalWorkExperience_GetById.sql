
             ALTER PROCEDURE tblExternalWorkExperience_GetById
             @Id INT
             AS
                SELECT * FROM tblExternalWorkExperience
                WHERE Id = @Id
             GO
            