
             ALTER PROCEDURE tblRefZIPCode_Update
             	@Id int ,
		@Description nvarchar(50)  = NULL,
		@IsDeleted bit  = NULL,
		@MunicipalityId int  = NULL
             AS
                UPDATE tblRefZIPCode
                SET Description=@Description,IsDeleted=@IsDeleted,MunicipalityId=@MunicipalityId
                WHERE Id = @Id
                SELECT * FROM tblRefZIPCode WHERE Id = @Id
             GO
            