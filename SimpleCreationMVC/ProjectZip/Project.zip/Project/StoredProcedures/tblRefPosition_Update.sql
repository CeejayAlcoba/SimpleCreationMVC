
             ALTER PROCEDURE tblRefPosition_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefPosition
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefPosition WHERE Id = @Id
             GO
            