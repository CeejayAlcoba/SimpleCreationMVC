
             CREATE PROCEDURE sysdiagrams_GetById
             @Id INT
             AS
                SELECT * FROM sysdiagrams
                WHERE diagram_id = @Id
             GO
            