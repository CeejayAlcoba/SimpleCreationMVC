
             ALTER PROCEDURE tblRefMunicipality_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefMunicipality
                WHERE Id =  @Id
             GO
            