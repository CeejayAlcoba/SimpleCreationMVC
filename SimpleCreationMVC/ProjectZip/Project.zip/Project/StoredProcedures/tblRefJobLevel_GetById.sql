
             ALTER PROCEDURE tblRefJobLevel_GetById
             @Id INT
             AS
                SELECT * FROM tblRefJobLevel
                WHERE Id = @Id
             GO
            