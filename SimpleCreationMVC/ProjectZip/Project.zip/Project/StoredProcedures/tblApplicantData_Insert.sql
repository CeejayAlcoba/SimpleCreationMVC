
             ALTER PROCEDURE tblApplicantData_Insert
             @Id int = NULL,
             	@GenderId int  = NULL,
		@CivilStatusId int  = NULL,
		@ReligionId int  = NULL,
		@PlaceOfBirth nvarchar(MAX)  = NULL,
		@NationalIdNumber nvarchar(MAX)  = NULL,
		@SSSNumber nvarchar(MAX)  = NULL,
		@HDMFNumber nvarchar(MAX)  = NULL,
		@PHICNUmber nvarchar(MAX)  = NULL,
		@TIN nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL,
		@BirthDate date  = NULL,
		@LastName nvarchar(100)  = NULL,
		@FirstName nvarchar(100)  = NULL,
		@MiddleName nvarchar(100)  = NULL,
		@AppliedDate date  = NULL,
		@HMOCardNumber nvarchar(MAX)  = NULL,
		@HMOAccountNumber nvarchar(MAX)  = NULL
             AS
                INSERT INTO tblApplicantData(GenderId,CivilStatusId,ReligionId,PlaceOfBirth,NationalIdNumber,SSSNumber,HDMFNumber,PHICNUmber,TIN,IsDeleted,BirthDate,LastName,FirstName,MiddleName,AppliedDate,HMOCardNumber,HMOAccountNumber)
                VALUES (@GenderId,@CivilStatusId,@ReligionId,@PlaceOfBirth,@NationalIdNumber,@SSSNumber,@HDMFNumber,@PHICNUmber,@TIN,@IsDeleted,@BirthDate,@LastName,@FirstName,@MiddleName,@AppliedDate,@HMOCardNumber,@HMOAccountNumber)
                SELECT * FROM tblApplicantData WHERE Id = SCOPE_IDENTITY()
             GO
            