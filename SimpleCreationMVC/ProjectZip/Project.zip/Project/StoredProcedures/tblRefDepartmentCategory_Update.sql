
             ALTER PROCEDURE tblRefDepartmentCategory_Update
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblRefDepartmentCategory
                SET Description=@Description,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblRefDepartmentCategory WHERE Id = @Id
             GO
            