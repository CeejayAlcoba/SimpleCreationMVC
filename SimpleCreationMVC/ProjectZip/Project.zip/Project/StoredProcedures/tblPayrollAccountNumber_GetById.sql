
             ALTER PROCEDURE tblPayrollAccountNumber_GetById
             @Id INT
             AS
                SELECT * FROM tblPayrollAccountNumber
                WHERE Id = @Id
             GO
            