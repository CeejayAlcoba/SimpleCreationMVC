
             ALTER PROCEDURE tblRefDepartmentCategory_DeleteById
                @Id INT
             AS
                DELETE FROM tblRefDepartmentCategory
                WHERE Id =  @Id
             GO
            