
             ALTER PROCEDURE tblEmployeeSalary_Update
             	@Id int ,
		@Amount float  = NULL,
		@EmployeeId int  = NULL,
		@SalaryTypeId int  = NULL,
		@Date datetime  = NULL,
		@IsDeleted bit  = NULL
             AS
                UPDATE tblEmployeeSalary
                SET Amount=@Amount,EmployeeId=@EmployeeId,SalaryTypeId=@SalaryTypeId,Date=@Date,IsDeleted=@IsDeleted
                WHERE Id = @Id
                SELECT * FROM tblEmployeeSalary WHERE Id = @Id
             GO
            