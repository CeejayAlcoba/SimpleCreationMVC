
             ALTER PROCEDURE tblSalaryHistoryLog_GetAll
             AS
                SELECT * FROM tblSalaryHistoryLog
             GO
            