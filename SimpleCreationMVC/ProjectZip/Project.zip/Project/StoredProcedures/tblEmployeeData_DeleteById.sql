
             ALTER PROCEDURE tblEmployeeData_DeleteById
                @Id INT
             AS
                DELETE FROM tblEmployeeData
                WHERE Id =  @Id
             GO
            