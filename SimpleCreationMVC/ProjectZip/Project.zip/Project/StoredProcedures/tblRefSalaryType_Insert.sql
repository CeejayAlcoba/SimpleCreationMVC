
             ALTER PROCEDURE tblRefSalaryType_Insert
             	@Id int ,
		@Description nvarchar(MAX)  = NULL,
		@IsDeleted bit  = NULL
             AS
                INSERT INTO tblRefSalaryType(Description,IsDeleted)
                VALUES (@Description,@IsDeleted)
                SELECT * FROM tblRefSalaryType WHERE Id = SCOPE_IDENTITY()
             GO
            