
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-gender")]
    [ApiController]
    public class tblRefGenderController : ControllerBase
    {
        private readonly tblRefGenderService tblRefGenderService = new tblRefGenderService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefGender()
        {
            try
            {
                var data = await tblRefGenderService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefGender(int id)
        {
            try
            {
                var data = await  tblRefGenderService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefGender([FromBody]tblRefGender tblRefGender)
        {
            try
            {
                var data = await tblRefGenderService.Insert(tblRefGender);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefGender(int id,[FromBody]tblRefGender tblRefGender)
        {
            try
            {
                if(id != tblRefGender.Id) return BadRequest("Id mismatched.");

                var data = await tblRefGenderService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefGenderService.Update(tblRefGender); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefGender(int id)
        {
            try
            {
                var data = await tblRefGenderService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefGenderService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
