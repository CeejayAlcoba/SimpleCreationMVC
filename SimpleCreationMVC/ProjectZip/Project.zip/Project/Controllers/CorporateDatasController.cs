
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/corporate-datas")]
    [ApiController]
    public class CorporateDatasController : ControllerBase
    {
        private readonly CorporateDatasService corporateDatasService = new CorporateDatasService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllCorporateDatas()
        {
            try
            {
                var data = await corporateDatasService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdCorporateDatas(int id)
        {
            try
            {
                var data = await  corporateDatasService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertCorporateDatas([FromBody]CorporateDatas corporateDatas)
        {
            try
            {
                var data = await corporateDatasService.Insert(corporateDatas);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCorporateDatas(int id,[FromBody]CorporateDatas corporateDatas)
        {
            try
            {
                if(id != corporateDatas.Id) return BadRequest("Id mismatched.");

                var data = await corporateDatasService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await corporateDatasService.Update(corporateDatas); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdCorporateDatas(int id)
        {
            try
            {
                var data = await corporateDatasService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await corporateDatasService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
