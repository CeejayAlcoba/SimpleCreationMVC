
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-family-data")]
    [ApiController]
    public class tblFamilyDataController : ControllerBase
    {
        private readonly tblFamilyDataService tblFamilyDataService = new tblFamilyDataService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblFamilyData()
        {
            try
            {
                var data = await tblFamilyDataService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblFamilyData(int id)
        {
            try
            {
                var data = await  tblFamilyDataService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblFamilyData([FromBody]tblFamilyData tblFamilyData)
        {
            try
            {
                var data = await tblFamilyDataService.Insert(tblFamilyData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblFamilyData(int id,[FromBody]tblFamilyData tblFamilyData)
        {
            try
            {
                if(id != tblFamilyData.Id) return BadRequest("Id mismatched.");

                var data = await tblFamilyDataService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblFamilyDataService.Update(tblFamilyData); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblFamilyData(int id)
        {
            try
            {
                var data = await tblFamilyDataService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblFamilyDataService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
