
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/appointments")]
    [ApiController]
    public class AppointmentsController : ControllerBase
    {
        private readonly AppointmentsService appointmentsService = new AppointmentsService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllAppointments()
        {
            try
            {
                var data = await appointmentsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdAppointments(int id)
        {
            try
            {
                var data = await  appointmentsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertAppointments([FromBody]Appointments appointments)
        {
            try
            {
                var data = await appointmentsService.Insert(appointments);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAppointments(int id,[FromBody]Appointments appointments)
        {
            try
            {
                if(id != appointments.Id) return BadRequest("Id mismatched.");

                var data = await appointmentsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await appointmentsService.Update(appointments); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdAppointments(int id)
        {
            try
            {
                var data = await appointmentsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await appointmentsService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
