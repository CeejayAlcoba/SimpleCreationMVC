
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-promotion-history-log")]
    [ApiController]
    public class tblPromotionHistoryLogController : ControllerBase
    {
        private readonly tblPromotionHistoryLogService tblPromotionHistoryLogService = new tblPromotionHistoryLogService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblPromotionHistoryLog()
        {
            try
            {
                var data = await tblPromotionHistoryLogService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblPromotionHistoryLog(int id)
        {
            try
            {
                var data = await  tblPromotionHistoryLogService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblPromotionHistoryLog([FromBody]tblPromotionHistoryLog tblPromotionHistoryLog)
        {
            try
            {
                var data = await tblPromotionHistoryLogService.Insert(tblPromotionHistoryLog);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblPromotionHistoryLog(int id,[FromBody]tblPromotionHistoryLog tblPromotionHistoryLog)
        {
            try
            {
                if(id != tblPromotionHistoryLog.Id) return BadRequest("Id mismatched.");

                var data = await tblPromotionHistoryLogService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblPromotionHistoryLogService.Update(tblPromotionHistoryLog); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblPromotionHistoryLog(int id)
        {
            try
            {
                var data = await tblPromotionHistoryLogService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblPromotionHistoryLogService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
