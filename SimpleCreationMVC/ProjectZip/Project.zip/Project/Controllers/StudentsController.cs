
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.ApiControllers
{
    [Route("api/students")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly StudentsService _studentsService = new StudentsService();

        [HttpGet("list")]
        public async Task<IActionResult> GetAllStudents()
        {
            try
            {
                var data = await _studentsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdStudents(int id)
        {
            try
            {
                var data = await  _studentsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertStudents([FromBody]Students students)
        {
            try
            {
                var data = await _studentsService.Insert(students);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateStudents(int id,[FromBody]Students students)
        {
            try
            {
                if(id != students.Id) return BadRequest("Id mismatched.");

                var data = await _studentsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await _studentsService.Update(students); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdStudents(int id)
        {
            try
            {
                var data = await _studentsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await _studentsService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
