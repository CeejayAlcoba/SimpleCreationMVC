
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-position")]
    [ApiController]
    public class tblRefPositionController : ControllerBase
    {
        private readonly tblRefPositionService tblRefPositionService = new tblRefPositionService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefPosition()
        {
            try
            {
                var data = await tblRefPositionService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefPosition(int id)
        {
            try
            {
                var data = await  tblRefPositionService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefPosition([FromBody]tblRefPosition tblRefPosition)
        {
            try
            {
                var data = await tblRefPositionService.Insert(tblRefPosition);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefPosition(int id,[FromBody]tblRefPosition tblRefPosition)
        {
            try
            {
                if(id != tblRefPosition.Id) return BadRequest("Id mismatched.");

                var data = await tblRefPositionService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefPositionService.Update(tblRefPosition); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefPosition(int id)
        {
            try
            {
                var data = await tblRefPositionService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefPositionService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
