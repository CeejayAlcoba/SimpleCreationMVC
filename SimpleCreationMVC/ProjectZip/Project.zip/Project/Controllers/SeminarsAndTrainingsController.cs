
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/seminars-and-trainings")]
    [ApiController]
    public class SeminarsAndTrainingsController : ControllerBase
    {
        private readonly SeminarsAndTrainingsService seminarsAndTrainingsService = new SeminarsAndTrainingsService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllSeminarsAndTrainings()
        {
            try
            {
                var data = await seminarsAndTrainingsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdSeminarsAndTrainings(int id)
        {
            try
            {
                var data = await  seminarsAndTrainingsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertSeminarsAndTrainings([FromBody]SeminarsAndTrainings seminarsAndTrainings)
        {
            try
            {
                var data = await seminarsAndTrainingsService.Insert(seminarsAndTrainings);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateSeminarsAndTrainings(int id,[FromBody]SeminarsAndTrainings seminarsAndTrainings)
        {
            try
            {
                if(id != seminarsAndTrainings.Id) return BadRequest("Id mismatched.");

                var data = await seminarsAndTrainingsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await seminarsAndTrainingsService.Update(seminarsAndTrainings); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdSeminarsAndTrainings(int id)
        {
            try
            {
                var data = await seminarsAndTrainingsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await seminarsAndTrainingsService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
