
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/internal-work-experiences")]
    [ApiController]
    public class InternalWorkExperiencesController : ControllerBase
    {
        private readonly InternalWorkExperiencesService internalWorkExperiencesService = new InternalWorkExperiencesService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllInternalWorkExperiences()
        {
            try
            {
                var data = await internalWorkExperiencesService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdInternalWorkExperiences(int id)
        {
            try
            {
                var data = await  internalWorkExperiencesService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertInternalWorkExperiences([FromBody]InternalWorkExperiences internalWorkExperiences)
        {
            try
            {
                var data = await internalWorkExperiencesService.Insert(internalWorkExperiences);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateInternalWorkExperiences(int id,[FromBody]InternalWorkExperiences internalWorkExperiences)
        {
            try
            {
                if(id != internalWorkExperiences.Id) return BadRequest("Id mismatched.");

                var data = await internalWorkExperiencesService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await internalWorkExperiencesService.Update(internalWorkExperiences); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdInternalWorkExperiences(int id)
        {
            try
            {
                var data = await internalWorkExperiencesService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await internalWorkExperiencesService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
