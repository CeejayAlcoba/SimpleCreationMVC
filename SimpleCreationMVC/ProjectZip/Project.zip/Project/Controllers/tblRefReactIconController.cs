
using Microsoft.AspNetCore.Mvc;
using Models;
using Services.Interfaces;

namespace ApiControllers
{
    [Route("api/tbl-ref-react-icon")]
    [ApiController]
    public class tblRefReactIconController : ControllerBase
    {
        private readonly ItblRefReactIconService _tblRefReactIconService;

        public tblRefReactIconController(ItblRefReactIconService tblRefReactIconService)
        {
            _tblRefReactIconService = tblRefReactIconService;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetAllAsync([FromQuery]tblRefReactIcon filter)
        {
            try
            {
                IEnumerable<tblRefReactIcon> data = await _tblRefReactIconService.GetAllAsync(filter);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdAsync(int id)
        {
            try
            {
                tblRefReactIcon? data = await _tblRefReactIconService.GetByIdAsync(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertAsync([FromBody]tblRefReactIcon tblRefReactIcon)
        {
            try
            {
                tblRefReactIcon? data = await _tblRefReactIconService.InsertAsync(tblRefReactIcon);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateAsync(int id,[FromBody]tblRefReactIcon tblRefReactIcon)
        {
            try
            {
                if(id != tblRefReactIcon.Id) return BadRequest("Id mismatched.");

                tblRefReactIcon? data = await _tblRefReactIconService.GetByIdAsync(id);
                if (data == null) return NotFound();

                tblRefReactIcon? updatedData = await _tblRefReactIconService.UpdateAsync(tblRefReactIcon); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdAsync(int id)
        {
            try
            {
                tblRefReactIcon? data = await _tblRefReactIconService.GetByIdAsync(id);
                if (data == null) return NotFound();

                var deletedData = await _tblRefReactIconService.DeleteByIdAsync(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk")]
        public async Task<IActionResult> BulkInsertAsync([FromBody]List<tblRefReactIcon> listData)
        {
            try
            {
                IEnumerable<tblRefReactIcon> data = await _tblRefReactIconService.BulkInsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPatch("bulk")]
        public async Task<IActionResult> BulkUpdateAsync([FromBody] List<tblRefReactIcon> listData)
        {
            try
            {
                IEnumerable<tblRefReactIcon> data = await _tblRefReactIconService.BulkUpdateAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-upsert")]
        public async Task<IActionResult> BulkUpsertAsync([FromBody] List<tblRefReactIcon> listData)
        {
            try
            {
                IEnumerable<tblRefReactIcon> data = await _tblRefReactIconService.BulkUpsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-merge")]
        public async Task<IActionResult> BulkMergeAsync([FromBody] List<tblRefReactIcon> listData)
        {
            try
            {
                IEnumerable<tblRefReactIcon> data = await _tblRefReactIconService.BulkMergeAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
    }
}
