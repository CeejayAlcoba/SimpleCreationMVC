
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-department")]
    [ApiController]
    public class tblRefDepartmentController : ControllerBase
    {
        private readonly tblRefDepartmentService tblRefDepartmentService = new tblRefDepartmentService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefDepartment()
        {
            try
            {
                var data = await tblRefDepartmentService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefDepartment(int id)
        {
            try
            {
                var data = await  tblRefDepartmentService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefDepartment([FromBody]tblRefDepartment tblRefDepartment)
        {
            try
            {
                var data = await tblRefDepartmentService.Insert(tblRefDepartment);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefDepartment(int id,[FromBody]tblRefDepartment tblRefDepartment)
        {
            try
            {
                if(id != tblRefDepartment.Id) return BadRequest("Id mismatched.");

                var data = await tblRefDepartmentService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefDepartmentService.Update(tblRefDepartment); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefDepartment(int id)
        {
            try
            {
                var data = await tblRefDepartmentService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefDepartmentService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
