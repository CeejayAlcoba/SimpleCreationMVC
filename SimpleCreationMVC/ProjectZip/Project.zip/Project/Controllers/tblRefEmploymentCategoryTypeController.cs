
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-employment-category-type")]
    [ApiController]
    public class tblRefEmploymentCategoryTypeController : ControllerBase
    {
        private readonly tblRefEmploymentCategoryTypeService tblRefEmploymentCategoryTypeService = new tblRefEmploymentCategoryTypeService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefEmploymentCategoryType()
        {
            try
            {
                var data = await tblRefEmploymentCategoryTypeService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefEmploymentCategoryType(int id)
        {
            try
            {
                var data = await  tblRefEmploymentCategoryTypeService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefEmploymentCategoryType([FromBody]tblRefEmploymentCategoryType tblRefEmploymentCategoryType)
        {
            try
            {
                var data = await tblRefEmploymentCategoryTypeService.Insert(tblRefEmploymentCategoryType);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefEmploymentCategoryType(int id,[FromBody]tblRefEmploymentCategoryType tblRefEmploymentCategoryType)
        {
            try
            {
                if(id != tblRefEmploymentCategoryType.Id) return BadRequest("Id mismatched.");

                var data = await tblRefEmploymentCategoryTypeService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefEmploymentCategoryTypeService.Update(tblRefEmploymentCategoryType); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefEmploymentCategoryType(int id)
        {
            try
            {
                var data = await tblRefEmploymentCategoryTypeService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefEmploymentCategoryTypeService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
