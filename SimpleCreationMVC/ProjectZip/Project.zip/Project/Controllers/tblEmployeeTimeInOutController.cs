
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.ApiControllers
{
    [Route("api/tbl-employee-time-in-out")]
    [ApiController]
    public class tblEmployeeTimeInOutController : ControllerBase
    {
        private readonly tblEmployeeTimeInOutService _tblEmployeeTimeInOutService = new tblEmployeeTimeInOutService();

        [HttpGet("list")]
        public async Task<IActionResult> GetAlltblEmployeeTimeInOut()
        {
            try
            {
                var data = await _tblEmployeeTimeInOutService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblEmployeeTimeInOut(int id)
        {
            try
            {
                var data = await  _tblEmployeeTimeInOutService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblEmployeeTimeInOut([FromBody]tblEmployeeTimeInOut tblEmployeeTimeInOut)
        {
            try
            {
                var data = await _tblEmployeeTimeInOutService.Insert(tblEmployeeTimeInOut);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblEmployeeTimeInOut(int id,[FromBody]tblEmployeeTimeInOut tblEmployeeTimeInOut)
        {
            try
            {
                if(id != tblEmployeeTimeInOut.Id) return BadRequest("Id mismatched.");

                var data = await _tblEmployeeTimeInOutService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await _tblEmployeeTimeInOutService.Update(tblEmployeeTimeInOut); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblEmployeeTimeInOut(int id)
        {
            try
            {
                var data = await _tblEmployeeTimeInOutService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await _tblEmployeeTimeInOutService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
