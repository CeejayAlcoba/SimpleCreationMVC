
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-children")]
    [ApiController]
    public class tblRefChildrenController : ControllerBase
    {
        private readonly tblRefChildrenService tblRefChildrenService = new tblRefChildrenService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefChildren()
        {
            try
            {
                var data = await tblRefChildrenService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefChildren(int id)
        {
            try
            {
                var data = await  tblRefChildrenService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefChildren([FromBody]tblRefChildren tblRefChildren)
        {
            try
            {
                var data = await tblRefChildrenService.Insert(tblRefChildren);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefChildren(int id,[FromBody]tblRefChildren tblRefChildren)
        {
            try
            {
                if(id != tblRefChildren.Id) return BadRequest("Id mismatched.");

                var data = await tblRefChildrenService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefChildrenService.Update(tblRefChildren); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefChildren(int id)
        {
            try
            {
                var data = await tblRefChildrenService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefChildrenService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
