
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-employee-data")]
    [ApiController]
    public class tblEmployeeDataController : ControllerBase
    {
        private readonly tblEmployeeDataService tblEmployeeDataService = new tblEmployeeDataService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblEmployeeData()
        {
            try
            {
                var data = await tblEmployeeDataService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblEmployeeData(int id)
        {
            try
            {
                var data = await  tblEmployeeDataService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblEmployeeData([FromBody]tblEmployeeData tblEmployeeData)
        {
            try
            {
                var data = await tblEmployeeDataService.Insert(tblEmployeeData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblEmployeeData(int id,[FromBody]tblEmployeeData tblEmployeeData)
        {
            try
            {
                if(id != tblEmployeeData.Id) return BadRequest("Id mismatched.");

                var data = await tblEmployeeDataService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblEmployeeDataService.Update(tblEmployeeData); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblEmployeeData(int id)
        {
            try
            {
                var data = await tblEmployeeDataService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblEmployeeDataService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
