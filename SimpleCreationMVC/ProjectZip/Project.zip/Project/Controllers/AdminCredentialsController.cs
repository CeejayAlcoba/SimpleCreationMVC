
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.ApiControllers
{
    [Route("api/admin-credentials")]
    [ApiController]
    public class AdminCredentialsController : ControllerBase
    {
        private readonly AdminCredentialsService _adminCredentialsService = new AdminCredentialsService();

        [HttpGet("list")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var data = await _adminCredentialsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var data = await _adminCredentialsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Insert([FromBody]AdminCredentials adminCredentials)
        {
            try
            {
                var data = await _adminCredentialsService.Insert(adminCredentials);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id,[FromBody]AdminCredentials adminCredentials)
        {
            try
            {
                if(id != adminCredentials.Id) return BadRequest("Id mismatched.");

                var data = await _adminCredentialsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await _adminCredentialsService.Update(adminCredentials); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteById(int id)
        {
            try
            {
                var data = await _adminCredentialsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await _adminCredentialsService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("many")]
        public async Task<IActionResult> InsertMany([FromBody]List<AdminCredentials> listData)
        {
            try
            {
                var data = await _adminCredentialsService.InsertMany(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("many")]
        public async Task<IActionResult> UpdateMany([FromBody] List<AdminCredentials> listData)
        {
            try
            {
                var data = await _adminCredentialsService.UpdateMany(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
