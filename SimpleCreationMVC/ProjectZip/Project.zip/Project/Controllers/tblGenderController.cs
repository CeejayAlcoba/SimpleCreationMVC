
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.ApiControllers
{
    [Route("api/tbl-gender")]
    [ApiController]
    public class tblGenderController : ControllerBase
    {
        private readonly tblGenderService _tblGenderService = new tblGenderService();

        [HttpGet("list")]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                IEnumerable<tblGender> data = await _tblGenderService.GetAllAsync();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdAsync(int id)
        {
            try
            {
                tblGender? data = await _tblGenderService.GetByIdAsync(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertAsync([FromBody]tblGender tblGender)
        {
            try
            {
                tblGender? data = await _tblGenderService.InsertAsync(tblGender);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAsync(int id,[FromBody]tblGender tblGender)
        {
            try
            {
                if(id != tblGender.Id) return BadRequest("Id mismatched.");

                tblGender? data = await _tblGenderService.GetByIdAsync(id);
                if (data == null) return NotFound();

                tblGender? updatedData = await _tblGenderService.UpdateAsync(tblGender); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdAsync(int id)
        {
            try
            {
                tblGender? data = await _tblGenderService.GetByIdAsync(id);
                if (data == null) return NotFound();

                var deletedData = await _tblGenderService.DeleteByIdAsync(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk")]
        public async Task<IActionResult> BulkInsertAsync([FromBody]List<tblGender> listData)
        {
            try
            {
                IEnumerable<tblGender> data = await _tblGenderService.BulkInsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("bulk")]
        public async Task<IActionResult> BulkUpdateAsync([FromBody] List<tblGender> listData)
        {
            try
            {
                IEnumerable<tblGender> data = await _tblGenderService.BulkUpdateAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("bulk-upsert")]
        public async Task<IActionResult> BulkUpsertAsync([FromBody] List<tblGender> listData)
        {
            try
            {
                IEnumerable<tblGender> data = await _tblGenderService.BulkUpsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
