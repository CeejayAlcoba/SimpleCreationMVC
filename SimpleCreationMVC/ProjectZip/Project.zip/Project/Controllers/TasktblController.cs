
using Microsoft.AspNetCore.Mvc;
using Models;
using Services.Interfaces;

namespace ApiControllers
{
    [Route("api/tasktbl")]
    [ApiController]
    public class TasktblController : ControllerBase
    {
        private readonly ITasktblService _tasktblService;

        public TasktblController(ITasktblService tasktblService)
        {
            _tasktblService = tasktblService;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                IEnumerable<Tasktbl> data = await _tasktblService.GetAllAsync();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdAsync(int id)
        {
            try
            {
                Tasktbl? data = await _tasktblService.GetByIdAsync(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertAsync([FromBody]Tasktbl tasktbl)
        {
            try
            {
                Tasktbl? data = await _tasktblService.InsertAsync(tasktbl);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateAsync(int id,[FromBody]Tasktbl tasktbl)
        {
            try
            {
                if(id != tasktbl.Id) return BadRequest("Id mismatched.");

                Tasktbl? data = await _tasktblService.GetByIdAsync(id);
                if (data == null) return NotFound();

                Tasktbl? updatedData = await _tasktblService.UpdateAsync(tasktbl); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdAsync(int id)
        {
            try
            {
                Tasktbl? data = await _tasktblService.GetByIdAsync(id);
                if (data == null) return NotFound();

                var deletedData = await _tasktblService.DeleteByIdAsync(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk")]
        public async Task<IActionResult> BulkInsertAsync([FromBody]List<Tasktbl> listData)
        {
            try
            {
                IEnumerable<Tasktbl> data = await _tasktblService.BulkInsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPatch("bulk")]
        public async Task<IActionResult> BulkUpdateAsync([FromBody] List<Tasktbl> listData)
        {
            try
            {
                IEnumerable<Tasktbl> data = await _tasktblService.BulkUpdateAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-upsert")]
        public async Task<IActionResult> BulkUpsertAsync([FromBody] List<Tasktbl> listData)
        {
            try
            {
                IEnumerable<Tasktbl> data = await _tasktblService.BulkUpsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-merge")]
        public async Task<IActionResult> BulkMergeAsync([FromBody] List<Tasktbl> listData)
        {
            try
            {
                IEnumerable<Tasktbl> data = await _tasktblService.BulkMergeAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
    }
}
