
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-external-work-experience")]
    [ApiController]
    public class tblExternalWorkExperienceController : ControllerBase
    {
        private readonly tblExternalWorkExperienceService tblExternalWorkExperienceService = new tblExternalWorkExperienceService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblExternalWorkExperience()
        {
            try
            {
                var data = await tblExternalWorkExperienceService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblExternalWorkExperience(int id)
        {
            try
            {
                var data = await  tblExternalWorkExperienceService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblExternalWorkExperience([FromBody]tblExternalWorkExperience tblExternalWorkExperience)
        {
            try
            {
                var data = await tblExternalWorkExperienceService.Insert(tblExternalWorkExperience);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblExternalWorkExperience(int id,[FromBody]tblExternalWorkExperience tblExternalWorkExperience)
        {
            try
            {
                if(id != tblExternalWorkExperience.Id) return BadRequest("Id mismatched.");

                var data = await tblExternalWorkExperienceService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblExternalWorkExperienceService.Update(tblExternalWorkExperience); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblExternalWorkExperience(int id)
        {
            try
            {
                var data = await tblExternalWorkExperienceService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblExternalWorkExperienceService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
