
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-zipcode")]
    [ApiController]
    public class tblRefZIPCodeController : ControllerBase
    {
        private readonly tblRefZIPCodeService tblRefZIPCodeService = new tblRefZIPCodeService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefZIPCode()
        {
            try
            {
                var data = await tblRefZIPCodeService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefZIPCode(int id)
        {
            try
            {
                var data = await  tblRefZIPCodeService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefZIPCode([FromBody]tblRefZIPCode tblRefZIPCode)
        {
            try
            {
                var data = await tblRefZIPCodeService.Insert(tblRefZIPCode);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefZIPCode(int id,[FromBody]tblRefZIPCode tblRefZIPCode)
        {
            try
            {
                if(id != tblRefZIPCode.Id) return BadRequest("Id mismatched.");

                var data = await tblRefZIPCodeService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefZIPCodeService.Update(tblRefZIPCode); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefZIPCode(int id)
        {
            try
            {
                var data = await tblRefZIPCodeService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefZIPCodeService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
