
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-grade-level")]
    [ApiController]
    public class tblRefGradeLevelController : ControllerBase
    {
        private readonly tblRefGradeLevelService tblRefGradeLevelService = new tblRefGradeLevelService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefGradeLevel()
        {
            try
            {
                var data = await tblRefGradeLevelService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefGradeLevel(int id)
        {
            try
            {
                var data = await  tblRefGradeLevelService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefGradeLevel([FromBody]tblRefGradeLevel tblRefGradeLevel)
        {
            try
            {
                var data = await tblRefGradeLevelService.Insert(tblRefGradeLevel);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefGradeLevel(int id,[FromBody]tblRefGradeLevel tblRefGradeLevel)
        {
            try
            {
                if(id != tblRefGradeLevel.Id) return BadRequest("Id mismatched.");

                var data = await tblRefGradeLevelService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefGradeLevelService.Update(tblRefGradeLevel); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefGradeLevel(int id)
        {
            try
            {
                var data = await tblRefGradeLevelService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefGradeLevelService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
