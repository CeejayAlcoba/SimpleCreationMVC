
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/published-books")]
    [ApiController]
    public class PublishedBooksController : ControllerBase
    {
        private readonly PublishedBooksService publishedBooksService = new PublishedBooksService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllPublishedBooks()
        {
            try
            {
                var data = await publishedBooksService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdPublishedBooks(int id)
        {
            try
            {
                var data = await  publishedBooksService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertPublishedBooks([FromBody]PublishedBooks publishedBooks)
        {
            try
            {
                var data = await publishedBooksService.Insert(publishedBooks);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePublishedBooks(int id,[FromBody]PublishedBooks publishedBooks)
        {
            try
            {
                if(id != publishedBooks.Id) return BadRequest("Id mismatched.");

                var data = await publishedBooksService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await publishedBooksService.Update(publishedBooks); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdPublishedBooks(int id)
        {
            try
            {
                var data = await publishedBooksService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await publishedBooksService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
