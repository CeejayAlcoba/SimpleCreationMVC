
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.ApiControllers
{
    [Route("api/classes")]
    [ApiController]
    public class ClassesController : ControllerBase
    {
        private readonly ClassesService _classesService = new ClassesService();

        [HttpGet("list")]
        public async Task<IActionResult> GetAllClasses()
        {
            try
            {
                var data = await _classesService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdClasses(int id)
        {
            try
            {
                var data = await  _classesService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertClasses([FromBody]Classes classes)
        {
            try
            {
                var data = await _classesService.Insert(classes);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateClasses(int id,[FromBody]Classes classes)
        {
            try
            {
                if(id != classes.Id) return BadRequest("Id mismatched.");

                var data = await _classesService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await _classesService.Update(classes); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdClasses(int id)
        {
            try
            {
                var data = await _classesService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await _classesService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
