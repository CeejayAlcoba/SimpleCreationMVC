
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-permanent-address")]
    [ApiController]
    public class tblRefPermanentAddressController : ControllerBase
    {
        private readonly tblRefPermanentAddressService tblRefPermanentAddressService = new tblRefPermanentAddressService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefPermanentAddress()
        {
            try
            {
                var data = await tblRefPermanentAddressService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefPermanentAddress(int id)
        {
            try
            {
                var data = await  tblRefPermanentAddressService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefPermanentAddress([FromBody]tblRefPermanentAddress tblRefPermanentAddress)
        {
            try
            {
                var data = await tblRefPermanentAddressService.Insert(tblRefPermanentAddress);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefPermanentAddress(int id,[FromBody]tblRefPermanentAddress tblRefPermanentAddress)
        {
            try
            {
                if(id != tblRefPermanentAddress.Id) return BadRequest("Id mismatched.");

                var data = await tblRefPermanentAddressService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefPermanentAddressService.Update(tblRefPermanentAddress); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefPermanentAddress(int id)
        {
            try
            {
                var data = await tblRefPermanentAddressService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefPermanentAddressService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
