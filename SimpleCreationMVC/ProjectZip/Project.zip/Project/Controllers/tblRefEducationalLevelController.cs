
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-educational-level")]
    [ApiController]
    public class tblRefEducationalLevelController : ControllerBase
    {
        private readonly tblRefEducationalLevelService tblRefEducationalLevelService = new tblRefEducationalLevelService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefEducationalLevel()
        {
            try
            {
                var data = await tblRefEducationalLevelService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefEducationalLevel(int id)
        {
            try
            {
                var data = await  tblRefEducationalLevelService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefEducationalLevel([FromBody]tblRefEducationalLevel tblRefEducationalLevel)
        {
            try
            {
                var data = await tblRefEducationalLevelService.Insert(tblRefEducationalLevel);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefEducationalLevel(int id,[FromBody]tblRefEducationalLevel tblRefEducationalLevel)
        {
            try
            {
                if(id != tblRefEducationalLevel.Id) return BadRequest("Id mismatched.");

                var data = await tblRefEducationalLevelService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefEducationalLevelService.Update(tblRefEducationalLevel); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefEducationalLevel(int id)
        {
            try
            {
                var data = await tblRefEducationalLevelService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefEducationalLevelService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
