
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/paper-research-presentations")]
    [ApiController]
    public class PaperResearchPresentationsController : ControllerBase
    {
        private readonly PaperResearchPresentationsService paperResearchPresentationsService = new PaperResearchPresentationsService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllPaperResearchPresentations()
        {
            try
            {
                var data = await paperResearchPresentationsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdPaperResearchPresentations(int id)
        {
            try
            {
                var data = await  paperResearchPresentationsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertPaperResearchPresentations([FromBody]PaperResearchPresentations paperResearchPresentations)
        {
            try
            {
                var data = await paperResearchPresentationsService.Insert(paperResearchPresentations);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePaperResearchPresentations(int id,[FromBody]PaperResearchPresentations paperResearchPresentations)
        {
            try
            {
                if(id != paperResearchPresentations.Id) return BadRequest("Id mismatched.");

                var data = await paperResearchPresentationsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await paperResearchPresentationsService.Update(paperResearchPresentations); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdPaperResearchPresentations(int id)
        {
            try
            {
                var data = await paperResearchPresentationsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await paperResearchPresentationsService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
