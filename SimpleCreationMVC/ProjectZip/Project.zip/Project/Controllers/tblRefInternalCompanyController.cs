
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-internal-company")]
    [ApiController]
    public class tblRefInternalCompanyController : ControllerBase
    {
        private readonly tblRefInternalCompanyService tblRefInternalCompanyService = new tblRefInternalCompanyService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefInternalCompany()
        {
            try
            {
                var data = await tblRefInternalCompanyService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefInternalCompany(int id)
        {
            try
            {
                var data = await  tblRefInternalCompanyService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefInternalCompany([FromBody]tblRefInternalCompany tblRefInternalCompany)
        {
            try
            {
                var data = await tblRefInternalCompanyService.Insert(tblRefInternalCompany);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefInternalCompany(int id,[FromBody]tblRefInternalCompany tblRefInternalCompany)
        {
            try
            {
                if(id != tblRefInternalCompany.Id) return BadRequest("Id mismatched.");

                var data = await tblRefInternalCompanyService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefInternalCompanyService.Update(tblRefInternalCompany); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefInternalCompany(int id)
        {
            try
            {
                var data = await tblRefInternalCompanyService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefInternalCompanyService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
