
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/community-involvements")]
    [ApiController]
    public class CommunityInvolvementsController : ControllerBase
    {
        private readonly CommunityInvolvementsService communityInvolvementsService = new CommunityInvolvementsService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllCommunityInvolvements()
        {
            try
            {
                var data = await communityInvolvementsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdCommunityInvolvements(int id)
        {
            try
            {
                var data = await  communityInvolvementsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertCommunityInvolvements([FromBody]CommunityInvolvements communityInvolvements)
        {
            try
            {
                var data = await communityInvolvementsService.Insert(communityInvolvements);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCommunityInvolvements(int id,[FromBody]CommunityInvolvements communityInvolvements)
        {
            try
            {
                if(id != communityInvolvements.Id) return BadRequest("Id mismatched.");

                var data = await communityInvolvementsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await communityInvolvementsService.Update(communityInvolvements); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdCommunityInvolvements(int id)
        {
            try
            {
                var data = await communityInvolvementsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await communityInvolvementsService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
