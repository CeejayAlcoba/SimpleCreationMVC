using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;
using Models;
using Models.Pagination; 
using Services.Interfaces;
using Utilities.Interfaces;

namespace ApiControllers
{
    [Route("api/initial-db")]
    [ApiController]
    public class InitialDBController : ControllerBase
    {
        private readonly IInitialDBService _initialDBService;
        private readonly IExpressionHelperUtility _expressionHelperUtility;

        public InitialDBController(IInitialDBService initialDBService, IExpressionHelperUtility expressionHelperUtility)
        {
            _initialDBService = initialDBService;
            _expressionHelperUtility = expressionHelperUtility;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetAllAsync(
            [FromQuery] int pageNumber = 1, 
            [FromQuery] int pageSize = 10, 
            [FromQuery] InitialDB? filter = null,
            [FromQuery] string? orderBy = null,
            [FromQuery] bool isDescending = false)
        {
            try
            {
                var orderByExpression = _expressionHelperUtility.GetOrderByExpression<InitialDB>(orderBy);
                PagedResult<InitialDB> data = await _initialDBService.GetAllAsync(pageNumber, pageSize, null, orderByExpression, isDescending);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdAsync(int id)
        {
            try
            {
                InitialDB? data = await _initialDBService.GetByIdAsync(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertAsync([FromBody]InitialDB initialDB)
        {
            try
            {
                InitialDB? data = await _initialDBService.InsertAsync(initialDB);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateAsync(int id,[FromBody]InitialDB initialDB)
        {
            try
            {
                if(id != initialDB.Id) return BadRequest("Id mismatched.");

                InitialDB? data = await _initialDBService.GetByIdAsync(id);
                if (data == null) return NotFound();

                InitialDB? updatedData = await _initialDBService.UpdateAsync(initialDB); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdAsync(int id)
        {
            try
            {
                InitialDB? data = await _initialDBService.GetByIdAsync(id);
                if (data == null) return NotFound();

                var deletedData = await _initialDBService.DeleteByIdAsync(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk")]
        public async Task<IActionResult> BulkInsertAsync([FromBody]List<InitialDB> listData)
        {
            try
            {
                IEnumerable<InitialDB> data = await _initialDBService.BulkInsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPatch("bulk")]
        public async Task<IActionResult> BulkUpdateAsync([FromBody] List<InitialDB> listData)
        {
            try
            {
                IEnumerable<InitialDB> data = await _initialDBService.BulkUpdateAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-upsert")]
        public async Task<IActionResult> BulkUpsertAsync([FromBody] List<InitialDB> listData)
        {
            try
            {
                IEnumerable<InitialDB> data = await _initialDBService.BulkUpsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-merge")]
        public async Task<IActionResult> BulkMergeAsync([FromBody] List<InitialDB> listData)
        {
            try
            {
                IEnumerable<InitialDB> data = await _initialDBService.BulkMergeAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
    }
}