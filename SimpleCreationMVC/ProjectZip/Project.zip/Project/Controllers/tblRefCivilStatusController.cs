
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-civil-status")]
    [ApiController]
    public class tblRefCivilStatusController : ControllerBase
    {
        private readonly tblRefCivilStatusService tblRefCivilStatusService = new tblRefCivilStatusService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefCivilStatus()
        {
            try
            {
                var data = await tblRefCivilStatusService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefCivilStatus(int id)
        {
            try
            {
                var data = await  tblRefCivilStatusService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefCivilStatus([FromBody]tblRefCivilStatus tblRefCivilStatus)
        {
            try
            {
                var data = await tblRefCivilStatusService.Insert(tblRefCivilStatus);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefCivilStatus(int id,[FromBody]tblRefCivilStatus tblRefCivilStatus)
        {
            try
            {
                if(id != tblRefCivilStatus.Id) return BadRequest("Id mismatched.");

                var data = await tblRefCivilStatusService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefCivilStatusService.Update(tblRefCivilStatus); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefCivilStatus(int id)
        {
            try
            {
                var data = await tblRefCivilStatusService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefCivilStatusService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
