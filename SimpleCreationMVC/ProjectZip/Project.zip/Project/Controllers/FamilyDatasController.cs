
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/family-datas")]
    [ApiController]
    public class FamilyDatasController : ControllerBase
    {
        private readonly FamilyDatasService familyDatasService = new FamilyDatasService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllFamilyDatas()
        {
            try
            {
                var data = await familyDatasService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdFamilyDatas(int id)
        {
            try
            {
                var data = await  familyDatasService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertFamilyDatas([FromBody]FamilyDatas familyDatas)
        {
            try
            {
                var data = await familyDatasService.Insert(familyDatas);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateFamilyDatas(int id,[FromBody]FamilyDatas familyDatas)
        {
            try
            {
                if(id != familyDatas.Id) return BadRequest("Id mismatched.");

                var data = await familyDatasService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await familyDatasService.Update(familyDatas); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdFamilyDatas(int id)
        {
            try
            {
                var data = await familyDatasService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await familyDatasService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
