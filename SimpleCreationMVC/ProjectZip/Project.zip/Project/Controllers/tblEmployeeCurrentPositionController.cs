
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-employee-current-position")]
    [ApiController]
    public class tblEmployeeCurrentPositionController : ControllerBase
    {
        private readonly tblEmployeeCurrentPositionService tblEmployeeCurrentPositionService = new tblEmployeeCurrentPositionService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblEmployeeCurrentPosition()
        {
            try
            {
                var data = await tblEmployeeCurrentPositionService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblEmployeeCurrentPosition(int id)
        {
            try
            {
                var data = await  tblEmployeeCurrentPositionService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblEmployeeCurrentPosition([FromBody]tblEmployeeCurrentPosition tblEmployeeCurrentPosition)
        {
            try
            {
                var data = await tblEmployeeCurrentPositionService.Insert(tblEmployeeCurrentPosition);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblEmployeeCurrentPosition(int id,[FromBody]tblEmployeeCurrentPosition tblEmployeeCurrentPosition)
        {
            try
            {
                if(id != tblEmployeeCurrentPosition.Id) return BadRequest("Id mismatched.");

                var data = await tblEmployeeCurrentPositionService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblEmployeeCurrentPositionService.Update(tblEmployeeCurrentPosition); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblEmployeeCurrentPosition(int id)
        {
            try
            {
                var data = await tblEmployeeCurrentPositionService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblEmployeeCurrentPositionService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
