
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/external-work-experiences")]
    [ApiController]
    public class ExternalWorkExperiencesController : ControllerBase
    {
        private readonly ExternalWorkExperiencesService externalWorkExperiencesService = new ExternalWorkExperiencesService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllExternalWorkExperiences()
        {
            try
            {
                var data = await externalWorkExperiencesService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdExternalWorkExperiences(int id)
        {
            try
            {
                var data = await  externalWorkExperiencesService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertExternalWorkExperiences([FromBody]ExternalWorkExperiences externalWorkExperiences)
        {
            try
            {
                var data = await externalWorkExperiencesService.Insert(externalWorkExperiences);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateExternalWorkExperiences(int id,[FromBody]ExternalWorkExperiences externalWorkExperiences)
        {
            try
            {
                if(id != externalWorkExperiences.Id) return BadRequest("Id mismatched.");

                var data = await externalWorkExperiencesService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await externalWorkExperiencesService.Update(externalWorkExperiences); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdExternalWorkExperiences(int id)
        {
            try
            {
                var data = await externalWorkExperiencesService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await externalWorkExperiencesService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
