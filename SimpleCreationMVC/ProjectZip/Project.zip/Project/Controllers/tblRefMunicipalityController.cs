
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-municipality")]
    [ApiController]
    public class tblRefMunicipalityController : ControllerBase
    {
        private readonly tblRefMunicipalityService tblRefMunicipalityService = new tblRefMunicipalityService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefMunicipality()
        {
            try
            {
                var data = await tblRefMunicipalityService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefMunicipality(int id)
        {
            try
            {
                var data = await  tblRefMunicipalityService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefMunicipality([FromBody]tblRefMunicipality tblRefMunicipality)
        {
            try
            {
                var data = await tblRefMunicipalityService.Insert(tblRefMunicipality);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefMunicipality(int id,[FromBody]tblRefMunicipality tblRefMunicipality)
        {
            try
            {
                if(id != tblRefMunicipality.Id) return BadRequest("Id mismatched.");

                var data = await tblRefMunicipalityService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefMunicipalityService.Update(tblRefMunicipality); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefMunicipality(int id)
        {
            try
            {
                var data = await tblRefMunicipalityService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefMunicipalityService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
