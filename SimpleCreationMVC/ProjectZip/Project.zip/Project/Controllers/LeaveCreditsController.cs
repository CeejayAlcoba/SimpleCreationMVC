
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/leave-credits")]
    [ApiController]
    public class LeaveCreditsController : ControllerBase
    {
        private readonly LeaveCreditsService leaveCreditsService = new LeaveCreditsService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllLeaveCredits()
        {
            try
            {
                var data = await leaveCreditsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdLeaveCredits(int id)
        {
            try
            {
                var data = await  leaveCreditsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertLeaveCredits([FromBody]LeaveCredits leaveCredits)
        {
            try
            {
                var data = await leaveCreditsService.Insert(leaveCredits);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateLeaveCredits(int id,[FromBody]LeaveCredits leaveCredits)
        {
            try
            {
                if(id != leaveCredits.Id) return BadRequest("Id mismatched.");

                var data = await leaveCreditsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await leaveCreditsService.Update(leaveCredits); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdLeaveCredits(int id)
        {
            try
            {
                var data = await leaveCreditsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await leaveCreditsService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
