
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-salary-history-log")]
    [ApiController]
    public class tblSalaryHistoryLogController : ControllerBase
    {
        private readonly tblSalaryHistoryLogService tblSalaryHistoryLogService = new tblSalaryHistoryLogService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblSalaryHistoryLog()
        {
            try
            {
                var data = await tblSalaryHistoryLogService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblSalaryHistoryLog(int id)
        {
            try
            {
                var data = await  tblSalaryHistoryLogService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblSalaryHistoryLog([FromBody]tblSalaryHistoryLog tblSalaryHistoryLog)
        {
            try
            {
                var data = await tblSalaryHistoryLogService.Insert(tblSalaryHistoryLog);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblSalaryHistoryLog(int id,[FromBody]tblSalaryHistoryLog tblSalaryHistoryLog)
        {
            try
            {
                if(id != tblSalaryHistoryLog.Id) return BadRequest("Id mismatched.");

                var data = await tblSalaryHistoryLogService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblSalaryHistoryLogService.Update(tblSalaryHistoryLog); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblSalaryHistoryLog(int id)
        {
            try
            {
                var data = await tblSalaryHistoryLogService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblSalaryHistoryLogService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
