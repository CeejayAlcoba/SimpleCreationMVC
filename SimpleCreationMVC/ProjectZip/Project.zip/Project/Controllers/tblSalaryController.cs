
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-salary")]
    [ApiController]
    public class tblSalaryController : ControllerBase
    {
        private readonly tblSalaryService tblSalaryService = new tblSalaryService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblSalary()
        {
            try
            {
                var data = await tblSalaryService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblSalary(int id)
        {
            try
            {
                var data = await  tblSalaryService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblSalary([FromBody]tblSalary tblSalary)
        {
            try
            {
                var data = await tblSalaryService.Insert(tblSalary);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblSalary(int id,[FromBody]tblSalary tblSalary)
        {
            try
            {
                if(id != tblSalary.Id) return BadRequest("Id mismatched.");

                var data = await tblSalaryService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblSalaryService.Update(tblSalary); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblSalary(int id)
        {
            try
            {
                var data = await tblSalaryService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblSalaryService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
