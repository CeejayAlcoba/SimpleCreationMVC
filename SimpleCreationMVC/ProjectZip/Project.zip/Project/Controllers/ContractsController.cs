
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/contracts")]
    [ApiController]
    public class ContractsController : ControllerBase
    {
        private readonly ContractsService contractsService = new ContractsService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllContracts()
        {
            try
            {
                var data = await contractsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdContracts(int id)
        {
            try
            {
                var data = await  contractsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertContracts([FromBody]Contracts contracts)
        {
            try
            {
                var data = await contractsService.Insert(contracts);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateContracts(int id,[FromBody]Contracts contracts)
        {
            try
            {
                if(id != contracts.Id) return BadRequest("Id mismatched.");

                var data = await contractsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await contractsService.Update(contracts); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdContracts(int id)
        {
            try
            {
                var data = await contractsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await contractsService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
