
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/professional-affiliations")]
    [ApiController]
    public class ProfessionalAffiliationsController : ControllerBase
    {
        private readonly ProfessionalAffiliationsService professionalAffiliationsService = new ProfessionalAffiliationsService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllProfessionalAffiliations()
        {
            try
            {
                var data = await professionalAffiliationsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdProfessionalAffiliations(int id)
        {
            try
            {
                var data = await  professionalAffiliationsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertProfessionalAffiliations([FromBody]ProfessionalAffiliations professionalAffiliations)
        {
            try
            {
                var data = await professionalAffiliationsService.Insert(professionalAffiliations);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProfessionalAffiliations(int id,[FromBody]ProfessionalAffiliations professionalAffiliations)
        {
            try
            {
                if(id != professionalAffiliations.Id) return BadRequest("Id mismatched.");

                var data = await professionalAffiliationsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await professionalAffiliationsService.Update(professionalAffiliations); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdProfessionalAffiliations(int id)
        {
            try
            {
                var data = await professionalAffiliationsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await professionalAffiliationsService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
