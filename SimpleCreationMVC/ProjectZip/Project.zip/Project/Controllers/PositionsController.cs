
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/positions")]
    [ApiController]
    public class PositionsController : ControllerBase
    {
        private readonly PositionsService positionsService = new PositionsService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllPositions()
        {
            try
            {
                var data = await positionsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdPositions(int id)
        {
            try
            {
                var data = await  positionsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertPositions([FromBody]Positions positions)
        {
            try
            {
                var data = await positionsService.Insert(positions);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePositions(int id,[FromBody]Positions positions)
        {
            try
            {
                if(id != positions.Id) return BadRequest("Id mismatched.");

                var data = await positionsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await positionsService.Update(positions); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdPositions(int id)
        {
            try
            {
                var data = await positionsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await positionsService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
