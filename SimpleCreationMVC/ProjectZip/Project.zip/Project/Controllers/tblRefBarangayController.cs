
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-barangay")]
    [ApiController]
    public class tblRefBarangayController : ControllerBase
    {
        private readonly tblRefBarangayService tblRefBarangayService = new tblRefBarangayService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefBarangay()
        {
            try
            {
                var data = await tblRefBarangayService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefBarangay(int id)
        {
            try
            {
                var data = await  tblRefBarangayService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefBarangay([FromBody]tblRefBarangay tblRefBarangay)
        {
            try
            {
                var data = await tblRefBarangayService.Insert(tblRefBarangay);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefBarangay(int id,[FromBody]tblRefBarangay tblRefBarangay)
        {
            try
            {
                if(id != tblRefBarangay.Id) return BadRequest("Id mismatched.");

                var data = await tblRefBarangayService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefBarangayService.Update(tblRefBarangay); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefBarangay(int id)
        {
            try
            {
                var data = await tblRefBarangayService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefBarangayService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
