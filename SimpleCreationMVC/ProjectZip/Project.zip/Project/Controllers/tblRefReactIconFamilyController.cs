
using Microsoft.AspNetCore.Mvc;
using Models;
using Services.Interfaces;

namespace ApiControllers
{
    [Route("api/tbl-ref-react-icon-family")]
    [ApiController]
    public class tblRefReactIconFamilyController : ControllerBase
    {
        private readonly ItblRefReactIconFamilyService _tblRefReactIconFamilyService;

        public tblRefReactIconFamilyController(ItblRefReactIconFamilyService tblRefReactIconFamilyService)
        {
            _tblRefReactIconFamilyService = tblRefReactIconFamilyService;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetAllAsync([FromQuery]tblRefReactIconFamily filter)
        {
            try
            {
                IEnumerable<tblRefReactIconFamily> data = await _tblRefReactIconFamilyService.GetAllAsync(filter);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdAsync(int id)
        {
            try
            {
                tblRefReactIconFamily? data = await _tblRefReactIconFamilyService.GetByIdAsync(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertAsync([FromBody]tblRefReactIconFamily tblRefReactIconFamily)
        {
            try
            {
                tblRefReactIconFamily? data = await _tblRefReactIconFamilyService.InsertAsync(tblRefReactIconFamily);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateAsync(int id,[FromBody]tblRefReactIconFamily tblRefReactIconFamily)
        {
            try
            {
                if(id != tblRefReactIconFamily.Id) return BadRequest("Id mismatched.");

                tblRefReactIconFamily? data = await _tblRefReactIconFamilyService.GetByIdAsync(id);
                if (data == null) return NotFound();

                tblRefReactIconFamily? updatedData = await _tblRefReactIconFamilyService.UpdateAsync(tblRefReactIconFamily); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdAsync(int id)
        {
            try
            {
                tblRefReactIconFamily? data = await _tblRefReactIconFamilyService.GetByIdAsync(id);
                if (data == null) return NotFound();

                var deletedData = await _tblRefReactIconFamilyService.DeleteByIdAsync(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk")]
        public async Task<IActionResult> BulkInsertAsync([FromBody]List<tblRefReactIconFamily> listData)
        {
            try
            {
                IEnumerable<tblRefReactIconFamily> data = await _tblRefReactIconFamilyService.BulkInsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPatch("bulk")]
        public async Task<IActionResult> BulkUpdateAsync([FromBody] List<tblRefReactIconFamily> listData)
        {
            try
            {
                IEnumerable<tblRefReactIconFamily> data = await _tblRefReactIconFamilyService.BulkUpdateAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-upsert")]
        public async Task<IActionResult> BulkUpsertAsync([FromBody] List<tblRefReactIconFamily> listData)
        {
            try
            {
                IEnumerable<tblRefReactIconFamily> data = await _tblRefReactIconFamilyService.BulkUpsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-merge")]
        public async Task<IActionResult> BulkMergeAsync([FromBody] List<tblRefReactIconFamily> listData)
        {
            try
            {
                IEnumerable<tblRefReactIconFamily> data = await _tblRefReactIconFamilyService.BulkMergeAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
    }
}
