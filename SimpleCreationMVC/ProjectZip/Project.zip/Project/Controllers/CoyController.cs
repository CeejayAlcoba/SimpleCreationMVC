using Microsoft.AspNetCore.Mvc;
using Models;
using Models.Pagination; 
using Services.Interfaces;

namespace ApiControllers
{
    [Route("api/coy")]
    [ApiController]
    public class CoyController : ControllerBase
    {
        private readonly ICoyService _coyService;

        public CoyController(ICoyService coyService)
        {
            _coyService = coyService;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetAllAsync([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10, [FromQuery] Coy? filter = null)
        {
            try
            {
                PagedResult<Coy> data = await _coyService.GetAllAsync(pageNumber, pageSize, filter);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdAsync(int id)
        {
            try
            {
                Coy? data = await _coyService.GetByIdAsync(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertAsync([FromBody]Coy coy)
        {
            try
            {
                Coy? data = await _coyService.InsertAsync(coy);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateAsync(int id,[FromBody]Coy coy)
        {
            try
            {
                if(id != coy.Id) return BadRequest("Id mismatched.");

                Coy? data = await _coyService.GetByIdAsync(id);
                if (data == null) return NotFound();

                Coy? updatedData = await _coyService.UpdateAsync(coy); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdAsync(int id)
        {
            try
            {
                Coy? data = await _coyService.GetByIdAsync(id);
                if (data == null) return NotFound();

                var deletedData = await _coyService.DeleteByIdAsync(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk")]
        public async Task<IActionResult> BulkInsertAsync([FromBody]List<Coy> listData)
        {
            try
            {
                IEnumerable<Coy> data = await _coyService.BulkInsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPatch("bulk")]
        public async Task<IActionResult> BulkUpdateAsync([FromBody] List<Coy> listData)
        {
            try
            {
                IEnumerable<Coy> data = await _coyService.BulkUpdateAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-upsert")]
        public async Task<IActionResult> BulkUpsertAsync([FromBody] List<Coy> listData)
        {
            try
            {
                IEnumerable<Coy> data = await _coyService.BulkUpsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-merge")]
        public async Task<IActionResult> BulkMergeAsync([FromBody] List<Coy> listData)
        {
            try
            {
                IEnumerable<Coy> data = await _coyService.BulkMergeAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
    }
}