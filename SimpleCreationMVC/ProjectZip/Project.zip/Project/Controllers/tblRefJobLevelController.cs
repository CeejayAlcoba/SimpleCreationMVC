
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-job-level")]
    [ApiController]
    public class tblRefJobLevelController : ControllerBase
    {
        private readonly tblRefJobLevelService tblRefJobLevelService = new tblRefJobLevelService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefJobLevel()
        {
            try
            {
                var data = await tblRefJobLevelService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefJobLevel(int id)
        {
            try
            {
                var data = await  tblRefJobLevelService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefJobLevel([FromBody]tblRefJobLevel tblRefJobLevel)
        {
            try
            {
                var data = await tblRefJobLevelService.Insert(tblRefJobLevel);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefJobLevel(int id,[FromBody]tblRefJobLevel tblRefJobLevel)
        {
            try
            {
                if(id != tblRefJobLevel.Id) return BadRequest("Id mismatched.");

                var data = await tblRefJobLevelService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefJobLevelService.Update(tblRefJobLevel); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefJobLevel(int id)
        {
            try
            {
                var data = await tblRefJobLevelService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefJobLevelService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
