
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.ApiControllers
{
    [Route("api/tbl-ref-role")]
    [ApiController]
    public class tblRefRoleController : ControllerBase
    {
        private readonly tblRefRoleService _tblRefRoleService = new tblRefRoleService();

        [HttpGet("list")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var data = await _tblRefRoleService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var data = await _tblRefRoleService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Insert([FromBody]tblRefRole tblRefRole)
        {
            try
            {
                var data = await _tblRefRoleService.Insert(tblRefRole);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id,[FromBody]tblRefRole tblRefRole)
        {
            try
            {
                if(id != tblRefRole.Id) return BadRequest("Id mismatched.");

                var data = await _tblRefRoleService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await _tblRefRoleService.Update(tblRefRole); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteById(int id)
        {
            try
            {
                var data = await _tblRefRoleService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await _tblRefRoleService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("many")]
        public async Task<IActionResult> InsertMany([FromBody]List<tblRefRole> listData)
        {
            try
            {
                var data = await _tblRefRoleService.InsertMany(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("many")]
        public async Task<IActionResult> UpdateMany([FromBody] List<tblRefRole> listData)
        {
            try
            {
                var data = await _tblRefRoleService.UpdateMany(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
