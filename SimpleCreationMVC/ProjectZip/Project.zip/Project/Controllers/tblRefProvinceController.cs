
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-province")]
    [ApiController]
    public class tblRefProvinceController : ControllerBase
    {
        private readonly tblRefProvinceService tblRefProvinceService = new tblRefProvinceService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefProvince()
        {
            try
            {
                var data = await tblRefProvinceService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefProvince(int id)
        {
            try
            {
                var data = await  tblRefProvinceService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefProvince([FromBody]tblRefProvince tblRefProvince)
        {
            try
            {
                var data = await tblRefProvinceService.Insert(tblRefProvince);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefProvince(int id,[FromBody]tblRefProvince tblRefProvince)
        {
            try
            {
                if(id != tblRefProvince.Id) return BadRequest("Id mismatched.");

                var data = await tblRefProvinceService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefProvinceService.Update(tblRefProvince); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefProvince(int id)
        {
            try
            {
                var data = await tblRefProvinceService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefProvinceService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
