
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-educational-data")]
    [ApiController]
    public class tblEducationalDataController : ControllerBase
    {
        private readonly tblEducationalDataService tblEducationalDataService = new tblEducationalDataService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblEducationalData()
        {
            try
            {
                var data = await tblEducationalDataService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblEducationalData(int id)
        {
            try
            {
                var data = await  tblEducationalDataService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblEducationalData([FromBody]tblEducationalData tblEducationalData)
        {
            try
            {
                var data = await tblEducationalDataService.Insert(tblEducationalData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblEducationalData(int id,[FromBody]tblEducationalData tblEducationalData)
        {
            try
            {
                if(id != tblEducationalData.Id) return BadRequest("Id mismatched.");

                var data = await tblEducationalDataService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblEducationalDataService.Update(tblEducationalData); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblEducationalData(int id)
        {
            try
            {
                var data = await tblEducationalDataService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblEducationalDataService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
