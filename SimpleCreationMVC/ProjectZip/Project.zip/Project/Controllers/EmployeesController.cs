
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/employees")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly EmployeesService employeesService = new EmployeesService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAllEmployees()
        {
            try
            {
                var data = await employeesService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdEmployees(int id)
        {
            try
            {
                var data = await  employeesService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertEmployees([FromBody]Employees employees)
        {
            try
            {
                var data = await employeesService.Insert(employees);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEmployees(int id,[FromBody]Employees employees)
        {
            try
            {
                if(id != employees.Id) return BadRequest("Id mismatched.");

                var data = await employeesService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await employeesService.Update(employees); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> HardDeleteByIdEmployees(int id)
        {
            try
            {
                var data = await employeesService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await employeesService.HardDeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
