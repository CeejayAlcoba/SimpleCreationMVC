
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-internal-work-experience")]
    [ApiController]
    public class tblInternalWorkExperienceController : ControllerBase
    {
        private readonly tblInternalWorkExperienceService tblInternalWorkExperienceService = new tblInternalWorkExperienceService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblInternalWorkExperience()
        {
            try
            {
                var data = await tblInternalWorkExperienceService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblInternalWorkExperience(int id)
        {
            try
            {
                var data = await  tblInternalWorkExperienceService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblInternalWorkExperience([FromBody]tblInternalWorkExperience tblInternalWorkExperience)
        {
            try
            {
                var data = await tblInternalWorkExperienceService.Insert(tblInternalWorkExperience);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblInternalWorkExperience(int id,[FromBody]tblInternalWorkExperience tblInternalWorkExperience)
        {
            try
            {
                if(id != tblInternalWorkExperience.Id) return BadRequest("Id mismatched.");

                var data = await tblInternalWorkExperienceService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblInternalWorkExperienceService.Update(tblInternalWorkExperience); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblInternalWorkExperience(int id)
        {
            try
            {
                var data = await tblInternalWorkExperienceService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblInternalWorkExperienceService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
