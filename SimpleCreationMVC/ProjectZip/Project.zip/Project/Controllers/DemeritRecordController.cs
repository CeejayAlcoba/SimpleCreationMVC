
using Microsoft.AspNetCore.Mvc;
using Models;
using Services.Interfaces;

namespace ApiControllers
{
    [Route("api/demerit-record")]
    [ApiController]
    public class DemeritRecordController : ControllerBase
    {
        private readonly IDemeritRecordService _demeritRecordService;

        public DemeritRecordController(IDemeritRecordService demeritRecordService)
        {
            _demeritRecordService = demeritRecordService;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetAllAsync([FromQuery]DemeritRecord filter)
        {
            try
            {
                IEnumerable<DemeritRecord> data = await _demeritRecordService.GetAllAsync(filter);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdAsync(int id)
        {
            try
            {
                DemeritRecord? data = await _demeritRecordService.GetByIdAsync(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertAsync([FromBody]DemeritRecord demeritRecord)
        {
            try
            {
                DemeritRecord? data = await _demeritRecordService.InsertAsync(demeritRecord);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateAsync(int id,[FromBody]DemeritRecord demeritRecord)
        {
            try
            {
                if(id != demeritRecord.Id) return BadRequest("Id mismatched.");

                DemeritRecord? data = await _demeritRecordService.GetByIdAsync(id);
                if (data == null) return NotFound();

                DemeritRecord? updatedData = await _demeritRecordService.UpdateAsync(demeritRecord); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdAsync(int id)
        {
            try
            {
                DemeritRecord? data = await _demeritRecordService.GetByIdAsync(id);
                if (data == null) return NotFound();

                var deletedData = await _demeritRecordService.DeleteByIdAsync(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk")]
        public async Task<IActionResult> BulkInsertAsync([FromBody]List<DemeritRecord> listData)
        {
            try
            {
                IEnumerable<DemeritRecord> data = await _demeritRecordService.BulkInsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPatch("bulk")]
        public async Task<IActionResult> BulkUpdateAsync([FromBody] List<DemeritRecord> listData)
        {
            try
            {
                IEnumerable<DemeritRecord> data = await _demeritRecordService.BulkUpdateAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-upsert")]
        public async Task<IActionResult> BulkUpsertAsync([FromBody] List<DemeritRecord> listData)
        {
            try
            {
                IEnumerable<DemeritRecord> data = await _demeritRecordService.BulkUpsertAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("bulk-merge")]
        public async Task<IActionResult> BulkMergeAsync([FromBody] List<DemeritRecord> listData)
        {
            try
            {
                IEnumerable<DemeritRecord> data = await _demeritRecordService.BulkMergeAsync(listData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
    }
}
