
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.ApiControllers
{
    [Route("api/subjects")]
    [ApiController]
    public class SubjectsController : ControllerBase
    {
        private readonly SubjectsService _subjectsService = new SubjectsService();

        [HttpGet("list")]
        public async Task<IActionResult> GetAllSubjects()
        {
            try
            {
                var data = await _subjectsService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdSubjects(int id)
        {
            try
            {
                var data = await  _subjectsService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertSubjects([FromBody]Subjects subjects)
        {
            try
            {
                var data = await _subjectsService.Insert(subjects);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateSubjects(int id,[FromBody]Subjects subjects)
        {
            try
            {
                if(id != subjects.Id) return BadRequest("Id mismatched.");

                var data = await _subjectsService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await _subjectsService.Update(subjects); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdSubjects(int id)
        {
            try
            {
                var data = await _subjectsService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await _subjectsService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
