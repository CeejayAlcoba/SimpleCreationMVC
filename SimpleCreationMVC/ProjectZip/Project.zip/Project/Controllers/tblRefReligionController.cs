
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-religion")]
    [ApiController]
    public class tblRefReligionController : ControllerBase
    {
        private readonly tblRefReligionService tblRefReligionService = new tblRefReligionService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefReligion()
        {
            try
            {
                var data = await tblRefReligionService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefReligion(int id)
        {
            try
            {
                var data = await  tblRefReligionService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefReligion([FromBody]tblRefReligion tblRefReligion)
        {
            try
            {
                var data = await tblRefReligionService.Insert(tblRefReligion);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefReligion(int id,[FromBody]tblRefReligion tblRefReligion)
        {
            try
            {
                if(id != tblRefReligion.Id) return BadRequest("Id mismatched.");

                var data = await tblRefReligionService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefReligionService.Update(tblRefReligion); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefReligion(int id)
        {
            try
            {
                var data = await tblRefReligionService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefReligionService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
