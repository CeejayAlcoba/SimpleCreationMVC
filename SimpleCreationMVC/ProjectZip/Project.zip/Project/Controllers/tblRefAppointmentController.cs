
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-appointment")]
    [ApiController]
    public class tblRefAppointmentController : ControllerBase
    {
        private readonly tblRefAppointmentService tblRefAppointmentService = new tblRefAppointmentService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefAppointment()
        {
            try
            {
                var data = await tblRefAppointmentService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefAppointment(int id)
        {
            try
            {
                var data = await  tblRefAppointmentService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefAppointment([FromBody]tblRefAppointment tblRefAppointment)
        {
            try
            {
                var data = await tblRefAppointmentService.Insert(tblRefAppointment);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefAppointment(int id,[FromBody]tblRefAppointment tblRefAppointment)
        {
            try
            {
                if(id != tblRefAppointment.Id) return BadRequest("Id mismatched.");

                var data = await tblRefAppointmentService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefAppointmentService.Update(tblRefAppointment); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefAppointment(int id)
        {
            try
            {
                var data = await tblRefAppointmentService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefAppointmentService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
