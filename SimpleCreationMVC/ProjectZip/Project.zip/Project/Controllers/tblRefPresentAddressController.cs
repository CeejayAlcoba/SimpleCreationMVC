
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-ref-present-address")]
    [ApiController]
    public class tblRefPresentAddressController : ControllerBase
    {
        private readonly tblRefPresentAddressService tblRefPresentAddressService = new tblRefPresentAddressService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblRefPresentAddress()
        {
            try
            {
                var data = await tblRefPresentAddressService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblRefPresentAddress(int id)
        {
            try
            {
                var data = await  tblRefPresentAddressService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblRefPresentAddress([FromBody]tblRefPresentAddress tblRefPresentAddress)
        {
            try
            {
                var data = await tblRefPresentAddressService.Insert(tblRefPresentAddress);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblRefPresentAddress(int id,[FromBody]tblRefPresentAddress tblRefPresentAddress)
        {
            try
            {
                if(id != tblRefPresentAddress.Id) return BadRequest("Id mismatched.");

                var data = await tblRefPresentAddressService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblRefPresentAddressService.Update(tblRefPresentAddress); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblRefPresentAddress(int id)
        {
            try
            {
                var data = await tblRefPresentAddressService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblRefPresentAddressService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
