
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-applicant-data")]
    [ApiController]
    public class tblApplicantDataController : ControllerBase
    {
        private readonly tblApplicantDataService tblApplicantDataService = new tblApplicantDataService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblApplicantData()
        {
            try
            {
                var data = await tblApplicantDataService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblApplicantData(int id)
        {
            try
            {
                var data = await  tblApplicantDataService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblApplicantData([FromBody]tblApplicantData tblApplicantData)
        {
            try
            {
                var data = await tblApplicantDataService.Insert(tblApplicantData);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblApplicantData(int id,[FromBody]tblApplicantData tblApplicantData)
        {
            try
            {
                if(id != tblApplicantData.Id) return BadRequest("Id mismatched.");

                var data = await tblApplicantDataService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblApplicantDataService.Update(tblApplicantData); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblApplicantData(int id)
        {
            try
            {
                var data = await tblApplicantDataService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblApplicantDataService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
