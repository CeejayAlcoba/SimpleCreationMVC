
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using Project.Services;

namespace Project.Controllers
{
    [Route("api/tbl-payroll-account-number")]
    [ApiController]
    public class tblPayrollAccountNumberController : ControllerBase
    {
        private readonly tblPayrollAccountNumberService tblPayrollAccountNumberService = new tblPayrollAccountNumberService();

        [HttpGet("all")]
        public async Task<IActionResult> GetAlltblPayrollAccountNumber()
        {
            try
            {
                var data = await tblPayrollAccountNumberService.GetAll();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdtblPayrollAccountNumber(int id)
        {
            try
            {
                var data = await  tblPayrollAccountNumberService.GetById(id);
                if (data == null) return NoContent();

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InserttblPayrollAccountNumber([FromBody]tblPayrollAccountNumber tblPayrollAccountNumber)
        {
            try
            {
                var data = await tblPayrollAccountNumberService.Insert(tblPayrollAccountNumber);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatetblPayrollAccountNumber(int id,[FromBody]tblPayrollAccountNumber tblPayrollAccountNumber)
        {
            try
            {
                if(id != tblPayrollAccountNumber.Id) return BadRequest("Id mismatched.");

                var data = await tblPayrollAccountNumberService.GetById(id);
                if (data == null) return NotFound();

                var updatedData = await tblPayrollAccountNumberService.Update(tblPayrollAccountNumber); 
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteByIdtblPayrollAccountNumber(int id)
        {
            try
            {
                var data = await tblPayrollAccountNumberService.GetById(id);
                if (data == null) return NotFound();

                var deletedData = await tblPayrollAccountNumberService.DeleteById(id);
                return Ok(deletedData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
