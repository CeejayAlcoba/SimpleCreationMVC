
namespace Utilities.Interfaces
{
    public interface IClaimsHelperUtility
    {
        int? GetUserId();
    }
}
