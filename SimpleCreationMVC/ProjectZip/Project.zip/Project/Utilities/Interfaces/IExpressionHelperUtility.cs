
using System;
using System.Linq.Expressions;

namespace Utilities.Interfaces
{
    public interface IExpressionHelperUtility
    {
        Expression<Func<T, object>>? GetOrderByExpression<T>(string? propertyName);
    }
}
