
namespace Utilities.Interfaces
{
    public interface IAutoMapperUtility
    {
        TDestination Map<TDestination>(object source);
        List<TDestination> MapList<TDestination>(IEnumerable<object> source);
    }
}
