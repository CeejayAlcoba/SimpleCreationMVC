
namespace Utilities.Interfaces
{
    public interface IAppUtility
    {
        IConfigurationRoot GetConfiguration();
    }
}
