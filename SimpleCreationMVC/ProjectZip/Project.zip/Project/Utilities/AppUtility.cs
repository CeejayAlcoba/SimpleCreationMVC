
using Microsoft.Extensions.Configuration;
namespace Repositories.Utilities
{
    public class AppUtility
    { 
           public IConfigurationRoot configuration = new ConfigurationBuilder()
           .SetBasePath(Directory.GetCurrentDirectory())
           .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
           .Build();
    }
}
