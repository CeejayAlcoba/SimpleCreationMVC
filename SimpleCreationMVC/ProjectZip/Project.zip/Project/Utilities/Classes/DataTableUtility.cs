
using System.Data;
using System.Reflection;
using Utilities.Interfaces;

namespace Utilities.Classes
{
    public class DataTableUtility : IDataTableUtility
    {
        public DataTable Convert<T>(IEnumerable<T> lists) where T : class
        {
            if (lists == null || !lists.Any())
                throw new ArgumentException("The list cannot be null or empty.");

            DataTable dt = new DataTable(typeof(T).Name);
            PropertyInfo[] properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            // Add columns to DataTable
            foreach (PropertyInfo property in properties)
            {
                Type columnType = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                dt.Columns.Add(property.Name, columnType);
            }

            // Add rows to DataTable
            foreach (T item in lists)
            {
                DataRow row = dt.NewRow();
                foreach (PropertyInfo property in properties)
                {
                    row[property.Name] = property.GetValue(item) ?? DBNull.Value;
                }
                dt.Rows.Add(row);
            }

            return dt;
        }
    }
}

