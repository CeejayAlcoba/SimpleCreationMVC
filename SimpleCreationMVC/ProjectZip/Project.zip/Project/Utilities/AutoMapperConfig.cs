
using AutoMapper;

namespace Repositories.Utilities
{
    public class AutoMapperConfig
    {
        public TDestination Map<TDestination>(object source)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap(source.GetType(), typeof(TDestination));
            });
            var mapper = new Mapper(config);
            return mapper.Map<TDestination>(source);
        }
        public List<TDestination> MapList<TDestination>(IEnumerable<object> source)
        {
            if (source == null || !source.Any())
            {
                return new List<TDestination>();
            }
            var sourceType = source.First().GetType();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap(sourceType, typeof(TDestination));
            });
            var mapper = new Mapper(config);

            // Perform mapping
            return mapper.Map<List<TDestination>>(source);
        }
    }
}
