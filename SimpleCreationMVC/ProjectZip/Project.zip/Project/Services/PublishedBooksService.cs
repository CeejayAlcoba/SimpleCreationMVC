
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class PublishedBooksService
    {
        private readonly PublishedBooksRepository _publishedBooksRepository = new PublishedBooksRepository();

        public async Task<PublishedBooks> Insert(PublishedBooks data)
        {
           return await _publishedBooksRepository.Insert(data);
        }

        public async Task<PublishedBooks> Update(PublishedBooks data)
        {
            return await _publishedBooksRepository.Update(data);
        }

        public async Task<IEnumerable<PublishedBooks>> GetAll()
        {
            return await _publishedBooksRepository.GetAll();
        }

        public async Task<PublishedBooks> GetById(int id)
        {
            return await _publishedBooksRepository.GetById(id);
        }
        public async Task<PublishedBooks> HardDeleteById(int id)
        {
              return await  _publishedBooksRepository.HardDeleteById(id);
        }
    }
}