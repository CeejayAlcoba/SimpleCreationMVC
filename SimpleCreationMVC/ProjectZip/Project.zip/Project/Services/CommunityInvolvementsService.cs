
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class CommunityInvolvementsService
    {
        private readonly CommunityInvolvementsRepository _communityInvolvementsRepository = new CommunityInvolvementsRepository();

        public async Task<CommunityInvolvements> Insert(CommunityInvolvements data)
        {
           return await _communityInvolvementsRepository.Insert(data);
        }

        public async Task<CommunityInvolvements> Update(CommunityInvolvements data)
        {
            return await _communityInvolvementsRepository.Update(data);
        }

        public async Task<IEnumerable<CommunityInvolvements>> GetAll()
        {
            return await _communityInvolvementsRepository.GetAll();
        }

        public async Task<CommunityInvolvements> GetById(int id)
        {
            return await _communityInvolvementsRepository.GetById(id);
        }
        public async Task<CommunityInvolvements> HardDeleteById(int id)
        {
              return await  _communityInvolvementsRepository.HardDeleteById(id);
        }
    }
}