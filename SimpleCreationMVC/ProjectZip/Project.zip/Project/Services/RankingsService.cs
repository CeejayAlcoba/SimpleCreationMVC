
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class RankingsService
    {
        private readonly RankingsRepository _rankingsRepository = new RankingsRepository();

        public async Task<Rankings> Insert(Rankings data)
        {
           return await _rankingsRepository.Insert(data);
        }

        public async Task<Rankings> Update(Rankings data)
        {
            return await _rankingsRepository.Update(data);
        }

        public async Task<IEnumerable<Rankings>> GetAll()
        {
            return await _rankingsRepository.GetAll();
        }

        public async Task<Rankings> GetById(int id)
        {
            return await _rankingsRepository.GetById(id);
        }
        public async Task<Rankings> HardDeleteById(int id)
        {
              return await  _rankingsRepository.HardDeleteById(id);
        }
    }
}