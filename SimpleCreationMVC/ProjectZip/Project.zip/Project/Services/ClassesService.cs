
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class ClassesService
    {
        private readonly ClassesRepository _classesRepository = new ClassesRepository();

        public async Task<Classes?> Insert(Classes data)
        {
            return await _classesRepository.Insert(data);
        }

        public async Task<Classes?> Update(Classes data)
        {
            return await _classesRepository.Update(data);
        }

        public async Task<IEnumerable<Classes>> GetAll()
        {
            return await _classesRepository.GetAll();
        }

        public async Task<Classes?> GetById(int id)
        {
            return await _classesRepository.GetById(id);
        }

        public async Task<Classes?> DeleteById(int id)
        {
            return await _classesRepository.DeleteById(id);
        }
        public async Task<IEnumerable<Classes>> InsertMany(List<Classes> data)
        {
            return await _classesRepository.InsertMany(data);
        }
        public async Task<IEnumerable<Classes>> UpdateMany(List<Classes> data)
        {
            return await _classesRepository.UpdateMany(data);
        }
    }
}