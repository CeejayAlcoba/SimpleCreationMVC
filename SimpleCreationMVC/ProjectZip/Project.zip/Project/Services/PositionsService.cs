
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class PositionsService
    {
        private readonly PositionsRepository _positionsRepository = new PositionsRepository();

        public async Task<Positions> Insert(Positions data)
        {
           return await _positionsRepository.Insert(data);
        }

        public async Task<Positions> Update(Positions data)
        {
            return await _positionsRepository.Update(data);
        }

        public async Task<IEnumerable<Positions>> GetAll()
        {
            return await _positionsRepository.GetAll();
        }

        public async Task<Positions> GetById(int id)
        {
            return await _positionsRepository.GetById(id);
        }
        public async Task<Positions> HardDeleteById(int id)
        {
              return await  _positionsRepository.HardDeleteById(id);
        }
    }
}