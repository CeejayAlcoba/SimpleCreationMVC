
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblSalaryHistoryLogService
    {
        private readonly tblSalaryHistoryLogRepository _tblSalaryHistoryLogRepository = new tblSalaryHistoryLogRepository();

        public async Task<tblSalaryHistoryLog> Insert(tblSalaryHistoryLog data)
        {
           return await _tblSalaryHistoryLogRepository.Insert(data);
        }

        public async Task<tblSalaryHistoryLog> Update(tblSalaryHistoryLog data)
        {
            return await _tblSalaryHistoryLogRepository.Update(data);
        }

        public async Task<IEnumerable<tblSalaryHistoryLog>> GetAll()
        {
            return await _tblSalaryHistoryLogRepository.GetAll();
        }

        public async Task<tblSalaryHistoryLog> GetById(int id)
        {
            return await _tblSalaryHistoryLogRepository.GetById(id);
        }
        public async Task<tblSalaryHistoryLog> DeleteById(int id)
        {
              return await  _tblSalaryHistoryLogRepository.DeleteById(id);
        }
    }
}