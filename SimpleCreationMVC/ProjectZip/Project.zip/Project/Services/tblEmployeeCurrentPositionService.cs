
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblEmployeeCurrentPositionService
    {
        private readonly tblEmployeeCurrentPositionRepository _tblEmployeeCurrentPositionRepository = new tblEmployeeCurrentPositionRepository();

        public async Task<tblEmployeeCurrentPosition> Insert(tblEmployeeCurrentPosition data)
        {
           return await _tblEmployeeCurrentPositionRepository.Insert(data);
        }

        public async Task<tblEmployeeCurrentPosition> Update(tblEmployeeCurrentPosition data)
        {
            return await _tblEmployeeCurrentPositionRepository.Update(data);
        }

        public async Task<IEnumerable<tblEmployeeCurrentPosition>> GetAll()
        {
            return await _tblEmployeeCurrentPositionRepository.GetAll();
        }

        public async Task<tblEmployeeCurrentPosition> GetById(int id)
        {
            return await _tblEmployeeCurrentPositionRepository.GetById(id);
        }
        public async Task<tblEmployeeCurrentPosition> DeleteById(int id)
        {
              return await  _tblEmployeeCurrentPositionRepository.DeleteById(id);
        }
    }
}