
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class EducationalDatasService
    {
        private readonly EducationalDatasRepository _educationalDatasRepository = new EducationalDatasRepository();

        public async Task<EducationalDatas> Insert(EducationalDatas data)
        {
           return await _educationalDatasRepository.Insert(data);
        }

        public async Task<EducationalDatas> Update(EducationalDatas data)
        {
            return await _educationalDatasRepository.Update(data);
        }

        public async Task<IEnumerable<EducationalDatas>> GetAll()
        {
            return await _educationalDatasRepository.GetAll();
        }

        public async Task<EducationalDatas> GetById(int id)
        {
            return await _educationalDatasRepository.GetById(id);
        }
        public async Task<EducationalDatas> HardDeleteById(int id)
        {
              return await  _educationalDatasRepository.HardDeleteById(id);
        }
    }
}