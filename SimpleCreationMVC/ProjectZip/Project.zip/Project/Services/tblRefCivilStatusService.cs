
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefCivilStatusService
    {
        private readonly tblRefCivilStatusRepository _tblRefCivilStatusRepository = new tblRefCivilStatusRepository();

        public async Task<tblRefCivilStatus> Insert(tblRefCivilStatus data)
        {
           return await _tblRefCivilStatusRepository.Insert(data);
        }

        public async Task<tblRefCivilStatus> Update(tblRefCivilStatus data)
        {
            return await _tblRefCivilStatusRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefCivilStatus>> GetAll()
        {
            return await _tblRefCivilStatusRepository.GetAll();
        }

        public async Task<tblRefCivilStatus> GetById(int id)
        {
            return await _tblRefCivilStatusRepository.GetById(id);
        }
        public async Task<tblRefCivilStatus> DeleteById(int id)
        {
              return await  _tblRefCivilStatusRepository.DeleteById(id);
        }
    }
}