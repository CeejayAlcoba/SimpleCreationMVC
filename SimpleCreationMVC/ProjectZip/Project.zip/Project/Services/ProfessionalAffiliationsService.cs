
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class ProfessionalAffiliationsService
    {
        private readonly ProfessionalAffiliationsRepository _professionalAffiliationsRepository = new ProfessionalAffiliationsRepository();

        public async Task<ProfessionalAffiliations> Insert(ProfessionalAffiliations data)
        {
           return await _professionalAffiliationsRepository.Insert(data);
        }

        public async Task<ProfessionalAffiliations> Update(ProfessionalAffiliations data)
        {
            return await _professionalAffiliationsRepository.Update(data);
        }

        public async Task<IEnumerable<ProfessionalAffiliations>> GetAll()
        {
            return await _professionalAffiliationsRepository.GetAll();
        }

        public async Task<ProfessionalAffiliations> GetById(int id)
        {
            return await _professionalAffiliationsRepository.GetById(id);
        }
        public async Task<ProfessionalAffiliations> HardDeleteById(int id)
        {
              return await  _professionalAffiliationsRepository.HardDeleteById(id);
        }
    }
}