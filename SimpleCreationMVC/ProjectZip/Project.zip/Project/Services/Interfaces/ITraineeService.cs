
using Models;

namespace Services.Interfaces
{
    public interface ITraineeService
    {
        Task<Trainee?> InsertAsync(Trainee data);
        Task<Trainee?> UpdateAsync(Trainee data);
        Task<IEnumerable<Trainee>> GetAllAsync(Trainee? filter);
        Task<Trainee?> GetByIdAsync(int id);
        Task<Trainee?> DeleteByIdAsync(int id);
        Task<IEnumerable<Trainee>> BulkInsertAsync(List<Trainee> data);
        Task<IEnumerable<Trainee>> BulkUpdateAsync(List<Trainee> data);
        Task<IEnumerable<Trainee>> BulkUpsertAsync(List<Trainee> data);
        Task<IEnumerable<Trainee>> BulkMergeAsync(List<Trainee> data);
    }
}
