
using Models;

namespace Services.Interfaces
{
    public interface ItblRefReactIconFamilyService
    {
        Task<tblRefReactIconFamily?> InsertAsync(tblRefReactIconFamily data);
        Task<tblRefReactIconFamily?> UpdateAsync(tblRefReactIconFamily data);
        Task<IEnumerable<tblRefReactIconFamily>> GetAllAsync(tblRefReactIconFamily? filter);
        Task<tblRefReactIconFamily?> GetByIdAsync(int id);
        Task<tblRefReactIconFamily?> DeleteByIdAsync(int id);
        Task<IEnumerable<tblRefReactIconFamily>> BulkInsertAsync(List<tblRefReactIconFamily> data);
        Task<IEnumerable<tblRefReactIconFamily>> BulkUpdateAsync(List<tblRefReactIconFamily> data);
        Task<IEnumerable<tblRefReactIconFamily>> BulkUpsertAsync(List<tblRefReactIconFamily> data);
        Task<IEnumerable<tblRefReactIconFamily>> BulkMergeAsync(List<tblRefReactIconFamily> data);
    }
}
