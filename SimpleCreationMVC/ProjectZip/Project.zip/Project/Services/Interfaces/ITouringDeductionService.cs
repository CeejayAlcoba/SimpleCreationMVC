
using Models;

namespace Services.Interfaces
{
    public interface ITouringDeductionService
    {
        Task<TouringDeduction?> InsertAsync(TouringDeduction data);
        Task<TouringDeduction?> UpdateAsync(TouringDeduction data);
        Task<IEnumerable<TouringDeduction>> GetAllAsync(TouringDeduction? filter);
        Task<TouringDeduction?> GetByIdAsync(int id);
        Task<TouringDeduction?> DeleteByIdAsync(int id);
        Task<IEnumerable<TouringDeduction>> BulkInsertAsync(List<TouringDeduction> data);
        Task<IEnumerable<TouringDeduction>> BulkUpdateAsync(List<TouringDeduction> data);
        Task<IEnumerable<TouringDeduction>> BulkUpsertAsync(List<TouringDeduction> data);
        Task<IEnumerable<TouringDeduction>> BulkMergeAsync(List<TouringDeduction> data);
    }
}
