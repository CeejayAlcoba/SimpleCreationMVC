using Models;
using Models.Pagination;

namespace Services.Interfaces
{
    public interface ICoyService
    {
        Task<Coy?> InsertAsync(Coy data);
        Task<Coy?> UpdateAsync(Coy data);
        Task<PagedResult<Coy>> GetAllAsync(int pageNumber = 1, int pageSize = 10, Coy? filter = null);
        Task<Coy?> GetByIdAsync(int id);
        Task<Coy?> DeleteByIdAsync(int id);
        Task<IEnumerable<Coy>> BulkInsertAsync(List<Coy> data);
        Task<IEnumerable<Coy>> BulkUpdateAsync(List<Coy> data);
        Task<IEnumerable<Coy>> BulkUpsertAsync(List<Coy> data);
        Task<IEnumerable<Coy>> BulkMergeAsync(List<Coy> data);
    }
}
