
using Models;

namespace Services.Interfaces
{
    public interface ItblRefReactIconService
    {
        Task<tblRefReactIcon?> InsertAsync(tblRefReactIcon data);
        Task<tblRefReactIcon?> UpdateAsync(tblRefReactIcon data);
        Task<IEnumerable<tblRefReactIcon>> GetAllAsync(tblRefReactIcon? filter);
        Task<tblRefReactIcon?> GetByIdAsync(int id);
        Task<tblRefReactIcon?> DeleteByIdAsync(int id);
        Task<IEnumerable<tblRefReactIcon>> BulkInsertAsync(List<tblRefReactIcon> data);
        Task<IEnumerable<tblRefReactIcon>> BulkUpdateAsync(List<tblRefReactIcon> data);
        Task<IEnumerable<tblRefReactIcon>> BulkUpsertAsync(List<tblRefReactIcon> data);
        Task<IEnumerable<tblRefReactIcon>> BulkMergeAsync(List<tblRefReactIcon> data);
    }
}
