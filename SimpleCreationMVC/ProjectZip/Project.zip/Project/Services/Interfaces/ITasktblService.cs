
using Models;

namespace Services.Interfaces
{
    public interface ITasktblService
    {
        Task<Tasktbl?> InsertAsync(Tasktbl data);
        Task<Tasktbl?> UpdateAsync(Tasktbl data);
        Task<IEnumerable<Tasktbl>> GetAllAsync();
        Task<Tasktbl?> GetByIdAsync(int id);
        Task<Tasktbl?> DeleteByIdAsync(int id);
        Task<IEnumerable<Tasktbl>> BulkInsertAsync(List<Tasktbl> data);
        Task<IEnumerable<Tasktbl>> BulkUpdateAsync(List<Tasktbl> data);
        Task<IEnumerable<Tasktbl>> BulkUpsertAsync(List<Tasktbl> data);
        Task<IEnumerable<Tasktbl>> BulkMergeAsync(List<Tasktbl> data);
    }
}
