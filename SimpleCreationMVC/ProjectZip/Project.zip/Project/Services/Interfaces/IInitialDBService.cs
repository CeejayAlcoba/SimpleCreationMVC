using Models;
using Models.Pagination;
using System.Linq.Expressions;

namespace Services.Interfaces
{
    public interface IInitialDBService
    {
        Task<InitialDB?> InsertAsync(InitialDB data);
        Task<InitialDB?> UpdateAsync(InitialDB data);
        Task<PagedResult<InitialDB>> GetAllAsync(int pageNumber = 1, int pageSize = 10, InitialDB? filter = null, Expression<Func<InitialDB, object>>? orderByProperty = null, bool isDescending = false, params Expression<Func<InitialDB, object>>[] includes);
        Task<InitialDB?> GetByIdAsync(int id);
        Task<InitialDB?> DeleteByIdAsync(int id);
        Task<IEnumerable<InitialDB>> BulkInsertAsync(List<InitialDB> data);
        Task<IEnumerable<InitialDB>> BulkUpdateAsync(List<InitialDB> data);
        Task<IEnumerable<InitialDB>> BulkUpsertAsync(List<InitialDB> data);
        Task<IEnumerable<InitialDB>> BulkMergeAsync(List<InitialDB> data);
    }
}
