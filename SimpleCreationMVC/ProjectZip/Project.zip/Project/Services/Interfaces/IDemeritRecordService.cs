
using Models;

namespace Services.Interfaces
{
    public interface IDemeritRecordService
    {
        Task<DemeritRecord?> InsertAsync(DemeritRecord data);
        Task<DemeritRecord?> UpdateAsync(DemeritRecord data);
        Task<IEnumerable<DemeritRecord>> GetAllAsync(DemeritRecord? filter);
        Task<DemeritRecord?> GetByIdAsync(int id);
        Task<DemeritRecord?> DeleteByIdAsync(int id);
        Task<IEnumerable<DemeritRecord>> BulkInsertAsync(List<DemeritRecord> data);
        Task<IEnumerable<DemeritRecord>> BulkUpdateAsync(List<DemeritRecord> data);
        Task<IEnumerable<DemeritRecord>> BulkUpsertAsync(List<DemeritRecord> data);
        Task<IEnumerable<DemeritRecord>> BulkMergeAsync(List<DemeritRecord> data);
    }
}
