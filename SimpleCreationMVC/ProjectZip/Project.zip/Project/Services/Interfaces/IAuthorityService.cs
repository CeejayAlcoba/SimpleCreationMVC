
using Models;

namespace Services.Interfaces
{
    public interface IAuthorityService
    {
        Task<Authority?> InsertAsync(Authority data);
        Task<Authority?> UpdateAsync(Authority data);
        Task<IEnumerable<Authority>> GetAllAsync(Authority? filter);
        Task<Authority?> GetByIdAsync(int id);
        Task<Authority?> DeleteByIdAsync(int id);
        Task<IEnumerable<Authority>> BulkInsertAsync(List<Authority> data);
        Task<IEnumerable<Authority>> BulkUpdateAsync(List<Authority> data);
        Task<IEnumerable<Authority>> BulkUpsertAsync(List<Authority> data);
        Task<IEnumerable<Authority>> BulkMergeAsync(List<Authority> data);
    }
}
