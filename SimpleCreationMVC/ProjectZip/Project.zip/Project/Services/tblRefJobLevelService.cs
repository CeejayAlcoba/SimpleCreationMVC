
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefJobLevelService
    {
        private readonly tblRefJobLevelRepository _tblRefJobLevelRepository = new tblRefJobLevelRepository();

        public async Task<tblRefJobLevel> Insert(tblRefJobLevel data)
        {
           return await _tblRefJobLevelRepository.Insert(data);
        }

        public async Task<tblRefJobLevel> Update(tblRefJobLevel data)
        {
            return await _tblRefJobLevelRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefJobLevel>> GetAll()
        {
            return await _tblRefJobLevelRepository.GetAll();
        }

        public async Task<tblRefJobLevel> GetById(int id)
        {
            return await _tblRefJobLevelRepository.GetById(id);
        }
        public async Task<tblRefJobLevel> DeleteById(int id)
        {
              return await  _tblRefJobLevelRepository.DeleteById(id);
        }
    }
}