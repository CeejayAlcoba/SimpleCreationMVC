
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class SeminarsAndTrainingsService
    {
        private readonly SeminarsAndTrainingsRepository _seminarsAndTrainingsRepository = new SeminarsAndTrainingsRepository();

        public async Task<SeminarsAndTrainings> Insert(SeminarsAndTrainings data)
        {
           return await _seminarsAndTrainingsRepository.Insert(data);
        }

        public async Task<SeminarsAndTrainings> Update(SeminarsAndTrainings data)
        {
            return await _seminarsAndTrainingsRepository.Update(data);
        }

        public async Task<IEnumerable<SeminarsAndTrainings>> GetAll()
        {
            return await _seminarsAndTrainingsRepository.GetAll();
        }

        public async Task<SeminarsAndTrainings> GetById(int id)
        {
            return await _seminarsAndTrainingsRepository.GetById(id);
        }
        public async Task<SeminarsAndTrainings> HardDeleteById(int id)
        {
              return await  _seminarsAndTrainingsRepository.HardDeleteById(id);
        }
    }
}