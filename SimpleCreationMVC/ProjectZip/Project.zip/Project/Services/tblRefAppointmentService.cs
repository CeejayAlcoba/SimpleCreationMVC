
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefAppointmentService
    {
        private readonly tblRefAppointmentRepository _tblRefAppointmentRepository = new tblRefAppointmentRepository();

        public async Task<tblRefAppointment> Insert(tblRefAppointment data)
        {
           return await _tblRefAppointmentRepository.Insert(data);
        }

        public async Task<tblRefAppointment> Update(tblRefAppointment data)
        {
            return await _tblRefAppointmentRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefAppointment>> GetAll()
        {
            return await _tblRefAppointmentRepository.GetAll();
        }

        public async Task<tblRefAppointment> GetById(int id)
        {
            return await _tblRefAppointmentRepository.GetById(id);
        }
        public async Task<tblRefAppointment> DeleteById(int id)
        {
              return await  _tblRefAppointmentRepository.DeleteById(id);
        }
    }
}