
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefSalaryTypeService
    {
        private readonly tblRefSalaryTypeRepository _tblRefSalaryTypeRepository = new tblRefSalaryTypeRepository();

        public async Task<tblRefSalaryType> Insert(tblRefSalaryType data)
        {
           return await _tblRefSalaryTypeRepository.Insert(data);
        }

        public async Task<tblRefSalaryType> Update(tblRefSalaryType data)
        {
            return await _tblRefSalaryTypeRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefSalaryType>> GetAll()
        {
            return await _tblRefSalaryTypeRepository.GetAll();
        }

        public async Task<tblRefSalaryType> GetById(int id)
        {
            return await _tblRefSalaryTypeRepository.GetById(id);
        }
        public async Task<tblRefSalaryType> DeleteById(int id)
        {
              return await  _tblRefSalaryTypeRepository.DeleteById(id);
        }
    }
}