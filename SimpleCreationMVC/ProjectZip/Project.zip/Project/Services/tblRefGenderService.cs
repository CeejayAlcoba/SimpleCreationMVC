
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefGenderService
    {
        private readonly tblRefGenderRepository _tblRefGenderRepository = new tblRefGenderRepository();

        public async Task<tblRefGender> Insert(tblRefGender data)
        {
           return await _tblRefGenderRepository.Insert(data);
        }

        public async Task<tblRefGender> Update(tblRefGender data)
        {
            return await _tblRefGenderRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefGender>> GetAll()
        {
            return await _tblRefGenderRepository.GetAll();
        }

        public async Task<tblRefGender> GetById(int id)
        {
            return await _tblRefGenderRepository.GetById(id);
        }
        public async Task<tblRefGender> DeleteById(int id)
        {
              return await  _tblRefGenderRepository.DeleteById(id);
        }
    }
}