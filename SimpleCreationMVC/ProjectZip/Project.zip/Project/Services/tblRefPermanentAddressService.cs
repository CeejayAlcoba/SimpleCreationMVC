
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefPermanentAddressService
    {
        private readonly tblRefPermanentAddressRepository _tblRefPermanentAddressRepository = new tblRefPermanentAddressRepository();

        public async Task<tblRefPermanentAddress> Insert(tblRefPermanentAddress data)
        {
           return await _tblRefPermanentAddressRepository.Insert(data);
        }

        public async Task<tblRefPermanentAddress> Update(tblRefPermanentAddress data)
        {
            return await _tblRefPermanentAddressRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefPermanentAddress>> GetAll()
        {
            return await _tblRefPermanentAddressRepository.GetAll();
        }

        public async Task<tblRefPermanentAddress> GetById(int id)
        {
            return await _tblRefPermanentAddressRepository.GetById(id);
        }
        public async Task<tblRefPermanentAddress> DeleteById(int id)
        {
              return await  _tblRefPermanentAddressRepository.DeleteById(id);
        }
    }
}