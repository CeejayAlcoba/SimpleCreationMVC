
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefReligionService
    {
        private readonly tblRefReligionRepository _tblRefReligionRepository = new tblRefReligionRepository();

        public async Task<tblRefReligion> Insert(tblRefReligion data)
        {
           return await _tblRefReligionRepository.Insert(data);
        }

        public async Task<tblRefReligion> Update(tblRefReligion data)
        {
            return await _tblRefReligionRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefReligion>> GetAll()
        {
            return await _tblRefReligionRepository.GetAll();
        }

        public async Task<tblRefReligion> GetById(int id)
        {
            return await _tblRefReligionRepository.GetById(id);
        }
        public async Task<tblRefReligion> DeleteById(int id)
        {
              return await  _tblRefReligionRepository.DeleteById(id);
        }
    }
}