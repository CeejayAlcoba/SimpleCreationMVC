
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefGradeLevelService
    {
        private readonly tblRefGradeLevelRepository _tblRefGradeLevelRepository = new tblRefGradeLevelRepository();

        public async Task<tblRefGradeLevel> Insert(tblRefGradeLevel data)
        {
           return await _tblRefGradeLevelRepository.Insert(data);
        }

        public async Task<tblRefGradeLevel> Update(tblRefGradeLevel data)
        {
            return await _tblRefGradeLevelRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefGradeLevel>> GetAll()
        {
            return await _tblRefGradeLevelRepository.GetAll();
        }

        public async Task<tblRefGradeLevel> GetById(int id)
        {
            return await _tblRefGradeLevelRepository.GetById(id);
        }
        public async Task<tblRefGradeLevel> DeleteById(int id)
        {
              return await  _tblRefGradeLevelRepository.DeleteById(id);
        }
    }
}