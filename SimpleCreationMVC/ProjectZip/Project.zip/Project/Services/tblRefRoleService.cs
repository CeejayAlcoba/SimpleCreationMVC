
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefRoleService
    {
        private readonly tblRefRoleRepository _tblRefRoleRepository = new tblRefRoleRepository();

        public async Task<tblRefRole?> Insert(tblRefRole data)
        {
            return await _tblRefRoleRepository.Insert(data);
        }

        public async Task<tblRefRole?> Update(tblRefRole data)
        {
            return await _tblRefRoleRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefRole>> GetAll()
        {
            return await _tblRefRoleRepository.GetAll();
        }

        public async Task<tblRefRole?> GetById(int id)
        {
            return await _tblRefRoleRepository.GetById(id);
        }

        public async Task<tblRefRole?> DeleteById(int id)
        {
            return await _tblRefRoleRepository.DeleteById(id);
        }
        public async Task<IEnumerable<tblRefRole>> InsertMany(List<tblRefRole> data)
        {
            return await _tblRefRoleRepository.InsertMany(data);
        }
        public async Task<IEnumerable<tblRefRole>> UpdateMany(List<tblRefRole> data)
        {
            return await _tblRefRoleRepository.UpdateMany(data);
        }
    }
}