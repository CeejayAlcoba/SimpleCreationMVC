
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefPositionService
    {
        private readonly tblRefPositionRepository _tblRefPositionRepository = new tblRefPositionRepository();

        public async Task<tblRefPosition> Insert(tblRefPosition data)
        {
           return await _tblRefPositionRepository.Insert(data);
        }

        public async Task<tblRefPosition> Update(tblRefPosition data)
        {
            return await _tblRefPositionRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefPosition>> GetAll()
        {
            return await _tblRefPositionRepository.GetAll();
        }

        public async Task<tblRefPosition> GetById(int id)
        {
            return await _tblRefPositionRepository.GetById(id);
        }
        public async Task<tblRefPosition> DeleteById(int id)
        {
              return await  _tblRefPositionRepository.DeleteById(id);
        }
    }
}