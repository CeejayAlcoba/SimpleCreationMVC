
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class SubjectsService
    {
        private readonly SubjectsRepository _subjectsRepository = new SubjectsRepository();

        public async Task<Subjects?> Insert(Subjects data)
        {
            return await _subjectsRepository.Insert(data);
        }

        public async Task<Subjects?> Update(Subjects data)
        {
            return await _subjectsRepository.Update(data);
        }

        public async Task<IEnumerable<Subjects>> GetAll()
        {
            return await _subjectsRepository.GetAll();
        }

        public async Task<Subjects?> GetById(int id)
        {
            return await _subjectsRepository.GetById(id);
        }

        public async Task<Subjects?> DeleteById(int id)
        {
            return await _subjectsRepository.DeleteById(id);
        }
    }
}