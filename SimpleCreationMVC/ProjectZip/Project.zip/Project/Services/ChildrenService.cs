
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class ChildrenService
    {
        private readonly ChildrenRepository _childrenRepository = new ChildrenRepository();

        public async Task<Children> Insert(Children data)
        {
           return await _childrenRepository.Insert(data);
        }

        public async Task<Children> Update(Children data)
        {
            return await _childrenRepository.Update(data);
        }

        public async Task<IEnumerable<Children>> GetAll()
        {
            return await _childrenRepository.GetAll();
        }

        public async Task<Children> GetById(int id)
        {
            return await _childrenRepository.GetById(id);
        }
        public async Task<Children> HardDeleteById(int id)
        {
              return await  _childrenRepository.HardDeleteById(id);
        }
    }
}