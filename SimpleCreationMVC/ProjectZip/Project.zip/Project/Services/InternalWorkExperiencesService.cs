
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class InternalWorkExperiencesService
    {
        private readonly InternalWorkExperiencesRepository _internalWorkExperiencesRepository = new InternalWorkExperiencesRepository();

        public async Task<InternalWorkExperiences> Insert(InternalWorkExperiences data)
        {
           return await _internalWorkExperiencesRepository.Insert(data);
        }

        public async Task<InternalWorkExperiences> Update(InternalWorkExperiences data)
        {
            return await _internalWorkExperiencesRepository.Update(data);
        }

        public async Task<IEnumerable<InternalWorkExperiences>> GetAll()
        {
            return await _internalWorkExperiencesRepository.GetAll();
        }

        public async Task<InternalWorkExperiences> GetById(int id)
        {
            return await _internalWorkExperiencesRepository.GetById(id);
        }
        public async Task<InternalWorkExperiences> HardDeleteById(int id)
        {
              return await  _internalWorkExperiencesRepository.HardDeleteById(id);
        }
    }
}