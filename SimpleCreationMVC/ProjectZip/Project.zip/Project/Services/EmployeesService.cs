
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class EmployeesService
    {
        private readonly EmployeesRepository _employeesRepository = new EmployeesRepository();

        public async Task<Employees> Insert(Employees data)
        {
           return await _employeesRepository.Insert(data);
        }

        public async Task<Employees> Update(Employees data)
        {
            return await _employeesRepository.Update(data);
        }

        public async Task<IEnumerable<Employees>> GetAll()
        {
            return await _employeesRepository.GetAll();
        }

        public async Task<Employees> GetById(int id)
        {
            return await _employeesRepository.GetById(id);
        }
        public async Task<Employees> HardDeleteById(int id)
        {
              return await  _employeesRepository.HardDeleteById(id);
        }
    }
}