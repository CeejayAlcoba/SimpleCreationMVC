
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class AppointmentsService
    {
        private readonly AppointmentsRepository _appointmentsRepository = new AppointmentsRepository();

        public async Task<Appointments> Insert(Appointments data)
        {
           return await _appointmentsRepository.Insert(data);
        }

        public async Task<Appointments> Update(Appointments data)
        {
            return await _appointmentsRepository.Update(data);
        }

        public async Task<IEnumerable<Appointments>> GetAll()
        {
            return await _appointmentsRepository.GetAll();
        }

        public async Task<Appointments> GetById(int id)
        {
            return await _appointmentsRepository.GetById(id);
        }
        public async Task<Appointments> HardDeleteById(int id)
        {
              return await  _appointmentsRepository.HardDeleteById(id);
        }
    }
}