
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefPresentAddressService
    {
        private readonly tblRefPresentAddressRepository _tblRefPresentAddressRepository = new tblRefPresentAddressRepository();

        public async Task<tblRefPresentAddress> Insert(tblRefPresentAddress data)
        {
           return await _tblRefPresentAddressRepository.Insert(data);
        }

        public async Task<tblRefPresentAddress> Update(tblRefPresentAddress data)
        {
            return await _tblRefPresentAddressRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefPresentAddress>> GetAll()
        {
            return await _tblRefPresentAddressRepository.GetAll();
        }

        public async Task<tblRefPresentAddress> GetById(int id)
        {
            return await _tblRefPresentAddressRepository.GetById(id);
        }
        public async Task<tblRefPresentAddress> DeleteById(int id)
        {
              return await  _tblRefPresentAddressRepository.DeleteById(id);
        }
    }
}