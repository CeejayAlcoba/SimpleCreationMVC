
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefEducationalLevelService
    {
        private readonly tblRefEducationalLevelRepository _tblRefEducationalLevelRepository = new tblRefEducationalLevelRepository();

        public async Task<tblRefEducationalLevel> Insert(tblRefEducationalLevel data)
        {
           return await _tblRefEducationalLevelRepository.Insert(data);
        }

        public async Task<tblRefEducationalLevel> Update(tblRefEducationalLevel data)
        {
            return await _tblRefEducationalLevelRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefEducationalLevel>> GetAll()
        {
            return await _tblRefEducationalLevelRepository.GetAll();
        }

        public async Task<tblRefEducationalLevel> GetById(int id)
        {
            return await _tblRefEducationalLevelRepository.GetById(id);
        }
        public async Task<tblRefEducationalLevel> DeleteById(int id)
        {
              return await  _tblRefEducationalLevelRepository.DeleteById(id);
        }
    }
}