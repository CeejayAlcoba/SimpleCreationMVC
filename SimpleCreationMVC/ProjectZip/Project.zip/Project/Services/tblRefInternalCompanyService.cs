
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefInternalCompanyService
    {
        private readonly tblRefInternalCompanyRepository _tblRefInternalCompanyRepository = new tblRefInternalCompanyRepository();

        public async Task<tblRefInternalCompany> Insert(tblRefInternalCompany data)
        {
           return await _tblRefInternalCompanyRepository.Insert(data);
        }

        public async Task<tblRefInternalCompany> Update(tblRefInternalCompany data)
        {
            return await _tblRefInternalCompanyRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefInternalCompany>> GetAll()
        {
            return await _tblRefInternalCompanyRepository.GetAll();
        }

        public async Task<tblRefInternalCompany> GetById(int id)
        {
            return await _tblRefInternalCompanyRepository.GetById(id);
        }
        public async Task<tblRefInternalCompany> DeleteById(int id)
        {
              return await  _tblRefInternalCompanyRepository.DeleteById(id);
        }
    }
}