
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefProvinceService
    {
        private readonly tblRefProvinceRepository _tblRefProvinceRepository = new tblRefProvinceRepository();

        public async Task<tblRefProvince> Insert(tblRefProvince data)
        {
           return await _tblRefProvinceRepository.Insert(data);
        }

        public async Task<tblRefProvince> Update(tblRefProvince data)
        {
            return await _tblRefProvinceRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefProvince>> GetAll()
        {
            return await _tblRefProvinceRepository.GetAll();
        }

        public async Task<tblRefProvince> GetById(int id)
        {
            return await _tblRefProvinceRepository.GetById(id);
        }
        public async Task<tblRefProvince> DeleteById(int id)
        {
              return await  _tblRefProvinceRepository.DeleteById(id);
        }
    }
}