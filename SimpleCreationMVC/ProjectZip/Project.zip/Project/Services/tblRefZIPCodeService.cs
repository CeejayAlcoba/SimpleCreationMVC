
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefZIPCodeService
    {
        private readonly tblRefZIPCodeRepository _tblRefZIPCodeRepository = new tblRefZIPCodeRepository();

        public async Task<tblRefZIPCode> Insert(tblRefZIPCode data)
        {
           return await _tblRefZIPCodeRepository.Insert(data);
        }

        public async Task<tblRefZIPCode> Update(tblRefZIPCode data)
        {
            return await _tblRefZIPCodeRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefZIPCode>> GetAll()
        {
            return await _tblRefZIPCodeRepository.GetAll();
        }

        public async Task<tblRefZIPCode> GetById(int id)
        {
            return await _tblRefZIPCodeRepository.GetById(id);
        }
        public async Task<tblRefZIPCode> DeleteById(int id)
        {
              return await  _tblRefZIPCodeRepository.DeleteById(id);
        }
    }
}