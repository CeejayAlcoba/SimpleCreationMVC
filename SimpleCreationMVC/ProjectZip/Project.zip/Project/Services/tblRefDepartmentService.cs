
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefDepartmentService
    {
        private readonly tblRefDepartmentRepository _tblRefDepartmentRepository = new tblRefDepartmentRepository();

        public async Task<tblRefDepartment> Insert(tblRefDepartment data)
        {
           return await _tblRefDepartmentRepository.Insert(data);
        }

        public async Task<tblRefDepartment> Update(tblRefDepartment data)
        {
            return await _tblRefDepartmentRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefDepartment>> GetAll()
        {
            return await _tblRefDepartmentRepository.GetAll();
        }

        public async Task<tblRefDepartment> GetById(int id)
        {
            return await _tblRefDepartmentRepository.GetById(id);
        }
        public async Task<tblRefDepartment> DeleteById(int id)
        {
              return await  _tblRefDepartmentRepository.DeleteById(id);
        }
    }
}