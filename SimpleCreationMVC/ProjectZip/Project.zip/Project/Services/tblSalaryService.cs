
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblSalaryService
    {
        private readonly tblSalaryRepository _tblSalaryRepository = new tblSalaryRepository();

        public async Task<tblSalary> Insert(tblSalary data)
        {
           return await _tblSalaryRepository.Insert(data);
        }

        public async Task<tblSalary> Update(tblSalary data)
        {
            return await _tblSalaryRepository.Update(data);
        }

        public async Task<IEnumerable<tblSalary>> GetAll()
        {
            return await _tblSalaryRepository.GetAll();
        }

        public async Task<tblSalary> GetById(int id)
        {
            return await _tblSalaryRepository.GetById(id);
        }
        public async Task<tblSalary> DeleteById(int id)
        {
              return await  _tblSalaryRepository.DeleteById(id);
        }
    }
}