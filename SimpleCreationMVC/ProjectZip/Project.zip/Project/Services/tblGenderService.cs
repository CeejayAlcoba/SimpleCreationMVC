
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblGenderService
    {
        private readonly tblGenderRepository _tblGenderRepository = new tblGenderRepository();

        public async Task<tblGender?> InsertAsync(tblGender data)
        {
            return await _tblGenderRepository.InsertAsync(data);
        }

        public async Task<tblGender?> UpdateAsync(tblGender data)
        {
            return await _tblGenderRepository.UpdateAsync(data);
        }

        public async Task<IEnumerable<tblGender>> GetAllAsync()
        {
            return await _tblGenderRepository.GetAllAsync();
        }

        public async Task<tblGender?> GetByIdAsync(int id)
        {
            return await _tblGenderRepository.GetByIdAsync(id);
        }

        public async Task<tblGender?> DeleteByIdAsync(int id)
        {
            return await _tblGenderRepository.DeleteByIdAsync(id);
        }
        public async Task<IEnumerable<tblGender>> BulkInsertAsync(List<tblGender> data)
        {
            return await _tblGenderRepository.BulkInsertAsync(data);
        }
        public async Task<IEnumerable<tblGender>> BulkUpdateAsync(List<tblGender> data)
        {
            return await _tblGenderRepository.BulkUpdateAsync(data);
        }
        public async Task<IEnumerable<tblGender>> BulkUpsertAsync(List<tblGender> data)
        {
            return await _tblGenderRepository.BulkUpsertAsync(data);
        }
    }
}