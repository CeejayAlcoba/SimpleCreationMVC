
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblEmployeeDataService
    {
        private readonly tblEmployeeDataRepository _tblEmployeeDataRepository = new tblEmployeeDataRepository();

        public async Task<tblEmployeeData> Insert(tblEmployeeData data)
        {
           return await _tblEmployeeDataRepository.Insert(data);
        }

        public async Task<tblEmployeeData> Update(tblEmployeeData data)
        {
            return await _tblEmployeeDataRepository.Update(data);
        }

        public async Task<IEnumerable<tblEmployeeData>> GetAll()
        {
            return await _tblEmployeeDataRepository.GetAll();
        }

        public async Task<tblEmployeeData> GetById(int id)
        {
            return await _tblEmployeeDataRepository.GetById(id);
        }
        public async Task<tblEmployeeData> DeleteById(int id)
        {
              return await  _tblEmployeeDataRepository.DeleteById(id);
        }
    }
}