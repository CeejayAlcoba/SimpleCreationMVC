
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblInternalWorkExperienceService
    {
        private readonly tblInternalWorkExperienceRepository _tblInternalWorkExperienceRepository = new tblInternalWorkExperienceRepository();

        public async Task<tblInternalWorkExperience> Insert(tblInternalWorkExperience data)
        {
           return await _tblInternalWorkExperienceRepository.Insert(data);
        }

        public async Task<tblInternalWorkExperience> Update(tblInternalWorkExperience data)
        {
            return await _tblInternalWorkExperienceRepository.Update(data);
        }

        public async Task<IEnumerable<tblInternalWorkExperience>> GetAll()
        {
            return await _tblInternalWorkExperienceRepository.GetAll();
        }

        public async Task<tblInternalWorkExperience> GetById(int id)
        {
            return await _tblInternalWorkExperienceRepository.GetById(id);
        }
        public async Task<tblInternalWorkExperience> DeleteById(int id)
        {
              return await  _tblInternalWorkExperienceRepository.DeleteById(id);
        }
    }
}