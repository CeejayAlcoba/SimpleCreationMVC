
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefBarangayService
    {
        private readonly tblRefBarangayRepository _tblRefBarangayRepository = new tblRefBarangayRepository();

        public async Task<tblRefBarangay> Insert(tblRefBarangay data)
        {
           return await _tblRefBarangayRepository.Insert(data);
        }

        public async Task<tblRefBarangay> Update(tblRefBarangay data)
        {
            return await _tblRefBarangayRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefBarangay>> GetAll()
        {
            return await _tblRefBarangayRepository.GetAll();
        }

        public async Task<tblRefBarangay> GetById(int id)
        {
            return await _tblRefBarangayRepository.GetById(id);
        }
        public async Task<tblRefBarangay> DeleteById(int id)
        {
              return await  _tblRefBarangayRepository.DeleteById(id);
        }
    }
}