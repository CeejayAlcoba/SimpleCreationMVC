
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblFamilyDataService
    {
        private readonly tblFamilyDataRepository _tblFamilyDataRepository = new tblFamilyDataRepository();

        public async Task<tblFamilyData> Insert(tblFamilyData data)
        {
           return await _tblFamilyDataRepository.Insert(data);
        }

        public async Task<tblFamilyData> Update(tblFamilyData data)
        {
            return await _tblFamilyDataRepository.Update(data);
        }

        public async Task<IEnumerable<tblFamilyData>> GetAll()
        {
            return await _tblFamilyDataRepository.GetAll();
        }

        public async Task<tblFamilyData> GetById(int id)
        {
            return await _tblFamilyDataRepository.GetById(id);
        }
        public async Task<tblFamilyData> DeleteById(int id)
        {
              return await  _tblFamilyDataRepository.DeleteById(id);
        }
    }
}