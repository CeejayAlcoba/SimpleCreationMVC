
//In Program.cs (Main project) add this 
//builder.Services.AddServices();

using Services.Interfaces;
using Services.Classes;

namespace Services
{
    public static class ServiceRegistration
    {
        public static void AddServices(this IServiceCollection services)
        {
            services.AddScoped<ItblRefReactIconFamilyService, tblRefReactIconFamilyService>();

        }
    }
}
