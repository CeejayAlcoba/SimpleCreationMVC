
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class ContractsService
    {
        private readonly ContractsRepository _contractsRepository = new ContractsRepository();

        public async Task<Contracts> Insert(Contracts data)
        {
           return await _contractsRepository.Insert(data);
        }

        public async Task<Contracts> Update(Contracts data)
        {
            return await _contractsRepository.Update(data);
        }

        public async Task<IEnumerable<Contracts>> GetAll()
        {
            return await _contractsRepository.GetAll();
        }

        public async Task<Contracts> GetById(int id)
        {
            return await _contractsRepository.GetById(id);
        }
        public async Task<Contracts> HardDeleteById(int id)
        {
              return await  _contractsRepository.HardDeleteById(id);
        }
    }
}