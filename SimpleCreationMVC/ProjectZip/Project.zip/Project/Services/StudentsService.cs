
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class StudentsService
    {
        private readonly StudentsRepository _studentsRepository = new StudentsRepository();

        public async Task<Students?> Insert(Students data)
        {
            return await _studentsRepository.Insert(data);
        }

        public async Task<Students?> Update(Students data)
        {
            return await _studentsRepository.Update(data);
        }

        public async Task<IEnumerable<Students>> GetAll()
        {
            return await _studentsRepository.GetAll();
        }

        public async Task<Students?> GetById(int id)
        {
            return await _studentsRepository.GetById(id);
        }

        public async Task<Students?> DeleteById(int id)
        {
            return await _studentsRepository.DeleteById(id);
        }
    }
}