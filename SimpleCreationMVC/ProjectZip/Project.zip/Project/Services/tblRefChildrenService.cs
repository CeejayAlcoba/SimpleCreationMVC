
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefChildrenService
    {
        private readonly tblRefChildrenRepository _tblRefChildrenRepository = new tblRefChildrenRepository();

        public async Task<tblRefChildren> Insert(tblRefChildren data)
        {
           return await _tblRefChildrenRepository.Insert(data);
        }

        public async Task<tblRefChildren> Update(tblRefChildren data)
        {
            return await _tblRefChildrenRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefChildren>> GetAll()
        {
            return await _tblRefChildrenRepository.GetAll();
        }

        public async Task<tblRefChildren> GetById(int id)
        {
            return await _tblRefChildrenRepository.GetById(id);
        }
        public async Task<tblRefChildren> DeleteById(int id)
        {
              return await  _tblRefChildrenRepository.DeleteById(id);
        }
    }
}