
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefEmploymentCategoryTypeService
    {
        private readonly tblRefEmploymentCategoryTypeRepository _tblRefEmploymentCategoryTypeRepository = new tblRefEmploymentCategoryTypeRepository();

        public async Task<tblRefEmploymentCategoryType> Insert(tblRefEmploymentCategoryType data)
        {
           return await _tblRefEmploymentCategoryTypeRepository.Insert(data);
        }

        public async Task<tblRefEmploymentCategoryType> Update(tblRefEmploymentCategoryType data)
        {
            return await _tblRefEmploymentCategoryTypeRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefEmploymentCategoryType>> GetAll()
        {
            return await _tblRefEmploymentCategoryTypeRepository.GetAll();
        }

        public async Task<tblRefEmploymentCategoryType> GetById(int id)
        {
            return await _tblRefEmploymentCategoryTypeRepository.GetById(id);
        }
        public async Task<tblRefEmploymentCategoryType> DeleteById(int id)
        {
              return await  _tblRefEmploymentCategoryTypeRepository.DeleteById(id);
        }
    }
}