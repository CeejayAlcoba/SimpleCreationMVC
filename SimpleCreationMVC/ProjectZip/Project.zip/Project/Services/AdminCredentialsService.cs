
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class AdminCredentialsService
    {
        private readonly AdminCredentialsRepository _adminCredentialsRepository = new AdminCredentialsRepository();

        public async Task<AdminCredentials?> Insert(AdminCredentials data)
        {
            return await _adminCredentialsRepository.Insert(data);
        }

        public async Task<AdminCredentials?> Update(AdminCredentials data)
        {
            return await _adminCredentialsRepository.Update(data);
        }

        public async Task<IEnumerable<AdminCredentials>> GetAll()
        {
            return await _adminCredentialsRepository.GetAll();
        }

        public async Task<AdminCredentials?> GetById(int id)
        {
            return await _adminCredentialsRepository.GetById(id);
        }

        public async Task<AdminCredentials?> DeleteById(int id)
        {
            return await _adminCredentialsRepository.DeleteById(id);
        }
        public async Task<IEnumerable<AdminCredentials>> InsertMany(List<AdminCredentials> data)
        {
            return await _adminCredentialsRepository.InsertMany(data);
        }
        public async Task<IEnumerable<AdminCredentials>> UpdateMany(List<AdminCredentials> data)
        {
            return await _adminCredentialsRepository.UpdateMany(data);
        }
    }
}