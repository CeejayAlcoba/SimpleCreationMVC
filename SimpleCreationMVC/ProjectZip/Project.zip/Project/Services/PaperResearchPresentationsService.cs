
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class PaperResearchPresentationsService
    {
        private readonly PaperResearchPresentationsRepository _paperResearchPresentationsRepository = new PaperResearchPresentationsRepository();

        public async Task<PaperResearchPresentations> Insert(PaperResearchPresentations data)
        {
           return await _paperResearchPresentationsRepository.Insert(data);
        }

        public async Task<PaperResearchPresentations> Update(PaperResearchPresentations data)
        {
            return await _paperResearchPresentationsRepository.Update(data);
        }

        public async Task<IEnumerable<PaperResearchPresentations>> GetAll()
        {
            return await _paperResearchPresentationsRepository.GetAll();
        }

        public async Task<PaperResearchPresentations> GetById(int id)
        {
            return await _paperResearchPresentationsRepository.GetById(id);
        }
        public async Task<PaperResearchPresentations> HardDeleteById(int id)
        {
              return await  _paperResearchPresentationsRepository.HardDeleteById(id);
        }
    }
}