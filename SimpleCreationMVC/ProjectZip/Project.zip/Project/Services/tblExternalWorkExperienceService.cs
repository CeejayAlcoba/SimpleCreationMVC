
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblExternalWorkExperienceService
    {
        private readonly tblExternalWorkExperienceRepository _tblExternalWorkExperienceRepository = new tblExternalWorkExperienceRepository();

        public async Task<tblExternalWorkExperience> Insert(tblExternalWorkExperience data)
        {
           return await _tblExternalWorkExperienceRepository.Insert(data);
        }

        public async Task<tblExternalWorkExperience> Update(tblExternalWorkExperience data)
        {
            return await _tblExternalWorkExperienceRepository.Update(data);
        }

        public async Task<IEnumerable<tblExternalWorkExperience>> GetAll()
        {
            return await _tblExternalWorkExperienceRepository.GetAll();
        }

        public async Task<tblExternalWorkExperience> GetById(int id)
        {
            return await _tblExternalWorkExperienceRepository.GetById(id);
        }
        public async Task<tblExternalWorkExperience> DeleteById(int id)
        {
              return await  _tblExternalWorkExperienceRepository.DeleteById(id);
        }
    }
}