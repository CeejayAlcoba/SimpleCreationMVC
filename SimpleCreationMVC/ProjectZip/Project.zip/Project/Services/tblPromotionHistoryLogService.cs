
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblPromotionHistoryLogService
    {
        private readonly tblPromotionHistoryLogRepository _tblPromotionHistoryLogRepository = new tblPromotionHistoryLogRepository();

        public async Task<tblPromotionHistoryLog> Insert(tblPromotionHistoryLog data)
        {
           return await _tblPromotionHistoryLogRepository.Insert(data);
        }

        public async Task<tblPromotionHistoryLog> Update(tblPromotionHistoryLog data)
        {
            return await _tblPromotionHistoryLogRepository.Update(data);
        }

        public async Task<IEnumerable<tblPromotionHistoryLog>> GetAll()
        {
            return await _tblPromotionHistoryLogRepository.GetAll();
        }

        public async Task<tblPromotionHistoryLog> GetById(int id)
        {
            return await _tblPromotionHistoryLogRepository.GetById(id);
        }
        public async Task<tblPromotionHistoryLog> DeleteById(int id)
        {
              return await  _tblPromotionHistoryLogRepository.DeleteById(id);
        }
    }
}