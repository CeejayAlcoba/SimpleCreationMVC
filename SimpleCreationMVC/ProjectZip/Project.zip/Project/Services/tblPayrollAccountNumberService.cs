
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblPayrollAccountNumberService
    {
        private readonly tblPayrollAccountNumberRepository _tblPayrollAccountNumberRepository = new tblPayrollAccountNumberRepository();

        public async Task<tblPayrollAccountNumber> Insert(tblPayrollAccountNumber data)
        {
           return await _tblPayrollAccountNumberRepository.Insert(data);
        }

        public async Task<tblPayrollAccountNumber> Update(tblPayrollAccountNumber data)
        {
            return await _tblPayrollAccountNumberRepository.Update(data);
        }

        public async Task<IEnumerable<tblPayrollAccountNumber>> GetAll()
        {
            return await _tblPayrollAccountNumberRepository.GetAll();
        }

        public async Task<tblPayrollAccountNumber> GetById(int id)
        {
            return await _tblPayrollAccountNumberRepository.GetById(id);
        }
        public async Task<tblPayrollAccountNumber> DeleteById(int id)
        {
              return await  _tblPayrollAccountNumberRepository.DeleteById(id);
        }
    }
}