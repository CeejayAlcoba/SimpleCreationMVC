
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefMunicipalityService
    {
        private readonly tblRefMunicipalityRepository _tblRefMunicipalityRepository = new tblRefMunicipalityRepository();

        public async Task<tblRefMunicipality> Insert(tblRefMunicipality data)
        {
           return await _tblRefMunicipalityRepository.Insert(data);
        }

        public async Task<tblRefMunicipality> Update(tblRefMunicipality data)
        {
            return await _tblRefMunicipalityRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefMunicipality>> GetAll()
        {
            return await _tblRefMunicipalityRepository.GetAll();
        }

        public async Task<tblRefMunicipality> GetById(int id)
        {
            return await _tblRefMunicipalityRepository.GetById(id);
        }
        public async Task<tblRefMunicipality> DeleteById(int id)
        {
              return await  _tblRefMunicipalityRepository.DeleteById(id);
        }
    }
}