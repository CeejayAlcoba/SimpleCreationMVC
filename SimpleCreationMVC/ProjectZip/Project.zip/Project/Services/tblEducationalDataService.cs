
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblEducationalDataService
    {
        private readonly tblEducationalDataRepository _tblEducationalDataRepository = new tblEducationalDataRepository();

        public async Task<tblEducationalData> Insert(tblEducationalData data)
        {
           return await _tblEducationalDataRepository.Insert(data);
        }

        public async Task<tblEducationalData> Update(tblEducationalData data)
        {
            return await _tblEducationalDataRepository.Update(data);
        }

        public async Task<IEnumerable<tblEducationalData>> GetAll()
        {
            return await _tblEducationalDataRepository.GetAll();
        }

        public async Task<tblEducationalData> GetById(int id)
        {
            return await _tblEducationalDataRepository.GetById(id);
        }
        public async Task<tblEducationalData> DeleteById(int id)
        {
              return await  _tblEducationalDataRepository.DeleteById(id);
        }
    }
}