
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblApplicantDataService
    {
        private readonly tblApplicantDataRepository _tblApplicantDataRepository = new tblApplicantDataRepository();

        public async Task<tblApplicantData> Insert(tblApplicantData data)
        {
           return await _tblApplicantDataRepository.Insert(data);
        }

        public async Task<tblApplicantData> Update(tblApplicantData data)
        {
            return await _tblApplicantDataRepository.Update(data);
        }

        public async Task<IEnumerable<tblApplicantData>> GetAll()
        {
            return await _tblApplicantDataRepository.GetAll();
        }

        public async Task<tblApplicantData> GetById(int id)
        {
            return await _tblApplicantDataRepository.GetById(id);
        }
        public async Task<tblApplicantData> DeleteById(int id)
        {
              return await  _tblApplicantDataRepository.DeleteById(id);
        }
    }
}