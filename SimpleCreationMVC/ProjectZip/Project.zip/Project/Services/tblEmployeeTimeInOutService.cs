
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblEmployeeTimeInOutService
    {
        private readonly tblEmployeeTimeInOutRepository _tblEmployeeTimeInOutRepository = new tblEmployeeTimeInOutRepository();

        public async Task<tblEmployeeTimeInOut?> Insert(tblEmployeeTimeInOut data)
        {
            return await _tblEmployeeTimeInOutRepository.Insert(data);
        }

        public async Task<tblEmployeeTimeInOut?> Update(tblEmployeeTimeInOut data)
        {
            return await _tblEmployeeTimeInOutRepository.Update(data);
        }

        public async Task<IEnumerable<tblEmployeeTimeInOut>> GetAll()
        {
            return await _tblEmployeeTimeInOutRepository.GetAll();
        }

        public async Task<tblEmployeeTimeInOut?> GetById(int id)
        {
            return await _tblEmployeeTimeInOutRepository.GetById(id);
        }

        public async Task<tblEmployeeTimeInOut?> DeleteById(int id)
        {
            return await _tblEmployeeTimeInOutRepository.DeleteById(id);
        }
    }
}