using Models;
using Repositories.Interfaces;
using Services.Interfaces;
using Models.Pagination;
using System.Linq.Expressions;

namespace Services.Classes
{
    public class InitialDBService : IInitialDBService
    {
        private readonly IInitialDBRepository _initialDBRepository;

        public InitialDBService(IInitialDBRepository initialDBRepository)
        {
            _initialDBRepository = initialDBRepository;
        }

        public async Task<InitialDB?> InsertAsync(InitialDB data)
        {
            return await _initialDBRepository.InsertAsync(data);
        }

        public async Task<InitialDB?> UpdateAsync(InitialDB data)
        {
            return await _initialDBRepository.UpdateAsync(data);
        }
        public async Task<PagedResult<InitialDB>> GetAllAsync(int pageNumber = 1, int pageSize = 10, InitialDB? filter = null, Expression<Func<InitialDB, object>>? orderByProperty = null, bool isDescending = false, params Expression<Func<InitialDB, object>>[] includes)
        {
            return await _initialDBRepository.GetAllAsync(pageNumber, pageSize, filter, orderByProperty, isDescending, includes);
        }

        public async Task<InitialDB?> GetByIdAsync(int id)
        {
            return await _initialDBRepository.GetByIdAsync(id);
        }

        public async Task<InitialDB?> DeleteByIdAsync(int id)
        {
            return await _initialDBRepository.DeleteByIdAsync(id);
        }
        public async Task<IEnumerable<InitialDB>> BulkInsertAsync(List<InitialDB> data)
        {
            return await _initialDBRepository.BulkInsertAsync(data);
        }
        public async Task<IEnumerable<InitialDB>> BulkUpdateAsync(List<InitialDB> data)
        {
            return await _initialDBRepository.BulkUpdateAsync(data);
        }
        public async Task<IEnumerable<InitialDB>> BulkUpsertAsync(List<InitialDB> data)
        {
            return await _initialDBRepository.BulkUpsertAsync(data);
        }
        public async Task<IEnumerable<InitialDB>> BulkMergeAsync(List<InitialDB> data)
        {
            return await _initialDBRepository.BulkMergeAsync(data);
        }
    }
}