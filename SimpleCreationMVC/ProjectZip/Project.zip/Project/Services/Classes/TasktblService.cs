
using Models;
using Repositories.Interfaces;
using Services.Interfaces;

namespace Services.Classes
{
    public class TasktblService : ITasktblService
    {
        private readonly ITasktblRepository _tasktblRepository;

        public TasktblService(ITasktblRepository tasktblRepository)
        {
            _tasktblRepository = tasktblRepository;
        }

        public async Task<Tasktbl?> InsertAsync(Tasktbl data)
        {
            return await _tasktblRepository.InsertAsync(data);
        }

        public async Task<Tasktbl?> UpdateAsync(Tasktbl data)
        {
            return await _tasktblRepository.UpdateAsync(data);
        }

        public async Task<IEnumerable<Tasktbl>> GetAllAsync(Tasktbl? filter)
        {
            return await _tasktblRepository.GetAllAsync(filter);
        }

        public async Task<Tasktbl?> GetByIdAsync(int id)
        {
            return await _tasktblRepository.GetByIdAsync(id);
        }

        public async Task<Tasktbl?> DeleteByIdAsync(int id)
        {
            return await _tasktblRepository.DeleteByIdAsync(id);
        }
        public async Task<IEnumerable<Tasktbl>> BulkInsertAsync(List<Tasktbl> data)
        {
            return await _tasktblRepository.BulkInsertAsync(data);
        }
        public async Task<IEnumerable<Tasktbl>> BulkUpdateAsync(List<Tasktbl> data)
        {
            return await _tasktblRepository.BulkUpdateAsync(data);
        }
        public async Task<IEnumerable<Tasktbl>> BulkUpsertAsync(List<Tasktbl> data)
        {
            return await _tasktblRepository.BulkUpsertAsync(data);
        }
        public async Task<IEnumerable<Tasktbl>> BulkMergeAsync(List<Tasktbl> data)
        {
            return await _tasktblRepository.BulkMergeAsync(data);
        }
    }
}