using Models;
using Repositories.Interfaces;
using Services.Interfaces;
using Models.Pagination;

namespace Services.Classes
{
    public class CoyService : ICoyService
    {
        private readonly ICoyRepository _coyRepository;

        public CoyService(ICoyRepository coyRepository)
        {
            _coyRepository = coyRepository;
        }

        public async Task<Coy?> InsertAsync(Coy data)
        {
            return await _coyRepository.InsertAsync(data);
        }

        public async Task<Coy?> UpdateAsync(Coy data)
        {
            return await _coyRepository.UpdateAsync(data);
        }
        public async Task<PagedResult<Coy>> GetAllAsync(int pageNumber = 1, int pageSize = 10, Coy? filter = null)
        {
            return await _coyRepository.GetAllAsync(pageNumber, pageSize, filter);
        }

        public async Task<Coy?> GetByIdAsync(int id)
        {
            return await _coyRepository.GetByIdAsync(id);
        }

        public async Task<Coy?> DeleteByIdAsync(int id)
        {
            return await _coyRepository.DeleteByIdAsync(id);
        }
        public async Task<IEnumerable<Coy>> BulkInsertAsync(List<Coy> data)
        {
            return await _coyRepository.BulkInsertAsync(data);
        }
        public async Task<IEnumerable<Coy>> BulkUpdateAsync(List<Coy> data)
        {
            return await _coyRepository.BulkUpdateAsync(data);
        }
        public async Task<IEnumerable<Coy>> BulkUpsertAsync(List<Coy> data)
        {
            return await _coyRepository.BulkUpsertAsync(data);
        }
        public async Task<IEnumerable<Coy>> BulkMergeAsync(List<Coy> data)
        {
            return await _coyRepository.BulkMergeAsync(data);
        }
    }
}