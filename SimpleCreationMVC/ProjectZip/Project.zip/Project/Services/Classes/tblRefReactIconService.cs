
using Models;
using Repositories.Interfaces;
using Services.Interfaces;

namespace Services.Classes
{
    public class tblRefReactIconService : ItblRefReactIconService
    {
        private readonly ItblRefReactIconRepository _tblRefReactIconRepository;

        public tblRefReactIconService(ItblRefReactIconRepository tblRefReactIconRepository)
        {
            _tblRefReactIconRepository = tblRefReactIconRepository;
        }

        public async Task<tblRefReactIcon?> InsertAsync(tblRefReactIcon data)
        {
            return await _tblRefReactIconRepository.InsertAsync(data);
        }

        public async Task<tblRefReactIcon?> UpdateAsync(tblRefReactIcon data)
        {
            return await _tblRefReactIconRepository.UpdateAsync(data);
        }

        public async Task<IEnumerable<tblRefReactIcon>> GetAllAsync(tblRefReactIcon? filter)
        {
            return await _tblRefReactIconRepository.GetAllAsync(filter);
        }

        public async Task<tblRefReactIcon?> GetByIdAsync(int id)
        {
            return await _tblRefReactIconRepository.GetByIdAsync(id);
        }

        public async Task<tblRefReactIcon?> DeleteByIdAsync(int id)
        {
            return await _tblRefReactIconRepository.DeleteByIdAsync(id);
        }
        public async Task<IEnumerable<tblRefReactIcon>> BulkInsertAsync(List<tblRefReactIcon> data)
        {
            return await _tblRefReactIconRepository.BulkInsertAsync(data);
        }
        public async Task<IEnumerable<tblRefReactIcon>> BulkUpdateAsync(List<tblRefReactIcon> data)
        {
            return await _tblRefReactIconRepository.BulkUpdateAsync(data);
        }
        public async Task<IEnumerable<tblRefReactIcon>> BulkUpsertAsync(List<tblRefReactIcon> data)
        {
            return await _tblRefReactIconRepository.BulkUpsertAsync(data);
        }
        public async Task<IEnumerable<tblRefReactIcon>> BulkMergeAsync(List<tblRefReactIcon> data)
        {
            return await _tblRefReactIconRepository.BulkMergeAsync(data);
        }
    }
}