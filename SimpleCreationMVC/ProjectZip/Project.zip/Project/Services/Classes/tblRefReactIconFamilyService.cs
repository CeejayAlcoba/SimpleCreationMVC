
using Models;
using Repositories.Interfaces;
using Services.Interfaces;

namespace Services.Classes
{
    public class tblRefReactIconFamilyService : ItblRefReactIconFamilyService
    {
        private readonly ItblRefReactIconFamilyRepository _tblRefReactIconFamilyRepository;

        public tblRefReactIconFamilyService(ItblRefReactIconFamilyRepository tblRefReactIconFamilyRepository)
        {
            _tblRefReactIconFamilyRepository = tblRefReactIconFamilyRepository;
        }

        public async Task<tblRefReactIconFamily?> InsertAsync(tblRefReactIconFamily data)
        {
            return await _tblRefReactIconFamilyRepository.InsertAsync(data);
        }

        public async Task<tblRefReactIconFamily?> UpdateAsync(tblRefReactIconFamily data)
        {
            return await _tblRefReactIconFamilyRepository.UpdateAsync(data);
        }

        public async Task<IEnumerable<tblRefReactIconFamily>> GetAllAsync(tblRefReactIconFamily? filter)
        {
            return await _tblRefReactIconFamilyRepository.GetAllAsync(filter);
        }

        public async Task<tblRefReactIconFamily?> GetByIdAsync(int id)
        {
            return await _tblRefReactIconFamilyRepository.GetByIdAsync(id);
        }

        public async Task<tblRefReactIconFamily?> DeleteByIdAsync(int id)
        {
            return await _tblRefReactIconFamilyRepository.DeleteByIdAsync(id);
        }
        public async Task<IEnumerable<tblRefReactIconFamily>> BulkInsertAsync(List<tblRefReactIconFamily> data)
        {
            return await _tblRefReactIconFamilyRepository.BulkInsertAsync(data);
        }
        public async Task<IEnumerable<tblRefReactIconFamily>> BulkUpdateAsync(List<tblRefReactIconFamily> data)
        {
            return await _tblRefReactIconFamilyRepository.BulkUpdateAsync(data);
        }
        public async Task<IEnumerable<tblRefReactIconFamily>> BulkUpsertAsync(List<tblRefReactIconFamily> data)
        {
            return await _tblRefReactIconFamilyRepository.BulkUpsertAsync(data);
        }
        public async Task<IEnumerable<tblRefReactIconFamily>> BulkMergeAsync(List<tblRefReactIconFamily> data)
        {
            return await _tblRefReactIconFamilyRepository.BulkMergeAsync(data);
        }
    }
}