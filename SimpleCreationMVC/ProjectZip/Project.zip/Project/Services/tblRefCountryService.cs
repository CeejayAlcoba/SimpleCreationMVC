
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblRefCountryService
    {
        private readonly tblRefCountryRepository _tblRefCountryRepository = new tblRefCountryRepository();

        public async Task<tblRefCountry> Insert(tblRefCountry data)
        {
           return await _tblRefCountryRepository.Insert(data);
        }

        public async Task<tblRefCountry> Update(tblRefCountry data)
        {
            return await _tblRefCountryRepository.Update(data);
        }

        public async Task<IEnumerable<tblRefCountry>> GetAll()
        {
            return await _tblRefCountryRepository.GetAll();
        }

        public async Task<tblRefCountry> GetById(int id)
        {
            return await _tblRefCountryRepository.GetById(id);
        }
        public async Task<tblRefCountry> DeleteById(int id)
        {
              return await  _tblRefCountryRepository.DeleteById(id);
        }
    }
}