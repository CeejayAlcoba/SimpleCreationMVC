
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class ExternalWorkExperiencesService
    {
        private readonly ExternalWorkExperiencesRepository _externalWorkExperiencesRepository = new ExternalWorkExperiencesRepository();

        public async Task<ExternalWorkExperiences> Insert(ExternalWorkExperiences data)
        {
           return await _externalWorkExperiencesRepository.Insert(data);
        }

        public async Task<ExternalWorkExperiences> Update(ExternalWorkExperiences data)
        {
            return await _externalWorkExperiencesRepository.Update(data);
        }

        public async Task<IEnumerable<ExternalWorkExperiences>> GetAll()
        {
            return await _externalWorkExperiencesRepository.GetAll();
        }

        public async Task<ExternalWorkExperiences> GetById(int id)
        {
            return await _externalWorkExperiencesRepository.GetById(id);
        }
        public async Task<ExternalWorkExperiences> HardDeleteById(int id)
        {
              return await  _externalWorkExperiencesRepository.HardDeleteById(id);
        }
    }
}