
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class CorporateDatasService
    {
        private readonly CorporateDatasRepository _corporateDatasRepository = new CorporateDatasRepository();

        public async Task<CorporateDatas> Insert(CorporateDatas data)
        {
           return await _corporateDatasRepository.Insert(data);
        }

        public async Task<CorporateDatas> Update(CorporateDatas data)
        {
            return await _corporateDatasRepository.Update(data);
        }

        public async Task<IEnumerable<CorporateDatas>> GetAll()
        {
            return await _corporateDatasRepository.GetAll();
        }

        public async Task<CorporateDatas> GetById(int id)
        {
            return await _corporateDatasRepository.GetById(id);
        }
        public async Task<CorporateDatas> HardDeleteById(int id)
        {
              return await  _corporateDatasRepository.HardDeleteById(id);
        }
    }
}