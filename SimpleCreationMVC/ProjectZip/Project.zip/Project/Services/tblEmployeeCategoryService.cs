
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class tblEmployeeCategoryService
    {
        private readonly tblEmployeeCategoryRepository _tblEmployeeCategoryRepository = new tblEmployeeCategoryRepository();

        public async Task<tblEmployeeCategory> Insert(tblEmployeeCategory data)
        {
           return await _tblEmployeeCategoryRepository.Insert(data);
        }

        public async Task<tblEmployeeCategory> Update(tblEmployeeCategory data)
        {
            return await _tblEmployeeCategoryRepository.Update(data);
        }

        public async Task<IEnumerable<tblEmployeeCategory>> GetAll()
        {
            return await _tblEmployeeCategoryRepository.GetAll();
        }

        public async Task<tblEmployeeCategory> GetById(int id)
        {
            return await _tblEmployeeCategoryRepository.GetById(id);
        }
        public async Task<tblEmployeeCategory> DeleteById(int id)
        {
              return await  _tblEmployeeCategoryRepository.DeleteById(id);
        }
    }
}