
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class AttendancesService
    {
        private readonly AttendancesRepository _attendancesRepository = new AttendancesRepository();

        public async Task<Attendances?> Insert(Attendances data)
        {
            return await _attendancesRepository.Insert(data);
        }

        public async Task<Attendances?> Update(Attendances data)
        {
            return await _attendancesRepository.Update(data);
        }

        public async Task<IEnumerable<Attendances>> GetAll()
        {
            return await _attendancesRepository.GetAll();
        }

        public async Task<Attendances?> GetById(int id)
        {
            return await _attendancesRepository.GetById(id);
        }

        public async Task<Attendances?> DeleteById(int id)
        {
            return await _attendancesRepository.DeleteById(id);
        }
        public async Task<IEnumerable<Attendances>> InsertMany(List<Attendances> data)
        {
            return await _attendancesRepository.InsertMany(data);
        }
        public async Task<IEnumerable<Attendances>> UpdateMany(List<Attendances> data)
        {
            return await _attendancesRepository.UpdateMany(data);
        }
    }
}