
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class UsersService
    {
        private readonly UsersRepository _usersRepository = new UsersRepository();

        public async Task<Users> Insert(Users data)
        {
           return await _usersRepository.Insert(data);
        }

        public async Task<Users> Update(Users data)
        {
            return await _usersRepository.Update(data);
        }

        public async Task<IEnumerable<Users>> GetAll()
        {
            return await _usersRepository.GetAll();
        }

        public async Task<Users> GetById(int id)
        {
            return await _usersRepository.GetById(id);
        }
        public async Task<Users> HardDeleteById(int id)
        {
              return await  _usersRepository.HardDeleteById(id);
        }
    }
}