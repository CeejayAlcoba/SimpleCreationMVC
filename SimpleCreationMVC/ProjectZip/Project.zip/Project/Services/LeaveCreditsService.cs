
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class LeaveCreditsService
    {
        private readonly LeaveCreditsRepository _leaveCreditsRepository = new LeaveCreditsRepository();

        public async Task<LeaveCredits> Insert(LeaveCredits data)
        {
           return await _leaveCreditsRepository.Insert(data);
        }

        public async Task<LeaveCredits> Update(LeaveCredits data)
        {
            return await _leaveCreditsRepository.Update(data);
        }

        public async Task<IEnumerable<LeaveCredits>> GetAll()
        {
            return await _leaveCreditsRepository.GetAll();
        }

        public async Task<LeaveCredits> GetById(int id)
        {
            return await _leaveCreditsRepository.GetById(id);
        }
        public async Task<LeaveCredits> HardDeleteById(int id)
        {
              return await  _leaveCreditsRepository.HardDeleteById(id);
        }
    }
}