
using Project.Models;
using Project.Repositories;

namespace Project.Services
{
    public class FamilyDatasService
    {
        private readonly FamilyDatasRepository _familyDatasRepository = new FamilyDatasRepository();

        public async Task<FamilyDatas> Insert(FamilyDatas data)
        {
           return await _familyDatasRepository.Insert(data);
        }

        public async Task<FamilyDatas> Update(FamilyDatas data)
        {
            return await _familyDatasRepository.Update(data);
        }

        public async Task<IEnumerable<FamilyDatas>> GetAll()
        {
            return await _familyDatasRepository.GetAll();
        }

        public async Task<FamilyDatas> GetById(int id)
        {
            return await _familyDatasRepository.GetById(id);
        }
        public async Task<FamilyDatas> HardDeleteById(int id)
        {
              return await  _familyDatasRepository.HardDeleteById(id);
        }
    }
}