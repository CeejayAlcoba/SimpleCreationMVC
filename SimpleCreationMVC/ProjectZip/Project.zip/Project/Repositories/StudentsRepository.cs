
using Dapper;
using Microsoft.Data.SqlClient;
using Project.Models;
using Project.ProcedureEnums;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Project.Repositories
{
    public class StudentsRepository : GenericRepository<Students, StudentsProcedures>
    {
        // New Get All
        public async Task<IEnumerable<Students>> GetAll()
        {
            return await GetAll(StudentsProcedures.Students_GetAll);
        }

        // New Get By ID
        public async Task<Students?> GetById(int id)
        {
            return await GetById(StudentsProcedures.Students_GetById, id);
        }

        // New Insert
        public async Task<Students?> Insert(Students entity)
        {
            return await Insert(StudentsProcedures.Students_Insert, entity);
        }

        // New Update
        public async Task<Students?> Update(Students entity)
        {
            return await Update(StudentsProcedures.Students_Update, entity);
        }

        // New Delete By ID
        public async Task<Students?> DeleteById(int id)
        {
             var data = await GetById(id);
             await DeleteById(StudentsProcedures.Students_DeleteById, id);
             return data;
        }
    }
}