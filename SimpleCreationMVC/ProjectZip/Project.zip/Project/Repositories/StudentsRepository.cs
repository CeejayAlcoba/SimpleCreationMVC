
using Project.Models;
using Project.ProcedureEnums;

namespace Project.Repositories
{
    public class StudentsRepository : GenericRepository<Students, StudentsProcedures>
    {
        private static GenericProcedure<StudentsProcedures> procedures = new GenericProcedure<StudentsProcedures>
        {
            GetAll = StudentsProcedures.Students_GetAll,
            GetById = StudentsProcedures.Students_GetById,
            Insert = StudentsProcedures.Students_Insert,
            Update = StudentsProcedures.Students_Update,
            InsertMany = StudentsProcedures.Students_InsertMany,
            UpdateMany = StudentsProcedures.Students_UpdateMany,
        };
        public StudentsRepository() : base(procedures)
        {
        }
    }
}