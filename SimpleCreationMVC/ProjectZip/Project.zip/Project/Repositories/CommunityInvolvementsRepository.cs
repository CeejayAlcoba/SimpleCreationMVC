
using Project.Models;

namespace Project.Repositories
{
    public class CommunityInvolvementsRepository : GenericRepository<CommunityInvolvements>
    {

    }
}
