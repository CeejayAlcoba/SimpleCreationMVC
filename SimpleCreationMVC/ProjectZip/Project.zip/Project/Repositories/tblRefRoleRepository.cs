
using Project.Models;
using Project.ProcedureEnums;

namespace Project.Repositories
{
    public class tblRefRoleRepository : GenericRepository<tblRefRole, tblRefRoleProcedures>
    {
        private static GenericProcedure<tblRefRoleProcedures> procedures = new GenericProcedure<tblRefRoleProcedures>
        {
            GetAll = tblRefRoleProcedures.tblRefRole_GetAll,
            GetById = tblRefRoleProcedures.tblRefRole_GetById,
            Insert = tblRefRoleProcedures.tblRefRole_Insert,
            Update = tblRefRoleProcedures.tblRefRole_Update,
            InsertMany = tblRefRoleProcedures.tblRefRole_InsertMany,
            UpdateMany = tblRefRoleProcedures.tblRefRole_UpdateMany,
        };
        public tblRefRoleRepository() : base(procedures)
        {
        }
    }
}