
using Dapper;
using Microsoft.Data.SqlClient;
using Project.Enums;
using System.Data;
namespace Project.Repositories
{
    public class GenericRepository<T>
    {
        public IDbConnection _connection;
         private readonly string connectionString = "Server=DESKTOP-9PGJDKR\\SQLEXPRESS; Database=HRIS_2; User Id=admin; Password=admin; Encrypt=True; TrustServerCertificate=True; MultipleActiveResultSets=True;";

       public GenericRepository()
        {
          _connection = new SqlConnection(connectionString);
        }

        private readonly int _commandTimeout = 120;
        private string ProcedureName (ProcedureTypes procedureType) {
            string tableName = typeof(T).Name;
            return $"{tableName}_{procedureType.ToString()}"; 
        }
        public virtual async Task<IEnumerable<T>> GetAll()
        {
            var procedureName = ProcedureName(ProcedureTypes.GetAll);
            var result = await _connection.QueryAsync<T>(procedureName, commandTimeout: _commandTimeout,
            commandType: CommandType.StoredProcedure);

            return result.ToList();
        }

        public virtual async Task<T> GetById(int id)
        {
            var procedureName = ProcedureName(ProcedureTypes.GetById);
            return await _connection.QueryFirstOrDefaultAsync<T>
                  (procedureName.ToString(), new { Id=id}, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }
        public virtual async Task<T> Insert(T parameters)
        {
            var procedureName = ProcedureName(ProcedureTypes.Insert);
            return await _connection.QueryFirstOrDefaultAsync<T>
                  (procedureName.ToString(), parameters, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }
        public virtual async Task<T> Update(T parameters)
        {
            var procedureName = ProcedureName(ProcedureTypes.Update);
            return await _connection.QueryFirstOrDefaultAsync<T>
                  (procedureName.ToString(), parameters, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
           
        }
        public virtual async Task<T> DeleteById(int id)
        {
            var deletedData = await GetById(id);
            var procedureName = ProcedureName(ProcedureTypes.DeleteById);
            _connection.Execute(procedureName.ToString(), new {Id=id }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
            return deletedData;
        }
    }
}