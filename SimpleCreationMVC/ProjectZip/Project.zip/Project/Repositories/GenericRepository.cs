
using Dapper;
using Microsoft.Data.SqlClient;
using Project.Models;
using Project.ProcedureEnums;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Project.Repositories
{
    public class GenericRepository<T,TProcedures>
        where T : class
        where TProcedures : struct, Enum
    {
        public readonly IDbConnection _connection;
        public readonly int _commandTimeout = 120;

        public GenericRepository()
        {
            _connection = new SqlConnection("Server=DESKTOP-CEEJAY\\SQLEXPRESS; Database=HumanResourceInformationSystem; User Id=admin; Password=admin; Encrypt=True; TrustServerCertificate=True; MultipleActiveResultSets=True;");
        }

        // Get All
        public async Task<IEnumerable<T>> GetAll(TProcedures procedureName)
        {
            return await _connection.QueryAsync<T>(procedureName.ToString(), commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        // Get By ID
        public async Task<T?> GetById(TProcedures procedureName,int id)
        {
            return await _connection.QueryFirstOrDefaultAsync<T>(procedureName.ToString(), new { Id = id }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        // Insert
        public async Task<T?> Insert(TProcedures procedureName,T entity)
        {
            return await _connection.QueryFirstOrDefaultAsync<T>(procedureName.ToString(), entity, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        // Update
        public async Task<T?> Update(TProcedures procedureName,T entity)
        {
            return await _connection.QueryFirstOrDefaultAsync<T>(procedureName.ToString(), entity, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        // Delete By ID
        public async Task DeleteById(TProcedures procedureName,int id)
        {
            await _connection.ExecuteAsync(procedureName.ToString(), new { Id = id }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }
    }
}