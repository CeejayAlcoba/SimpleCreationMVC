
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Reflection;
using System.Text;
using Dapper;
using Microsoft.Data.SqlClient;

namespace Project.Repositories
{
    public class GenericRepository<T> where T : class
    {
        IDbConnection _connection;

          private readonly string connectionString = "Server=db6608.public.databaseasp.net; Database=db6608; User Id=db6608; Password=A=i65fB@?G8b; Encrypt=True; TrustServerCertificate=True; MultipleActiveResultSets=True; Encrypt=false";

        public GenericRepository()
        {
            _connection = new SqlConnection(connectionString);
        }

        public async Task<T> Insert(T entity)
        {
            string keyColumn = GetKeyColumnName();
            string tableName = GetTableName();
            string columns = GetColumns(excludeKey: true);
            string properties = GetPropertyNames(excludeKey: true);
            string query = $@"INSERT INTO {tableName} ({columns}) VALUES ({properties})
                              SELECT * FROM {tableName} WHERE {keyColumn} = SCOPE_IDENTITY()";
            return await _connection.QueryFirstOrDefaultAsync<T>(query, entity);

        }

        public async Task<T> HardDeleteById(int id)
        {
            string tableName = GetTableName();
            string keyColumn = GetKeyColumnName();
            var deletedData = await GetById(id);
            string query = $@"DELETE FROM {tableName} WHERE {keyColumn} = @Id;";
            
            _connection.Execute(query, new { Id = id });
            return deletedData;
        }

        public async Task<IEnumerable<T>> GetAll()
        {
            string tableName = GetTableName();
            string query = $"SELECT * FROM {tableName}";
            return await _connection.QueryAsync<T>(query);
        }

        public async Task<T> GetById(int Id)
        {
            string tableName = GetTableName();
            string keyColumn = GetKeyColumnName();
            string query = $"SELECT * FROM {tableName} WHERE {keyColumn} = '{Id}'";
            return await _connection.QueryFirstOrDefaultAsync<T>(query);
        }

        public async Task<T> Update(T entity)
        {

            string tableName = GetTableName();
            string keyColumn = GetKeyColumnName();
            string keyProperty = GetKeyPropertyName();

            StringBuilder query = new StringBuilder();
            query.AppendLine($"UPDATE {tableName} SET ");

            var properties = GetProperties(true);
            for (int a = 0; a < properties.Count(); a++) {
                string propertyName = properties[a].Name;
                string comma = a < properties.Count() - 1 ? "," : "";
                query.AppendLine($"{propertyName} = @{propertyName} {comma} "); 
            }
            query.Remove(query.Length - 1, 1);

            query.AppendLine("WHERE {keyColumn} = @{keyProperty} SELECT * FROM {tableName} WHERE {keyColumn} = @{keyProperty}");

            return await _connection.QueryFirstOrDefaultAsync<T>(query.ToString(), entity);
        }

        private string GetTableName()
        {
            string tableName = "";
            var type = typeof(T);
            var tableAttr = type.GetCustomAttribute<TableAttribute>();
            if (tableAttr != null)
            {
                tableName = tableAttr.Name;
                return tableName;
            }

            return type.Name;
        }

        public static string GetKeyColumnName()
        {
            PropertyInfo[] properties = typeof(T).GetProperties();

            foreach (PropertyInfo property in properties)
            {
                object[] keyAttributes = property.GetCustomAttributes(typeof(KeyAttribute), true);

                if (keyAttributes != null && keyAttributes.Length > 0)
                {
                    object[] columnAttributes = property.GetCustomAttributes(typeof(ColumnAttribute), true);

                    if (columnAttributes != null && columnAttributes.Length > 0)
                    {
                        ColumnAttribute columnAttribute = (ColumnAttribute)columnAttributes[0];
                        return columnAttribute.Name;
                    }
                    else
                    {
                        return property.Name;
                    }
                }
            }

            return null;
        }


        private string GetColumns(bool excludeKey = false)
        {
            var type = typeof(T);
            var columns = string.Join(", ", type.GetProperties()
                .Where(p => !excludeKey || !p.IsDefined(typeof(KeyAttribute)))
                .Select(p =>
                {
                    var columnAttr = p.GetCustomAttribute<ColumnAttribute>();
                    return columnAttr != null ? columnAttr.Name : p.Name;
                }));

            return columns;
        }

        protected string GetPropertyNames(bool excludeKey = false)
        {
            var properties = typeof(T).GetProperties()
                .Where(p => !excludeKey || p.GetCustomAttribute<KeyAttribute>() == null);

            var values = string.Join(", ", properties.Select(p =>
            {
                return $"@{p.Name}";
            }));

            return values;
        }

        protected List<PropertyInfo> GetProperties(bool excludeKey = false)
        {
            var properties = typeof(T).GetProperties()
                .Where(p => !excludeKey || p.GetCustomAttribute<KeyAttribute>() == null);

            return properties.ToList();
        }

        protected string GetKeyPropertyName()
        {
            var properties = typeof(T).GetProperties()
                .Where(p => p.GetCustomAttribute<KeyAttribute>() != null);

            if (properties.Any())
            {
                return properties.FirstOrDefault().Name;
            }

            return null;
        }
    }
}