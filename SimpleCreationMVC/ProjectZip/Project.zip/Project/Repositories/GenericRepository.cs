
using Microsoft.EntityFrameworkCore;
using Project.ApplicationContexts;
using System.ComponentModel.DataAnnotations;

namespace Project.Repositories
{
    public class GenericRepository<T> where T : class
    {
        private readonly ApplicationContext _context = new ApplicationContext();

        public virtual async Task<T> Insert(T entity)
        {
            await _context.Set<T>().AddAsync(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public virtual async Task<IEnumerable<T>> GetAllAsync()
        {
            return await _context.Set<T>().ToListAsync();
        }

        public virtual async Task<T> GetById(int id)
        {
            return await _context.Set<T>().FindAsync(id);
        }

        public virtual async Task<T> UpdateAsync(T entity)
        {
            var keyValue = GetKeyValueAsInt(entity);
            var retrievedEntity = await GetById(keyValue.Value);
            var updateData = UpdateEntityProperties(retrievedEntity, entity);
            await _context.SaveChangesAsync();
            return updateData;
        }
        public virtual async Task<T> DeleteByIdAsync(int id)
        {
            var deletedData = await GetById(id);
            _context.Set<T>().Remove(deletedData);
            await _context.SaveChangesAsync();
            return deletedData;
        }
        public virtual async Task<IEnumerable<T>> BulkUpdateAsync(List<T> list)
        {
            await _context.BulkUpdateAsync(list);
            await _context.SaveChangesAsync();
            return list;
        }
        public virtual async Task<IEnumerable<T>> BulkUpsertAsync(List<T> list)
        {
            await _context.BulkInsertOrUpdateAsync(list);
            await _context.SaveChangesAsync();
            return list;
        }
        public virtual async Task<IEnumerable<T>> BulkInsertAsync(List<T> list)
        {
            await _context.BulkInsertAsync(list);
            await _context.SaveChangesAsync();
            return list;
        }
        private int? GetKeyValueAsInt(T entity)
        {
            var entityType = typeof(T);
            var keyProperty = entityType.GetProperties()
                .FirstOrDefault(prop => Attribute.IsDefined(prop, typeof(KeyAttribute)));

            if (keyProperty == null)
            {
                throw new InvalidOperationException("No Key attribute found on properties.");
            }

            var keyValue = keyProperty.GetValue(entity);

            if (keyValue is int intValue)
            {
                return intValue;
            }

            throw new InvalidOperationException("Key value is not of type int.");
        }


        private T UpdateEntityProperties(T oldEntity, T newEntity)
        {
            var entityType = typeof(T);

            foreach (var property in entityType.GetProperties())
            {
                if (property.CanWrite && !Attribute.IsDefined(property, typeof(KeyAttribute)))
                {
                    var newValue = property.GetValue(newEntity);
                    property.SetValue(oldEntity, newValue);
                }
            }
            return newEntity;

        }

    }
}