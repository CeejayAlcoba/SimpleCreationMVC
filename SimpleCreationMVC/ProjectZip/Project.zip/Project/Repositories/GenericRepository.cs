
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Reflection;
using System.Text;
using Dapper;
using Microsoft.Data.SqlClient;

namespace Project.Repositories
{
    public class GenericRepository<T> where T : class
    {
        public IDbConnection _connection;

        private readonly string connectionString = "Server=DESKTOP-LM2B2DI\\SQLEXPRESS01;Database=TaskManagement;Trusted_Connection=True;Encrypt=false";

        public GenericRepository()
        {
            _connection = new SqlConnection(connectionString);
        }

        public virtual async Task<T> InsertAsync(T entity)
        {
            string keyColumn = GetKeyColumnName();
            string tableName = GetTableName();
            string columns = GetColumns(excludeKey: true);
            string properties = GetPropertyNames(excludeKey: true);
            string query = $@"INSERT INTO {tableName} ({columns}) VALUES ({properties})
                              SELECT * FROM {tableName} WHERE {keyColumn} = SCOPE_IDENTITY()";
            return await _connection.QueryFirstOrDefaultAsync<T>(query, entity);

        }

        public virtual async Task<T> DeleteByIdAsync(int id)
        {
            string tableName = GetTableName();
            string keyColumn = GetKeyColumnName();
            var deletedData = await GetByIdAsync(id);
            string query = $@"DELETE FROM {tableName} WHERE {keyColumn} = @Id;";
        
            _connection.Execute(query, new { Id = id });
            return deletedData;
        }

        public virtual async Task<IEnumerable<T>> GetAllAsync()
        {
            string tableName = GetTableName();
            string query = $"SELECT * FROM {tableName}";
            return await _connection.QueryAsync<T>(query);
        }

        public virtual async Task<T> GetByIdAsync(int Id)
        {
            string tableName = GetTableName();
            string keyColumn = GetKeyColumnName();
            string query = $"SELECT * FROM {tableName} WHERE {keyColumn} = '{Id}'";
            return await _connection.QueryFirstOrDefaultAsync<T>(query);
        }

        public virtual async Task<T> UpdateAsync(T entity)
        {

            string tableName = GetTableName();
            string keyColumn = GetKeyColumnName();
            string keyProperty = GetKeyPropertyName();

            StringBuilder query = new StringBuilder();
            query.AppendLine($"UPDATE {tableName} SET ");

            var properties = GetProperties(true);
            for (int a = 0; a < properties.Count(); a++) {
                string propertyName = properties[a].Name;
                string comma = a < properties.Count() - 1 ? "," : "";
                query.AppendLine($"{propertyName} = @{propertyName} {comma} "); 
            }
            query.Remove(query.Length - 1, 1);

            query.AppendLine($"WHERE {keyColumn} = @{keyProperty} SELECT * FROM {tableName} WHERE {keyColumn} = @{keyProperty}");

            return await _connection.QueryFirstOrDefaultAsync<T>(query.ToString(), entity);
        }

        public virtual async Task<IEnumerable<T>> BulkInsertAsync(List<T> list)
        {
            List<T> result = new List<T>();
            foreach (T item in list)
            {
               T addedItem =  await InsertAsync(item);
               result.Add(addedItem);
            }
            return result;
        }

        public virtual async Task<IEnumerable<T>> BulkUpdateAsync(List<T> list)
        {
            List<T> result = new List<T>();
            foreach (T item in list)
            {
                T updatedItem = await UpdateAsync(item);
                result.Add(updatedItem);
            }
            return result;
        }

        public virtual async Task<IEnumerable<T>> BulkUpsertAsync(IEnumerable<T> entities)
        {
            List<T> result = new List<T>();
            foreach (var entity in entities)
            {
                string keyProperty = GetKeyPropertyName();
                var keyValue = typeof(T).GetProperty(keyProperty)?.GetValue(entity);

                // If key is default or null, insert new record, otherwise update existing
                if (keyValue == null || Convert.ToInt32(keyValue) == 0)
                {
                    T insertedItem = await InsertAsync(entity);
                    result.Add(insertedItem);
                }
                else
                {
                    T updatedItem = await UpdateAsync(entity);
                    result.Add(updatedItem);
                }
            }
            return result;
        }

        public virtual async Task<IEnumerable<T>> BulkMergeAsync(IEnumerable<T> entities  ,string? filterColumnName = null, object? filterValue = null)
        {
            string tableName = GetTableName();
            string keyColumn = GetKeyColumnName();
            string keyProperty = GetKeyPropertyName();

            var properties = GetProperties(excludeKey: true);

            var entitiesToInsert = new List<T>();
            var entitiesToUpdate = new List<T>();

            // ✅ Classify first
            foreach (var entity in entities)
            {
                var keyValue = typeof(T).GetProperty(keyProperty)?.GetValue(entity);

                if (keyValue == null || Convert.ToInt32(keyValue) == 0)
                {
                    entitiesToInsert.Add(entity);
                }
                else
                {
                    entitiesToUpdate.Add(entity);
                }
            }

            //Bulk Update
            await BulkUpdateAsync(entitiesToUpdate);


            var keepIds = entities
                            .Select(x => typeof(T).GetProperty(keyProperty)?.GetValue(x))
                            .Where(id => id != null && Convert.ToInt32(id) > 0)
                            .Cast<int>()
                            .ToList();

            //Bulk Delete
            await BulkDeleteAsync(entities, keepIds, filterColumnName, filterValue);

            //Bulk Insert
            await BulkInsertAsync(entitiesToUpdate);

            return entities;
        }

        public async Task<IEnumerable<T>> BulkDeleteAsync(IEnumerable<T> entities,List<int>? keepIds, string? filterColumnName = null, object? filterValue = null)
        {

            string tableName = GetTableName();
            string keyColumn = GetKeyColumnName();
            string keyProperty = GetKeyPropertyName();

            var deleteSql = new StringBuilder();
            deleteSql.AppendLine($"DELETE FROM {tableName}");
            deleteSql.AppendLine($"WHERE {keyColumn} NOT IN @Ids");
            
            if (!string.IsNullOrWhiteSpace(filterColumnName) && filterValue != null)
            {
                deleteSql.AppendLine($"AND {filterColumnName} = @FilterValue");
            }

            await _connection.ExecuteAsync(deleteSql.ToString(), new
            {
                Ids = keepIds,
                FilterValue = filterValue
            });
            
            return entities;
        }
        private string GetTableName()
        {
            string tableName = "";
            var type = typeof(T);
            var tableAttr = type.GetCustomAttribute<TableAttribute>();
            if (tableAttr != null)
            {
                tableName = tableAttr.Name;
                return tableName;
            }

            return type.Name;
        }

        public static string GetKeyColumnName()
        {
            PropertyInfo[] properties = typeof(T).GetProperties();

            foreach (PropertyInfo property in properties)
            {
                object[] keyAttributes = property.GetCustomAttributes(typeof(KeyAttribute), true);

                if (keyAttributes != null && keyAttributes.Length > 0)
                {
                    object[] columnAttributes = property.GetCustomAttributes(typeof(ColumnAttribute), true);

                    if (columnAttributes != null && columnAttributes.Length > 0)
                    {
                        ColumnAttribute columnAttribute = (ColumnAttribute)columnAttributes[0];
                        return columnAttribute.Name;
                    }
                    else
                    {
                        return property.Name;
                    }
                }
            }

            return null;
        }


        private string GetColumns(bool excludeKey = false)
        {
            var type = typeof(T);
            var columns = string.Join(", ", type.GetProperties()
                .Where(p => !excludeKey || !p.IsDefined(typeof(KeyAttribute)))
                .Select(p =>
                {
                    var columnAttr = p.GetCustomAttribute<ColumnAttribute>();
                    return columnAttr != null ? columnAttr.Name : p.Name;
                }));

            return columns;
        }

        protected string GetPropertyNames(bool excludeKey = false)
        {
            var properties = typeof(T).GetProperties()
                .Where(p => !excludeKey || p.GetCustomAttribute<KeyAttribute>() == null);

            var values = string.Join(", ", properties.Select(p =>
            {
                return $"@{p.Name}";
            }));

            return values;
        }

        protected List<PropertyInfo> GetProperties(bool excludeKey = false)
        {
            var properties = typeof(T).GetProperties()
                .Where(p => !excludeKey || p.GetCustomAttribute<KeyAttribute>() == null);

            return properties.ToList();
        }

        protected string GetKeyPropertyName()
        {
            var properties = typeof(T).GetProperties()
                .Where(p => p.GetCustomAttribute<KeyAttribute>() != null);

            if (properties.Any())
            {
                return properties.FirstOrDefault().Name;
            }

            return null;
        }
    }
}