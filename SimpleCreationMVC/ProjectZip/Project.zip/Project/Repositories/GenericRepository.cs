
using Dapper;
using Microsoft.Data.SqlClient;
using System.Data;
using Project.Utilities;

namespace Project.Repositories
{
    public class GenericProcedure<TProcedures>
    {
        public TProcedures? GetAll { get; set; } 
        public TProcedures? GetById { get; set; }
        public TProcedures? Insert { get; set; }
        public TProcedures? Update { get; set; }
        public TProcedures? DeleteById { get; set; }
        public TProcedures? InsertMany { get; set; }
        public TProcedures? UpdateMany { get; set; }
    }

     public class GenericRepository<T, TProcedures>
        where T : class
        where TProcedures : struct, Enum
    {
        public readonly IDbConnection _connection;
        private readonly GenericProcedure<TProcedures> _procedures;
        public readonly int _commandTimeout = 120;
        public readonly DataTableUtility _dataTableUtility = new DataTableUtility();

        public GenericRepository(GenericProcedure<TProcedures> procedures)
        {
            _procedures = procedures;
            _connection = new SqlConnection("Server=DESKTOP-MAIN\\SQLEXPRESS01; Database=StudentAttendanceManagementSystem; Trusted_Connection=True; Encrypt=false");
        }

        // Get All
        public async Task<IEnumerable<T>> GetAll()
        {
            return await _connection.QueryAsync<T>(_procedures.GetAll.ToString(), commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        // Get By ID
        public async Task<T?> GetById(int id)
        {
            return await _connection.QueryFirstOrDefaultAsync<T>(_procedures.GetById.ToString(), new { Id = id }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        // Insert
        public async Task<T?> Insert(T entity)
        {
            return await _connection.QueryFirstOrDefaultAsync<T>(_procedures.Insert.ToString(), entity, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        // Update
        public async Task<T?> Update(T entity)
        {
            return await _connection.QueryFirstOrDefaultAsync<T>(_procedures.Update.ToString(), entity, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        // Delete By ID
        public async Task<T?> DeleteById(int id)
        {
            return await _connection.QueryFirstOrDefaultAsync<T>(_procedures.DeleteById.ToString(), new { Id = id }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        // Insert Many
        public async Task<IEnumerable<T>> InsertMany( List<T> data)
        {
            var dt = _dataTableUtility.Convert<T>(data);
            var tableName = typeof(T).Name;
            return await _connection.QueryAsync<T>(_procedures.InsertMany.ToString(), new { TVP = dt.AsTableValuedParameter($"TVP_{tableName}") }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        // Update Many
        public async Task<IEnumerable<T>> UpdateMany( List<T> data)
        {
            var dt = _dataTableUtility.Convert<T>(data);
            var tableName = typeof(T).Name;
            return await _connection.QueryAsync<T>(_procedures.UpdateMany.ToString(), new { TVP = dt.AsTableValuedParameter($"TVP_{tableName}") }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }
    }
}