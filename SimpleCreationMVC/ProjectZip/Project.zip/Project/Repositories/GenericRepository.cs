
using Microsoft.EntityFrameworkCore;
using Project.ApplicationContexts;
using System.ComponentModel.DataAnnotations;
using EFCore.BulkExtensions;
using System.Reflection;

namespace Project.Repositories
{
    public class GenericRepository<T> where T : class
    {
        private readonly ApplicationContext _context = new ApplicationContext();

        public virtual async Task<T> InsertAsync(T entity)
        {
            await _context.Set<T>().AddAsync(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public virtual async Task<IEnumerable<T>> GetAllAsync()
        {
            return await _context.Set<T>().ToListAsync();
        }

        public virtual async Task<T?> GetByIdAsync(int id)
        {
            return await _context.Set<T>().FindAsync(id);
        }

        public virtual async Task<T> UpdateAsync(T entity)
        {
            var keyValue = GetKeyValueAsInt(entity);
            var retrievedEntity = await GetByIdAsync(keyValue.Value);
            var updateData = UpdateEntityProperties(retrievedEntity, entity);
            await _context.SaveChangesAsync();
            return updateData;
        }

        public virtual async Task<T> DeleteByIdAsync(int id)
        {
            T? deletedData = await GetByIdAsync(id);
            _context.Set<T>().Remove(deletedData);
            await _context.SaveChangesAsync();
            return deletedData;
        }

        public virtual async Task<IEnumerable<T>> BulkUpdateAsync(List<T> list)
        {
            await _context.BulkUpdateAsync(list);
            await _context.SaveChangesAsync();
            return list;
        }

        public virtual async Task<IEnumerable<T>> BulkInsertAsync(List<T> list)
        {
            await _context.BulkInsertAsync(list);
            await _context.SaveChangesAsync();
            return list;
        }

        public virtual async Task<IEnumerable<T>> BulkUpsertAsync(List<T> entities)
        {
            var (entitiesToInsert, entitiesToUpdate) = SeparateEntities(entities);

            // Bulk Insert
            if (entitiesToInsert.Any())
            {
                await _context.BulkInsertAsync(entitiesToInsert);
            }

            // Bulk Update
            if (entitiesToUpdate.Any())
            {
                await _context.BulkUpdateAsync(entitiesToUpdate);
            }

            await _context.SaveChangesAsync();

            return entities;
        }

        public virtual async Task<IEnumerable<T>> BulkMergeAsync(List<T> entities, Expression<Func<T, bool>>? deleteFilter = null)
        {
            var keyProperty = GetKeyProperty();

            var keepIds = entities
                            .Select(x => keyProperty.GetValue(x))
                            .Where(id => id != null && Convert.ToInt32(id) > 0)
                            .Cast<int>()
                            .ToList();

            IQueryable<T> query = _context.Set<T>();

            if (deleteFilter != null)
            {
                query = query.Where(deleteFilter);
            }

            if (keepIds.Any())
            {
                var entitiesToDelete = await query
                    .Where(x => !keepIds.Contains(EF.Property<int>(x, keyProperty.Name)))
                    .ToListAsync();

                if (entitiesToDelete.Any())
                {
                    await _context.BulkDeleteAsync(entitiesToDelete);
                }
            }

            await BulkUpsertAsync(entities);

            return entities;
        }

        private PropertyInfo GetKeyProperty()
        {
            var keyProperty = typeof(T).GetProperties()
                                .FirstOrDefault(p => p.GetCustomAttributes(typeof(KeyAttribute), true).Any());

            if (keyProperty == null)
                throw new InvalidOperationException($"No key property found for entity type {typeof(T).Name}");

            return keyProperty;
        }

        private (List<T> entitiesToInsert, List<T> entitiesToUpdate) SeparateEntities(List<T> entities)
        {
            var entitiesToInsert = new List<T>();
            var entitiesToUpdate = new List<T>();

            var keyProperty = GetKeyProperty();

            foreach (var entity in entities)
            {
                var keyValue = keyProperty.GetValue(entity);
                bool isDefaultKey = keyValue == null ||
                                   (keyValue is int intValue && intValue == 0) ||
                                   (keyValue is long longValue && longValue == 0);

                if (isDefaultKey)
                {
                    entitiesToInsert.Add(entity);
                }
                else
                {
                    entitiesToUpdate.Add(entity);
                }
            }
            return (entitiesToInsert, entitiesToUpdate);
        }

        private int? GetKeyValueAsInt(T entity)
        {
            var entityType = typeof(T);
            var keyProperty = GetKeyProperty();

            if (keyProperty == null)
            {
                throw new InvalidOperationException("No Key attribute found on properties.");
            }

            var keyValue = keyProperty.GetValue(entity);

            if (keyValue is int intValue)
            {
                return intValue;
            }

            throw new InvalidOperationException("Key value is not of type int.");
        }


        private T UpdateEntityProperties(T oldEntity, T newEntity)
        {
            var entityType = typeof(T);

            foreach (var property in entityType.GetProperties())
            {
                if (property.CanWrite && !Attribute.IsDefined(property, typeof(KeyAttribute)))
                {
                    var newValue = property.GetValue(newEntity);
                    property.SetValue(oldEntity, newValue);
                }
            }
            return newEntity;

        }

    }
}