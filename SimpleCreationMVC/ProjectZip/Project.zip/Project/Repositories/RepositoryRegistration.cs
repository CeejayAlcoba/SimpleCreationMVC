
//In Program.cs (Main project) add this 
//builder.Services.AddRepositories();

using Repositories.Interfaces;
using Repositories.Classes;

namespace Repositories
{
    public static class RepositoryRegistration
    {
        public static void AddRepositories(this IServiceCollection services)
        {
            services.AddScoped(typeof(IGenericRepository<,>), typeof(GenericRepository<,>));
            services.AddScoped<ItblRefReactIconFamilyRepository, tblRefReactIconFamilyRepository>();

        }
    }
}
