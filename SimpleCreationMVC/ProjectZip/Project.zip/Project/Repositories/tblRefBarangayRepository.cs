
using Project.Models;

namespace Project.Repositories
{
    public class tblRefBarangayRepository : GenericRepository<tblRefBarangay>
    {

    }
}
