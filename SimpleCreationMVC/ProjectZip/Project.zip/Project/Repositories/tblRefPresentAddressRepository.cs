
using Project.Models;

namespace Project.Repositories
{
    public class tblRefPresentAddressRepository : GenericRepository<tblRefPresentAddress>
    {

    }
}
