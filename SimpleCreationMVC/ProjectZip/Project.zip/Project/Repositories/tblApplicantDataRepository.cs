
using Project.Models;

namespace Project.Repositories
{
    public class tblApplicantDataRepository : GenericRepository<tblApplicantData>
    {

    }
}
