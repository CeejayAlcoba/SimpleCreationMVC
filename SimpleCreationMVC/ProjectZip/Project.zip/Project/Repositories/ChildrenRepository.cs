
using Project.Models;

namespace Project.Repositories
{
    public class ChildrenRepository : GenericRepository<Children>
    {

    }
}
