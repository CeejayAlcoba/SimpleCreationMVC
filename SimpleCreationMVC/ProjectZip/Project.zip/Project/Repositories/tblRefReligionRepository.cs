
using Project.Models;

namespace Project.Repositories
{
    public class tblRefReligionRepository : GenericRepository<tblRefReligion>
    {

    }
}
