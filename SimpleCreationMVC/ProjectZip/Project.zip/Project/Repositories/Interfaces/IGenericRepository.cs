
using System.Data;
using System.Threading.Tasks;

namespace Repositories.Interfaces
{
    public interface IGenericRepository<T, TProcedures>
        where T : class
        where TProcedures : struct, Enum
    {
        Task<IEnumerable<T>> GetAllAsync();
        Task<T?> GetByIdAsync(int id);
        Task<T?> InsertAsync(T entity);
        Task<T?> UpdateAsync(T entity);
        Task<T?> DeleteByIdAsync(int id);
        Task<IEnumerable<T>> BulkInsertAsync(List<T> data);
        Task<IEnumerable<T>> BulkUpdateAsync(List<T> data);
        Task<IEnumerable<T>> BulkUpsertAsync(List<T> data);
        Task<IEnumerable<T>> BulkMergeAsync(List<T> data);
    }
}
