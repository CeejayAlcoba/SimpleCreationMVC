
using Models;
using ProcedureEnums;

namespace Repositories.Interfaces
{
    public interface ItblRefReactIconRepository : IGenericRepository<tblRefReactIcon, tblRefReactIconProcedures>
    {
       
    }
}
