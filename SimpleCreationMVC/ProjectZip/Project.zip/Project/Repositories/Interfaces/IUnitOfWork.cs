using Repositories.Interfaces;

namespace Repositories.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IInitialDBRepository InitialDBs { get; }
        int Complete();
        Task<int> CompleteAsync();
    }
}