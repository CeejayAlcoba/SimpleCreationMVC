using Repositories.Interfaces;

namespace Repositories.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        ICoyRepository Coys { get; }
        int Complete();
        Task<int> CompleteAsync();
    }
}