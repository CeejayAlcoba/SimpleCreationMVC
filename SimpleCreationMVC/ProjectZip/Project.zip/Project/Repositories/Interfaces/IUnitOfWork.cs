using Repositories.Interfaces;

namespace Repositories.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        ITestTblRepository TestTbls { get; }
        int Complete();
        Task<int> CompleteAsync();
    }
}