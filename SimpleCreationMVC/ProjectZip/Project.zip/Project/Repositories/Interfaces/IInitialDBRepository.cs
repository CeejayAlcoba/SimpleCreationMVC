
using Models;

namespace Repositories.Interfaces
{
    public interface IInitialDBRepository : IGenericRepository<InitialDB>
    {
       
    }
}
