
using Models;
using ProcedureEnums;

namespace Repositories.Interfaces
{
    public interface ItblRefReactIconFamilyRepository : IGenericRepository<tblRefReactIconFamily, tblRefReactIconFamilyProcedures>
    {
       
    }
}
