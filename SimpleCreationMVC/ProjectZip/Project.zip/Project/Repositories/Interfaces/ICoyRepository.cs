
using Models;

namespace Repositories.Interfaces
{
    public interface ICoyRepository : IGenericRepository<Coy>
    {
       
    }
}
