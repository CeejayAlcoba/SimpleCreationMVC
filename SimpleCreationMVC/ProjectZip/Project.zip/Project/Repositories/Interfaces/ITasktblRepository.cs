
using Models;

namespace Repositories.Interfaces
{
    public interface ITasktblRepository : IGenericRepository<Tasktbl>
    {
       
    }
}
