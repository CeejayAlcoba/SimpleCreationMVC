
using Models;
using ProcedureEnums;

namespace Repositories.Interfaces
{
    public interface ITasktblRepository : IGenericRepository<Tasktbl, TasktblProcedures>
    {
       
    }
}
