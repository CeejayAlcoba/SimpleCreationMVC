
using Project.Models;

namespace Project.Repositories
{
    public class LeaveCreditsRepository : GenericRepository<LeaveCredits>
    {

    }
}
