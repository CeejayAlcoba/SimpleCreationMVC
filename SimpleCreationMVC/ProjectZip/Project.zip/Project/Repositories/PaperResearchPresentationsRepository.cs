
using Project.Models;

namespace Project.Repositories
{
    public class PaperResearchPresentationsRepository : GenericRepository<PaperResearchPresentations>
    {

    }
}
