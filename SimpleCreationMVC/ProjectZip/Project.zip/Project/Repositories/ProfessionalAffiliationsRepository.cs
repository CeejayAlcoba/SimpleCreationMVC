
using Project.Models;

namespace Project.Repositories
{
    public class ProfessionalAffiliationsRepository : GenericRepository<ProfessionalAffiliations>
    {

    }
}
