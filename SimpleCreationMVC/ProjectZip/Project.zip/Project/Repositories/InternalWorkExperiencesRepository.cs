
using Project.Models;

namespace Project.Repositories
{
    public class InternalWorkExperiencesRepository : GenericRepository<InternalWorkExperiences>
    {

    }
}
