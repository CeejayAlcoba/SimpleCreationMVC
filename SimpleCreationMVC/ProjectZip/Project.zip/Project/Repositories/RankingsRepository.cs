
using Project.Models;

namespace Project.Repositories
{
    public class RankingsRepository : GenericRepository<Rankings>
    {

    }
}
