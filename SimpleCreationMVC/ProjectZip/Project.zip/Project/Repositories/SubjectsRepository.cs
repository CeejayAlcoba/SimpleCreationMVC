
using Project.Models;
using Project.ProcedureEnums;

namespace Project.Repositories
{
    public class SubjectsRepository : GenericRepository<Subjects, SubjectsProcedures>
    {
        private static GenericProcedure<SubjectsProcedures> procedures = new GenericProcedure<SubjectsProcedures>
        {
            GetAll = SubjectsProcedures.Subjects_GetAll,
            GetById = SubjectsProcedures.Subjects_GetById,
            Insert = SubjectsProcedures.Subjects_Insert,
            Update = SubjectsProcedures.Subjects_Update,
            InsertMany = SubjectsProcedures.Subjects_InsertMany,
            UpdateMany = SubjectsProcedures.Subjects_UpdateMany,
        };
        public SubjectsRepository() : base(procedures)
        {
        }
    }
}