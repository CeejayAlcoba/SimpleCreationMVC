
using Dapper;
using Microsoft.Data.SqlClient;
using Project.Models;
using Project.ProcedureEnums;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Project.Repositories
{
    public class SubjectsRepository : GenericRepository<Subjects, SubjectsProcedures>
    {
        // New Get All
        public async Task<IEnumerable<Subjects>> GetAll()
        {
            return await GetAll(SubjectsProcedures.Subjects_GetAll);
        }

        // New Get By ID
        public async Task<Subjects?> GetById(int id)
        {
            return await GetById(SubjectsProcedures.Subjects_GetById, id);
        }

        // New Insert
        public async Task<Subjects?> Insert(Subjects entity)
        {
            return await Insert(SubjectsProcedures.Subjects_Insert, entity);
        }

        // New Update
        public async Task<Subjects?> Update(Subjects entity)
        {
            return await Update(SubjectsProcedures.Subjects_Update, entity);
        }

        // New Delete By ID
        public async Task<Subjects?> DeleteById(int id)
        {
             var data = await GetById(id);
             await DeleteById(SubjectsProcedures.Subjects_DeleteById, id);
             return data;
        }
    }
}