
using Project.Models;

namespace Project.Repositories
{
    public class CorporateDatasRepository : GenericRepository<CorporateDatas>
    {

    }
}
