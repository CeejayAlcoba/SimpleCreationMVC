
using Dapper;
using Microsoft.Data.SqlClient;
using Project.Models;
using Project.ProcedureEnums;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Project.Repositories
{
    public class tblEmployeeTimeInOutRepository : GenericRepository<tblEmployeeTimeInOut, tblEmployeeTimeInOutProcedures>
    {
        // New Get All
        public async Task<IEnumerable<tblEmployeeTimeInOut>> GetAll()
        {
            return await GetAll(tblEmployeeTimeInOutProcedures.tblEmployeeTimeInOut_GetAll);
        }

        // New Get By ID
        public async Task<tblEmployeeTimeInOut?> GetById(int id)
        {
            return await GetById(tblEmployeeTimeInOutProcedures.tblEmployeeTimeInOut_GetById, id);
        }

        // New Insert
        public async Task<tblEmployeeTimeInOut?> Insert(tblEmployeeTimeInOut entity)
        {
            return await Insert(tblEmployeeTimeInOutProcedures.tblEmployeeTimeInOut_Insert, entity);
        }

        // New Update
        public async Task<tblEmployeeTimeInOut?> Update(tblEmployeeTimeInOut entity)
        {
            return await Update(tblEmployeeTimeInOutProcedures.tblEmployeeTimeInOut_Update, entity);
        }

        // New Delete By ID
        public async Task<tblEmployeeTimeInOut?> DeleteById(int id)
        {
             var data = await GetById(id);
             await DeleteById(tblEmployeeTimeInOutProcedures.tblEmployeeTimeInOut_DeleteById, id);
             return data;
        }
    }
}