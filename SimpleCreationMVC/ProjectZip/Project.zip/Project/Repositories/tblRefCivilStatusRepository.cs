
using Project.Models;

namespace Project.Repositories
{
    public class tblRefCivilStatusRepository : GenericRepository<tblRefCivilStatus>
    {

    }
}
