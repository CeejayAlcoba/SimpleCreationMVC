
using Project.Models;

namespace Project.Repositories
{
    public class tblRefDepartmentRepository : GenericRepository<tblRefDepartment>
    {

    }
}
