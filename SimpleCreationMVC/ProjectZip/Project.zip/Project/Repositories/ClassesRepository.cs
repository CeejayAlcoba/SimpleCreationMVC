
using Project.Models;
using Project.ProcedureEnums;

namespace Project.Repositories
{
    public class ClassesRepository : GenericRepository<Classes, ClassesProcedures>
    {
        private static GenericProcedure<ClassesProcedures> procedures = new GenericProcedure<ClassesProcedures>
        {
            GetAll = ClassesProcedures.Classes_GetAll,
            GetById = ClassesProcedures.Classes_GetById,
            Insert = ClassesProcedures.Classes_Insert,
            Update = ClassesProcedures.Classes_Update,
            InsertMany = ClassesProcedures.Classes_InsertMany,
            UpdateMany = ClassesProcedures.Classes_UpdateMany,
        };
        public ClassesRepository() : base(procedures)
        {
        }
    }
}