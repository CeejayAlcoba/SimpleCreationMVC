
using Dapper;
using Microsoft.Data.SqlClient;
using Project.Models;
using Project.ProcedureEnums;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Project.Repositories
{
    public class ClassesRepository : GenericRepository<Classes, ClassesProcedures>
    {
        // New Get All
        public async Task<IEnumerable<Classes>> GetAll()
        {
            return await GetAll(ClassesProcedures.Classes_GetAll);
        }

        // New Get By ID
        public async Task<Classes?> GetById(int id)
        {
            return await GetById(ClassesProcedures.Classes_GetById, id);
        }

        // New Insert
        public async Task<Classes?> Insert(Classes entity)
        {
            return await Insert(ClassesProcedures.Classes_Insert, entity);
        }

        // New Update
        public async Task<Classes?> Update(Classes entity)
        {
            return await Update(ClassesProcedures.Classes_Update, entity);
        }

        // New Delete By ID
        public async Task<Classes?> DeleteById(int id)
        {
             var data = await GetById(id);
             await DeleteById(ClassesProcedures.Classes_DeleteById, id);
             return data;
        }
    }
}