
using Project.Models;

namespace Project.Repositories
{
    public class AdminCredentialsRepository : GenericRepository<AdminCredentials>
    {

    }
}
