
using Project.Models;
using Project.ProcedureEnums;

namespace Project.Repositories
{
    public class AdminCredentialsRepository : GenericRepository<AdminCredentials, AdminCredentialsProcedures>
    {
        private static GenericProcedure<AdminCredentialsProcedures> procedures = new GenericProcedure<AdminCredentialsProcedures>
        {
            GetAll = AdminCredentialsProcedures.AdminCredentials_GetAll,
            GetById = AdminCredentialsProcedures.AdminCredentials_GetById,
            Insert = AdminCredentialsProcedures.AdminCredentials_Insert,
            Update = AdminCredentialsProcedures.AdminCredentials_Update,
            InsertMany = AdminCredentialsProcedures.AdminCredentials_InsertMany,
            UpdateMany = AdminCredentialsProcedures.AdminCredentials_UpdateMany,
        };
        public AdminCredentialsRepository() : base(procedures)
        {
        }
    }
}