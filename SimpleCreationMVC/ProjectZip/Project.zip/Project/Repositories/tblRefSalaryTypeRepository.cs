
using Project.Models;

namespace Project.Repositories
{
    public class tblRefSalaryTypeRepository : GenericRepository<tblRefSalaryType>
    {

    }
}
