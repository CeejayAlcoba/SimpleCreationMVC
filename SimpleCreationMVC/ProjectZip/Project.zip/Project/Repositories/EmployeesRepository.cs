
using Project.Models;

namespace Project.Repositories
{
    public class EmployeesRepository : GenericRepository<Employees>
    {

    }
}
