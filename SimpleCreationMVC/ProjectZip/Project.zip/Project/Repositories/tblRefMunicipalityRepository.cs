
using Project.Models;

namespace Project.Repositories
{
    public class tblRefMunicipalityRepository : GenericRepository<tblRefMunicipality>
    {

    }
}
