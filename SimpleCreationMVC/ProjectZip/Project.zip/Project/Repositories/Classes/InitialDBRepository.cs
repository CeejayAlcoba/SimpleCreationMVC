
using Models;
using Repositories.Interfaces;
using ApplicationContexts;

namespace Repositories.Classes
{
    public class InitialDBRepository : GenericRepository<InitialDB>, IInitialDBRepository
    {
        public InitialDBRepository(ApplicationContext context):base(context)
        {
        }
    }
}
