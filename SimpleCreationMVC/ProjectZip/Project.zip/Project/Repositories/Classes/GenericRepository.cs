
using Dapper;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Reflection;
using System.ComponentModel.DataAnnotations;
using Utilities.Classes;
using Repositories.Interfaces;

namespace Repositories.Classes
{
    public class GenericProcedure<TProcedures>
    {
        public TProcedures? GetAllByFilters { get; set; } 
        public TProcedures? GetById { get; set; }
        public TProcedures? Insert { get; set; }
        public TProcedures? Update { get; set; }
        public TProcedures? DeleteById { get; set; }
        public TProcedures? BulkInsert { get; set; }
        public TProcedures? BulkUpdate { get; set; }
        public TProcedures? BulkDeleteNotInTVP { get; set; }
    }

    public class GenericRepository<T, TProcedures> : IGenericRepository<T, TProcedures>
        where T : class
        where TProcedures : struct, Enum
    {
        public readonly IDbConnection _connection;
        private readonly GenericProcedure<TProcedures> _procedures;
        public readonly int _commandTimeout = 120;
        private readonly DataTableUtility _dataTableUtility = new DataTableUtility();

        public GenericRepository(GenericProcedure<TProcedures> procedures)
        {
            _procedures = procedures;
            _connection = new SqlConnection("Server=DESKTOP-CEEJAY\\SQLEXPRESS; Database=ReactIcons; Trusted_Connection=True; Encrypt=FALSE; TrustServerCertificate=True; MultipleActiveResultSets=True;");
        }

        private string EnsureProcedureName(TProcedures? procedure)
        {
            if (procedure.ToString() == null || procedure?.ToString() == "0"){
                string name = typeof(T).Name;
                throw new InvalidOperationException($"Stored procedure for '{name}' is not defined.");
            }
            return procedure.ToString() ?? "";
        }

        public virtual async Task<IEnumerable<T>> GetAllAsync(T? filter = null)
        {
            var proc = EnsureProcedureName(_procedures.GetAllByFilters);
            return await _connection.QueryAsync<T>(proc, filter, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public virtual async Task<T?> GetByIdAsync(int id)
        {
            var proc = EnsureProcedureName(_procedures.GetById);
            return await _connection.QueryFirstOrDefaultAsync<T>(proc, new { Id = id }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public virtual async Task<T?> InsertAsync(T entity)
        {
            if (entity == null) throw new ArgumentNullException(nameof(entity));
            var proc = EnsureProcedureName(_procedures.Insert);
            return await _connection.QueryFirstOrDefaultAsync<T>(proc, entity, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public virtual async Task<T?> UpdateAsync(T entity)
        {
            if (entity == null) throw new ArgumentNullException(nameof(entity));
            var proc = EnsureProcedureName(_procedures.Update);
            return await _connection.QueryFirstOrDefaultAsync<T>(proc, entity, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public virtual async Task<T?> DeleteByIdAsync(int id)
        {
            var proc = EnsureProcedureName(_procedures.DeleteById);
            return await _connection.QueryFirstOrDefaultAsync<T>(proc, new { Id = id }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public virtual async Task<IEnumerable<T>> BulkInsertAsync(List<T>? data)
        {
            data ??= new List<T>();
            var proc = EnsureProcedureName(_procedures.BulkInsert);
            var dt = _dataTableUtility.Convert<T>(data);
            var tableName = typeof(T).Name;
            return await _connection.QueryAsync<T>(proc, new { TVP = dt.AsTableValuedParameter($"TVP_{tableName}") }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public virtual async Task<IEnumerable<T>> BulkUpdateAsync(List<T>? data)
        {
            data ??= new List<T>();
            var proc = EnsureProcedureName(_procedures.BulkUpdate);
            var dt = _dataTableUtility.Convert<T>(data);
            var tableName = typeof(T).Name;
            return await _connection.QueryAsync<T>(proc, new { TVP = dt.AsTableValuedParameter($"TVP_{tableName}") }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public virtual async Task<IEnumerable<T>> BulkUpsertAsync(List<T>? items)
        {
            items ??= new List<T>();
            var keyProperty = GetKeyProperty<T>();
        
            var insertList = items
                .Where(x => IsKeyDefaultValue(keyProperty.GetValue(x)))
                .ToList();
        
            var updateList = items
                .Where(x => !IsKeyDefaultValue(keyProperty.GetValue(x)))
                .ToList();
        
            var inserted = new List<T>();
            var updated = new List<T>();
        
            if (insertList.Any())
            {
                var newInserted = await BulkInsertAsync(insertList);
                inserted = newInserted.ToList();
            }
        
            if (updateList.Any())
            {
                var newUpdated = await BulkUpdateAsync(updateList);
                updated = newUpdated.ToList();
            }
        
            return updated.Concat(inserted);
        }

        public virtual async Task<IEnumerable<T>> BulkMergeAsync(List<T> data, object? filtersParams = null)
        {
            data ??= new List<T>();
            DynamicParameters deleteParameters = BuildParametersWithTVP(data, filtersParams);
            await BulkDeleteNotInTVPAsync(data,filtersParams);
            IEnumerable<T> result = await BulkUpsertAsync(data);
            var tableName = typeof(T).Name;
            return result;
        }

        private async Task<IEnumerable<T>> BulkDeleteNotInTVPAsync(List<T>? data, object? filtersParams = null)
        {
            data ??= new List<T>();
            var proc = EnsureProcedureName(_procedures.BulkDeleteNotInTVP);
            DynamicParameters parameters = BuildParametersWithTVP(data, filtersParams);
            var tableName = typeof(T).Name;
            return await _connection.QueryAsync<T>(proc, parameters, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        private bool IsKeyDefaultValue(object? value)
        {
            if (value == null)
                return true;

            var type = value.GetType();

            if (Nullable.GetUnderlyingType(type) != null)
                type = Nullable.GetUnderlyingType(type)!;

            var defaultValue = type.IsValueType ? Activator.CreateInstance(type) : null;

            return value.Equals(defaultValue);
        }
        private DynamicParameters BuildParametersWithTVP(List<T> data, object? additionalParams = null)
        {
            var dt = _dataTableUtility.Convert<T>(data);
            var tableName = typeof(T).Name;
        
            var parameters = new DynamicParameters();
            parameters.Add("TVP", dt.AsTableValuedParameter($"TVP_{tableName}"));
        
            if (additionalParams != null)
            {
                foreach (var prop in additionalParams.GetType().GetProperties())
                {
                    parameters.Add(prop.Name, prop.GetValue(additionalParams));
                }
            }
        
            return parameters;
        } 

        private static PropertyInfo GetKeyProperty<T>()
        {
            var keyProperty = typeof(T)
                .GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .FirstOrDefault(p => p.GetCustomAttribute<KeyAttribute>() != null);
        
            if (keyProperty == null)
                throw new InvalidOperationException(
                    $"Type '{typeof(T).Name}' does not contain a property marked with [Key]."
                );
        
            return keyProperty;
        }
    }
}