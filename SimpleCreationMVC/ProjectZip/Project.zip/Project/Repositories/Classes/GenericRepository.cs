
using Dapper;
using Microsoft.Data.SqlClient;
using System.Data;
using Utilities.Classes;
using Repositories.Interfaces;

namespace Repositories.Classes
{
    public class GenericProcedure<TProcedures>
    {
        public TProcedures? GetAllByFilters { get; set; } 
        public TProcedures? GetById { get; set; }
        public TProcedures? Insert { get; set; }
        public TProcedures? Update { get; set; }
        public TProcedures? DeleteById { get; set; }
        public TProcedures? BulkInsert { get; set; }
        public TProcedures? BulkUpdate { get; set; }
        public TProcedures? BulkUpsert { get; set; }
        public TProcedures? BulkMerge { get; set; }
    }

    public class GenericRepository<T, TProcedures> : IGenericRepository<T, TProcedures>
        where T : class
        where TProcedures : struct, Enum
    {
        public readonly IDbConnection _connection;
        private readonly GenericProcedure<TProcedures> _procedures;
        public readonly int _commandTimeout = 120;
        private readonly DataTableUtility _dataTableUtility = new DataTableUtility();

        public GenericRepository(GenericProcedure<TProcedures> procedures)
        {
            _procedures = procedures;
            _connection = new SqlConnection("Server=DESKTOP-CEEJAY\\SQLEXPRESS;Database=ReactIcons;Trusted_Connection=True; Encrypt=False;");
        }

        private string EnsureProcedureName(TProcedures? procedure)
        {
            if (procedure.ToString() == null || procedure?.ToString() == "0"){
                string name = typeof(T).Name;
                throw new InvalidOperationException($"Stored procedure for '{name}' is not defined.");
            }
            return procedure.ToString() ?? "";
        }

        public async Task<IEnumerable<T>> GetAllAsync(T? filter = null)
        {
            var proc = EnsureProcedureName(_procedures.GetAllByFilters);
            return await _connection.QueryAsync<T>(proc, filter, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public async Task<T?> GetByIdAsync(int id)
        {
            var proc = EnsureProcedureName(_procedures.GetById);
            return await _connection.QueryFirstOrDefaultAsync<T>(proc, new { Id = id }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public async Task<T?> InsertAsync(T entity)
        {
            if (entity == null) throw new ArgumentNullException(nameof(entity));
            var proc = EnsureProcedureName(_procedures.Insert);
            return await _connection.QueryFirstOrDefaultAsync<T>(proc, entity, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public async Task<T?> UpdateAsync(T entity)
        {
            if (entity == null) throw new ArgumentNullException(nameof(entity));
            var proc = EnsureProcedureName(_procedures.Update);
            return await _connection.QueryFirstOrDefaultAsync<T>(proc, entity, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public async Task<T?> DeleteByIdAsync(int id)
        {
            var proc = EnsureProcedureName(_procedures.DeleteById);
            return await _connection.QueryFirstOrDefaultAsync<T>(proc, new { Id = id }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public async Task<IEnumerable<T>> BulkInsertAsync(List<T> data)
        {
            if (data == null || data.Count == 0) throw new ArgumentException("Data list cannot be null or empty.", nameof(data));
            var proc = EnsureProcedureName(_procedures.BulkInsert);
            var dt = _dataTableUtility.Convert<T>(data);
            var tableName = typeof(T).Name;
            return await _connection.QueryAsync<T>(proc, new { TVP = dt.AsTableValuedParameter($"TVP_{tableName}") }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public async Task<IEnumerable<T>> BulkUpdateAsync(List<T> data)
        {
            if (data == null || data.Count == 0) throw new ArgumentException("Data list cannot be null or empty.", nameof(data));
            var proc = EnsureProcedureName(_procedures.BulkUpdate);
            var dt = _dataTableUtility.Convert<T>(data);
            var tableName = typeof(T).Name;
            return await _connection.QueryAsync<T>(proc, new { TVP = dt.AsTableValuedParameter($"TVP_{tableName}") }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public async Task<IEnumerable<T>> BulkUpsertAsync(List<T> data)
        {
            if (data == null || data.Count == 0) throw new ArgumentException("Data list cannot be null or empty.", nameof(data));
            var proc = EnsureProcedureName(_procedures.BulkUpsert);
            var dt = _dataTableUtility.Convert<T>(data);
            var tableName = typeof(T).Name;
            return await _connection.QueryAsync<T>(proc, new { TVP = dt.AsTableValuedParameter($"TVP_{tableName}") }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }

        public async Task<IEnumerable<T>> BulkMergeAsync(List<T> data)
        {
            if (data == null || data.Count == 0) throw new ArgumentException("Data list cannot be null or empty.", nameof(data));
            var proc = EnsureProcedureName(_procedures.BulkMerge);
            var dt = _dataTableUtility.Convert<T>(data);
            var tableName = typeof(T).Name;
            return await _connection.QueryAsync<T>(proc, new { TVP = dt.AsTableValuedParameter($"TVP_{tableName}") }, commandType: CommandType.StoredProcedure, commandTimeout: _commandTimeout);
        }
    }
}