using Microsoft.EntityFrameworkCore;
using ApplicationContexts;
using System.ComponentModel.DataAnnotations;
using EFCore.BulkExtensions;
using System.Reflection;
using System.Linq.Expressions;
using Utilities.Classes;
using Repositories.Interfaces;
using Models.Pagination;

namespace Repositories.Classes
{

    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        protected readonly ApplicationContext _context;

        public GenericRepository(ApplicationContext context)
        {
            _context = context;
        }

        public virtual async Task<T?> InsertAsync(T entity)
        {
            await _context.Set<T>().AddAsync(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public virtual async Task<PagedResult<T>> GetAllAsync(
         int pageNumber = 1,
         int pageSize = 10,
         T? filter = null,
         Expression<Func<T, object>>? orderByProperty = null,
         bool isDescending = false,
         params Expression<Func<T, object>>[] includes)
        {
            IQueryable<T> query = _context.Set<T>().AsNoTracking();

            // 1. [Filtering Block remains exactly the same as your original]
            if (filter != null)
            {
                var parameter = Expression.Parameter(typeof(T), "x");
                Expression? combined = null;
                foreach (var property in typeof(T).GetProperties())
                {
                    if (!property.CanRead) continue;
                    if (property.PropertyType.IsClass && property.PropertyType != typeof(string)) continue;
                    if (typeof(System.Collections.IEnumerable).IsAssignableFrom(property.PropertyType) && property.PropertyType != typeof(string)) continue;

                    var value = property.GetValue(filter);
                    if (value == null) continue;

                    var member = Expression.Property(parameter, property);
                    var constant = Expression.Constant(value, property.PropertyType);
                    var equalsCheck = Expression.Equal(member, constant);
                    combined = combined == null ? equalsCheck : Expression.AndAlso(combined, equalsCheck);
                }
                if (combined != null)
                {
                    query = query.Where(Expression.Lambda<Func<T, bool>>(combined, parameter));
                }
            }

            // 2. Apply Eager Loading (Includes)
            if (includes != null && includes.Length > 0)
            {
                foreach (var include in includes)
                {
                    query = query.Include(include);
                }
            }

            // 3. Type-Safe "keyof" Sorting Block
            if (orderByProperty != null)
            {
                query = isDescending
                    ? query.OrderByDescending(orderByProperty)
                    : query.OrderBy(orderByProperty);
            }

            // 4. Pagination and Execution
            int totalCount = await query.CountAsync();

            var items = await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            int totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

            return new PagedResult<T>
            {
                Items = items,
                CurrentPage = pageNumber,
                PageSize = pageSize,
                TotalCount = totalCount,
                TotalPages = totalPages
            };
        }


        public virtual async Task<T?> GetByIdAsync(int id)
        {
            return await _context.Set<T>().FindAsync(id);
        }

        public virtual async Task<T?> UpdateAsync(T entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return entity;
        }

        public virtual async Task<T?> DeleteByIdAsync(int id)
        {
            T? deletedData = await GetByIdAsync(id);
            if (deletedData != null)
            {
                _context.Set<T>().Remove(deletedData);
                await _context.SaveChangesAsync();
            }
            return deletedData;
        }

 
        public virtual async Task<IEnumerable<T>> BulkInsertAsync(List<T> list)
        {
            if (list == null || !list.Any()) return list ?? new List<T>();

            await _context.Set<T>().AddRangeAsync(list);
            await _context.SaveChangesAsync();
            return list;
        }

        public virtual async Task<IEnumerable<T>> BulkUpdateAsync(List<T> list)
        {
            if (list == null || !list.Any()) return list ?? new List<T>();

            _context.Set<T>().UpdateRange(list);
            await _context.SaveChangesAsync();
            return list;
        }

        public virtual async Task<IEnumerable<T>> BulkUpsertAsync(List<T> entities)
        {
            if (entities == null || !entities.Any()) return entities ?? new List<T>();

            string keyName = GetKeyPropertyName();

            var itemsToInsert = new List<T>();
            var itemsToUpdate = new List<T>();

            foreach (var entity in entities)
            {
                var propValue = entity.GetType().GetProperty(keyName)?.GetValue(entity);
                if (propValue == null || Convert.ToInt32(propValue) == 0)
                {
                    itemsToInsert.Add(entity);
                }
                else
                {
                    itemsToUpdate.Add(entity);
                }
            }

            if (itemsToInsert.Any())
            {
                await _context.Set<T>().AddRangeAsync(itemsToInsert);
            }

            if (itemsToUpdate.Any())
            {
                _context.Set<T>().UpdateRange(itemsToUpdate);
            }

            await _context.SaveChangesAsync();
            return entities;
        }

        public virtual async Task<IEnumerable<T>> BulkMergeAsync(List<T> entities, Expression<Func<T, bool>>? deleteFilter = null)
        {
            entities ??= new List<T>();
            string keyName = GetKeyPropertyName();

            var keepIds = entities
                .Select(x => x.GetType().GetProperty(keyName)?.GetValue(x))
                .Where(id => id != null && Convert.ToInt32(id) > 0)
                .Cast<int>()
                .ToList();

            IQueryable<T> query = _context.Set<T>();

            if (deleteFilter != null)
            {
                query = query.Where(deleteFilter);
            }

            var entitiesToDelete = await query
                .Where(x => !keepIds.Contains(EF.Property<int>(x, keyName)))
                .ToListAsync();

            if (entitiesToDelete.Any())
            {
                _context.Set<T>().RemoveRange(entitiesToDelete);
            }

            await BulkUpsertAsync(entities);

            return entities;
        }

        private string GetKeyPropertyName()
        {
            var entityType = _context.Model.FindEntityType(typeof(T));
            var primaryKey = entityType?.FindPrimaryKey();
            var keyProperty = primaryKey?.Properties.FirstOrDefault();

            if (keyProperty == null)
                throw new InvalidOperationException($"No Primary Key metadata mapped for entity type {typeof(T).Name}");

            return keyProperty.Name;
        }
    }
}