
using Models;
using Repositories.Interfaces;
using ApplicationContexts;

namespace Repositories.Classes
{
    public class CoyRepository : GenericRepository<Coy>, ICoyRepository
    {
        public CoyRepository(ApplicationContext context):base(context)
        {
        }
    }
}
