
using Models;
using ProcedureEnums;
using Repositories.Interfaces;

namespace Repositories.Classes
{
    public class tblRefReactIconRepository : GenericRepository<tblRefReactIcon, tblRefReactIconProcedures>, ItblRefReactIconRepository
    {
        private static GenericProcedure<tblRefReactIconProcedures> _procedures = new GenericProcedure<tblRefReactIconProcedures>
        {
            
        };
        public tblRefReactIconRepository() : base(_procedures)
        {
        }
    }
}