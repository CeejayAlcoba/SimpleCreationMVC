
using Models;
using ProcedureEnums;
using Repositories.Interfaces;

namespace Repositories.Classes
{
    public class tblRefReactIconFamilyRepository : GenericRepository<tblRefReactIconFamily, tblRefReactIconFamilyProcedures>, ItblRefReactIconFamilyRepository
    {
        private static GenericProcedure<tblRefReactIconFamilyProcedures> _procedures = new GenericProcedure<tblRefReactIconFamilyProcedures>
        {
            GetAllByFilters = tblRefReactIconFamilyProcedures.tblRefReactIconFamily_GetAllByFilters,
			GetById = tblRefReactIconFamilyProcedures.tblRefReactIconFamily_GetById,
			Insert = tblRefReactIconFamilyProcedures.tblRefReactIconFamily_Insert,
			Update = tblRefReactIconFamilyProcedures.tblRefReactIconFamily_Update,
			DeleteById = tblRefReactIconFamilyProcedures.tblRefReactIconFamily_DeleteById,
			BulkInsert = tblRefReactIconFamilyProcedures.tblRefReactIconFamily_BulkInsert,
			BulkUpdate = tblRefReactIconFamilyProcedures.tblRefReactIconFamily_BulkUpdate,
			BulkDeleteNotInTVP = tblRefReactIconFamilyProcedures.tblRefReactIconFamily_BulkDeleteNotInTVP
        };
        public tblRefReactIconFamilyRepository() : base(_procedures)
        {
        }
    }
}