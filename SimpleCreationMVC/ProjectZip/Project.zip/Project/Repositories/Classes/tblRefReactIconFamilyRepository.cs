
using Models;
using ProcedureEnums;
using Repositories.Interfaces;

namespace Repositories.Classes
{
    public class tblRefReactIconFamilyRepository : GenericRepository<tblRefReactIconFamily, tblRefReactIconFamilyProcedures>, ItblRefReactIconFamilyRepository
    {
        private static GenericProcedure<tblRefReactIconFamilyProcedures> _procedures = new GenericProcedure<tblRefReactIconFamilyProcedures>
        {
            
        };
        public tblRefReactIconFamilyRepository() : base(_procedures)
        {
        }
    }
}