
using Models;
using ProcedureEnums;
using Repositories.Interfaces;

namespace Repositories.Classes
{
    public class TasktblRepository : GenericRepository<Tasktbl, TasktblProcedures>, ITasktblRepository
    {
        private static GenericProcedure<TasktblProcedures> _procedures = new GenericProcedure<TasktblProcedures>
        {
            GetAll = TasktblProcedures.Tasktbl_GetAll,
			GetById = TasktblProcedures.Tasktbl_GetById,
			Insert = TasktblProcedures.Tasktbl_Insert,
			Update = TasktblProcedures.Tasktbl_Update,
			DeleteById = TasktblProcedures.Tasktbl_DeleteById,
			BulkInsert = TasktblProcedures.Tasktbl_BulkInsert,
			BulkUpdate = TasktblProcedures.Tasktbl_BulkUpdate,
			BulkUpsert = TasktblProcedures.Tasktbl_BulkUpsert,
			BulkMerge = TasktblProcedures.Tasktbl_BulkMerge
        };
        public TasktblRepository() : base(_procedures)
        {
        }
    }
}