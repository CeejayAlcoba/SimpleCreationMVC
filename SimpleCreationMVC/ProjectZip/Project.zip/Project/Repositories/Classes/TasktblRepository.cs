
using Models;
using Repositories.Interfaces;

namespace Repositories.Classes
{
    public class TasktblRepository : GenericRepository<Tasktbl>, ITasktblRepository
    {
    }
}
