using Microsoft.EntityFrameworkCore;
using ApplicationContexts;
using Repositories.Interfaces;
using Repositories.Classes;

namespace Repositories.Classes
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationContext _context;

        public UnitOfWork(ApplicationContext context)
        {
            _context = context;
            InitialDBs = new InitialDBRepository(_context);
        }

        public IInitialDBRepository InitialDBs { get; private set; }

        public int Complete()
        {
            return _context.SaveChanges();
        }

        public async Task<int> CompleteAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}