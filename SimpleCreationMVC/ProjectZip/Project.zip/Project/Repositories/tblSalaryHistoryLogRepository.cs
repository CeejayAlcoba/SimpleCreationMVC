
using Project.Models;

namespace Project.Repositories
{
    public class tblSalaryHistoryLogRepository : GenericRepository<tblSalaryHistoryLog>
    {

    }
}
