
using Project.Models;

namespace Project.Repositories
{
    public class tblRefGradeLevelRepository : GenericRepository<tblRefGradeLevel>
    {

    }
}
