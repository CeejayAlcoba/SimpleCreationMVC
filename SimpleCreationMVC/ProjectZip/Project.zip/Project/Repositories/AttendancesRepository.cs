
using Dapper;
using Microsoft.Data.SqlClient;
using Project.Models;
using Project.ProcedureEnums;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Project.Repositories
{
    public class AttendancesRepository : GenericRepository<Attendances, AttendancesProcedures>
    {
        // New Get All
        public async Task<IEnumerable<Attendances>> GetAll()
        {
            return await GetAll(AttendancesProcedures.Attendances_GetAll);
        }

        // New Get By ID
        public async Task<Attendances?> GetById(int id)
        {
            return await GetById(AttendancesProcedures.Attendances_GetById, id);
        }

        // New Insert
        public async Task<Attendances?> Insert(Attendances entity)
        {
            return await Insert(AttendancesProcedures.Attendances_Insert, entity);
        }

        // New Update
        public async Task<Attendances?> Update(Attendances entity)
        {
            return await Update(AttendancesProcedures.Attendances_Update, entity);
        }

        // New Delete By ID
        public async Task<Attendances?> DeleteById(int id)
        {
             var data = await GetById(id);
             await DeleteById(AttendancesProcedures.Attendances_DeleteById, id);
             return data;
        }
    }
}