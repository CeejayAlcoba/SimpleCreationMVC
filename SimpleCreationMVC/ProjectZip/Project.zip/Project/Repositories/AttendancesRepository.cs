
using Project.Models;
using Project.ProcedureEnums;

namespace Project.Repositories
{
    public class AttendancesRepository : GenericRepository<Attendances, AttendancesProcedures>
    {
        private static GenericProcedure<AttendancesProcedures> procedures = new GenericProcedure<AttendancesProcedures>
        {
            GetAll = AttendancesProcedures.Attendances_GetAll,
            GetById = AttendancesProcedures.Attendances_GetById,
            Insert = AttendancesProcedures.Attendances_Insert,
            Update = AttendancesProcedures.Attendances_Update,
            InsertMany = AttendancesProcedures.Attendances_InsertMany,
            UpdateMany = AttendancesProcedures.Attendances_UpdateMany,
        };
        public AttendancesRepository() : base(procedures)
        {
        }
    }
}