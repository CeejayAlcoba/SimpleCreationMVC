
using Project.Models;

namespace Project.Repositories
{
    public class tblEmployeeDataRepository : GenericRepository<tblEmployeeData>
    {

    }
}
