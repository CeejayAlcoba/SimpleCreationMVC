
using Project.Models;

namespace Project.Repositories
{
    public class tblRefCountryRepository : GenericRepository<tblRefCountry>
    {

    }
}
