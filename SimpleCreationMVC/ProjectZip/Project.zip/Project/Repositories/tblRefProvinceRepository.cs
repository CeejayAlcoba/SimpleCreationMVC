
using Project.Models;

namespace Project.Repositories
{
    public class tblRefProvinceRepository : GenericRepository<tblRefProvince>
    {

    }
}
