
using Project.Models;

namespace Project.Repositories
{
    public class ExternalWorkExperiencesRepository : GenericRepository<ExternalWorkExperiences>
    {

    }
}
