
using Project.Models;

namespace Project.Repositories
{
    public class tblRefEmploymentCategoryTypeRepository : GenericRepository<tblRefEmploymentCategoryType>
    {

    }
}
