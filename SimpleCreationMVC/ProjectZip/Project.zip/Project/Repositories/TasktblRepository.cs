
using Project.Models;

namespace Project.Repositories
{
    public class TasktblRepository : GenericRepository<Tasktbl>
    {

    }
}
