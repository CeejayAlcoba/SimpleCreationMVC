namespace Project.Enums
{
    public enum StoredProcedures
     {

		//---ManPowerReport---//
		ManPowerReport_GetAllEmployeeEntries,
		ManPowerReport_GetAllEmployeePromotionsAndTransfers,
		ManPowerReport_GetAllEmployeeSalaryAdjustment,

		//---Person---//
		Person_GetAll,

		//---tblApplicantData---//
		tblApplicantData_DeleteById,
		tblApplicantData_GetAll,
		tblApplicantData_GetById,
		tblApplicantData_Insert,
		tblApplicantData_Update,

		//---tblEducationalData---//
		tblEducationalData_DeleteById,
		tblEducationalData_GetAll,
		tblEducationalData_GetByApplicantId,
		tblEducationalData_GetByEmployeeId,
		tblEducationalData_GetById,
		tblEducationalData_Insert,
		tblEducationalData_Update,

		//---tblEmployeeCategory---//
		tblEmployeeCategory_DeleteById,
		tblEmployeeCategory_GetAll,
		tblEmployeeCategory_GetById,
		tblEmployeeCategory_Insert,
		tblEmployeeCategory_Update,

		//---tblEmployeeCurrentPosition---//
		tblEmployeeCurrentPosition_DeleteById,
		tblEmployeeCurrentPosition_GetAll,
		tblEmployeeCurrentPosition_GetByEmployeeId,
		tblEmployeeCurrentPosition_GetById,
		tblEmployeeCurrentPosition_Insert,
		tblEmployeeCurrentPosition_Update,

		//---tblEmployeeData---//
		tblEmployeeData_DeleteById,
		tblEmployeeData_GetAll,
		tblEmployeeData_GetById,
		tblEmployeeData_Insert,
		tblEmployeeData_Update,

		//---tblExternalWorkExperience---//
		tblExternalWorkExperience_DeleteById,
		tblExternalWorkExperience_GetAll,
		tblExternalWorkExperience_GetByApplicantId,
		tblExternalWorkExperience_GetByEmployeeId,
		tblExternalWorkExperience_GetById,
		tblExternalWorkExperience_Insert,
		tblExternalWorkExperience_Update,

		//---tblFamilyData---//
		tblFamilyData_DeleteById,
		tblFamilyData_GetAll,
		tblFamilyData_GetByApplicantId,
		tblFamilyData_GetByEmployeeId,
		tblFamilyData_GetById,
		tblFamilyData_Insert,
		tblFamilyData_Update,

		//---tblInternalWorkExperience---//
		tblInternalWorkExperience_DeleteById,
		tblInternalWorkExperience_GetAll,
		tblInternalWorkExperience_GetByApplicantId,
		tblInternalWorkExperience_GetByEmployeeId,
		tblInternalWorkExperience_GetById,
		tblInternalWorkExperience_Insert,
		tblInternalWorkExperience_Update,

		//---tblPayrollAccountNumber---//
		tblPayrollAccountNumber_DeleteById,
		tblPayrollAccountNumber_GetAll,
		tblPayrollAccountNumber_GetById,
		tblPayrollAccountNumber_Insert,
		tblPayrollAccountNumber_Update,

		//---tblPromotionHistoryLog---//
		tblPromotionHistoryLog_DeleteById,
		tblPromotionHistoryLog_GetAll,
		tblPromotionHistoryLog_GetById,
		tblPromotionHistoryLog_Insert,
		tblPromotionHistoryLog_Update,

		//---tblRefAppointment---//
		tblRefAppointment_DeleteById,
		tblRefAppointment_GetAll,
		tblRefAppointment_GetById,
		tblRefAppointment_Insert,
		tblRefAppointment_Update,

		//---tblRefBarangay---//
		tblRefBarangay_DeleteById,
		tblRefBarangay_GetAll,
		tblRefBarangay_GetById,
		tblRefBarangay_Insert,
		tblRefBarangay_Update,

		//---tblRefChildren---//
		tblRefChildren_DeleteById,
		tblRefChildren_GetAll,
		tblRefChildren_GetByFamilyId,
		tblRefChildren_GetById,
		tblRefChildren_Insert,
		tblRefChildren_Update,

		//---tblRefCivilStatus---//
		tblRefCivilStatus_DeleteById,
		tblRefCivilStatus_GetAll,
		tblRefCivilStatus_GetById,
		tblRefCivilStatus_Insert,
		tblRefCivilStatus_Update,

		//---tblRefCountry---//
		tblRefCountry_DeleteById,
		tblRefCountry_GetAll,
		tblRefCountry_GetById,
		tblRefCountry_Insert,
		tblRefCountry_Update,

		//---tblRefDepartment---//
		tblRefDepartment_DeleteById,
		tblRefDepartment_GetAll,
		tblRefDepartment_GetById,
		tblRefDepartment_Insert,
		tblRefDepartment_Update,

		//---tblRefEducationalLevel---//
		tblRefEducationalLevel_DeleteById,
		tblRefEducationalLevel_GetAll,
		tblRefEducationalLevel_GetById,
		tblRefEducationalLevel_Insert,
		tblRefEducationalLevel_Update,

		//---tblRefEmploymentCategoryType---//
		tblRefEmploymentCategoryType_DeleteById,
		tblRefEmploymentCategoryType_GetAll,
		tblRefEmploymentCategoryType_GetById,
		tblRefEmploymentCategoryType_Insert,
		tblRefEmploymentCategoryType_Update,

		//---tblRefGender---//
		tblRefGender_DeleteById,
		tblRefGender_GetAll,
		tblRefGender_GetById,
		tblRefGender_Insert,
		tblRefGender_Update,

		//---tblRefGradeLevel---//
		tblRefGradeLevel_DeleteById,
		tblRefGradeLevel_GetAll,
		tblRefGradeLevel_GetById,
		tblRefGradeLevel_Insert,
		tblRefGradeLevel_Update,

		//---tblRefInternalCompany---//
		tblRefInternalCompany_DeleteById,
		tblRefInternalCompany_GetAll,
		tblRefInternalCompany_GetById,
		tblRefInternalCompany_Insert,
		tblRefInternalCompany_Update,

		//---tblRefJobLevel---//
		tblRefJobLevel_DeleteById,
		tblRefJobLevel_GetAll,
		tblRefJobLevel_GetById,
		tblRefJobLevel_Insert,
		tblRefJobLevel_Update,

		//---tblRefMunicipality---//
		tblRefMunicipality_DeleteById,
		tblRefMunicipality_GetAll,
		tblRefMunicipality_GetById,
		tblRefMunicipality_Insert,
		tblRefMunicipality_Update,

		//---tblRefPermanentAddress---//
		tblRefPermanentAddress_DeleteById,
		tblRefPermanentAddress_GetAll,
		tblRefPermanentAddress_GetByEmployeeId,
		tblRefPermanentAddress_GetById,
		tblRefPermanentAddress_Insert,
		tblRefPermanentAddress_Update,

		//---tblRefPosition---//
		tblRefPosition_DeleteById,
		tblRefPosition_GetAll,
		tblRefPosition_GetById,
		tblRefPosition_Insert,
		tblRefPosition_Update,

		//---tblRefPresentAddress---//
		tblRefPresentAddress_DeleteById,
		tblRefPresentAddress_GetAll,
		tblRefPresentAddress_GetByEmployeeId,
		tblRefPresentAddress_GetById,
		tblRefPresentAddress_Insert,
		tblRefPresentAddress_Update,

		//---tblRefProvince---//
		tblRefProvince_DeleteById,
		tblRefProvince_GetAll,
		tblRefProvince_GetById,
		tblRefProvince_Insert,
		tblRefProvince_Update,

		//---tblRefReligion---//
		tblRefReligion_DeleteById,
		tblRefReligion_GetAll,
		tblRefReligion_GetById,
		tblRefReligion_Insert,
		tblRefReligion_Update,

		//---tblRefSalaryType---//
		tblRefSalaryType_DeleteById,
		tblRefSalaryType_GetAll,
		tblRefSalaryType_GetById,
		tblRefSalaryType_Insert,
		tblRefSalaryType_Update,

		//---tblRefZIPCode---//
		tblRefZIPCode_DeleteById,
		tblRefZIPCode_GetAll,
		tblRefZIPCode_GetById,
		tblRefZIPCode_Insert,
		tblRefZIPCode_Update,

		//---tblSalary---//
		tblSalary_DeleteById,
		tblSalary_GetAll,
		tblSalary_GetByEmployeeId,
		tblSalary_GetById,
		tblSalary_Insert,
		tblSalary_Update,

		//---tblSalaryHistoryLog---//
		tblSalaryHistoryLog_DeleteById,
		tblSalaryHistoryLog_GetAll,
		tblSalaryHistoryLog_GetById,
		tblSalaryHistoryLog_Insert,
		tblSalaryHistoryLog_Update,

     }
}
