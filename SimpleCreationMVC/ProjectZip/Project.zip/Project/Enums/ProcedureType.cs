
namespace Project.Enums
{
    public enum ProcedureTypes
    {
        Insert,
        Update, 
        DeleteById,
        GetAll,
        GetById,
    }
}
