
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Models;

namespace ApplicationContexts
{
    public class ApplicationContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = "Server=DESKTOP-LM2B2DI\\SQLEXPRESS01;Database=TaskManagement;Trusted_Connection=True;Encrypt=false";
            optionsBuilder.UseSqlServer(connectionString);
            optionsBuilder.EnableSensitiveDataLogging();
            base.OnConfiguring(optionsBuilder);
        }

		public DbSet<Tasktbl> Tasktbl { get; set; }

    }
}
