
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Project.Models;

namespace Project.ApplicationContexts
{
    public class ApplicationContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = "Server=DESKTOP-MAIN\\SQLEXPRESS01; Database=StudentAttendanceManagementSystem; Trusted_Connection=True; Encrypt=false";
            optionsBuilder.UseSqlServer(connectionString);
            optionsBuilder.EnableSensitiveDataLogging();
            base.OnConfiguring(optionsBuilder);
        }
		public DbSet<AdminCredentials> AdminCredentials { get; set; }
		public DbSet<Attendances> Attendances { get; set; }
		public DbSet<Classes> Classes { get; set; }
		public DbSet<Students> Students { get; set; }
		public DbSet<Subjects> Subjects { get; set; }

    }
}
