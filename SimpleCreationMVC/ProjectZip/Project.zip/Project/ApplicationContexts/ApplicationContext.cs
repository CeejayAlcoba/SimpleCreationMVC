
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Project.Models;

namespace Project.ApplicationContexts
{
    public class ApplicationContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = "Server=DESKTOP-9PGJDKR\\SQLEXPRESS; Database=TestDatabase; Trusted_Connection=True; Encrypt=False; ";
            optionsBuilder.UseSqlServer(connectionString);
            optionsBuilder.EnableSensitiveDataLogging();
            base.OnConfiguring(optionsBuilder);
        }
		public DbSet<tblRefRole> tblRefRole { get; set; }
		public DbSet<tblRefRole2> tblRefRole2 { get; set; }
		public DbSet<tblSideBarDivision> tblSideBarDivision { get; set; }
		public DbSet<tblSideBarMenu> tblSideBarMenu { get; set; }
		public DbSet<tblSideBarMenuItem> tblSideBarMenuItem { get; set; }
		public DbSet<tblSideBarMenuItemRoleMapping> tblSideBarMenuItemRoleMapping { get; set; }
		public DbSet<tblUser> tblUser { get; set; }
		public DbSet<tblUserRoleMapping> tblUserRoleMapping { get; set; }
		public DbSet<TestCheckEnum> TestCheckEnum { get; set; }

    }
}
