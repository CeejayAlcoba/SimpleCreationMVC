
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Project.Models;

namespace Project.ApplicationContexts
{
    public class ApplicationContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = "Server=DESKTOP-LM2B2DI\\SQLEXPRESS;Database=Test;Trusted_Connection=True;Encrypt=false";
            optionsBuilder.UseSqlServer(connectionString);
            optionsBuilder.EnableSensitiveDataLogging();
            base.OnConfiguring(optionsBuilder);
        }
		public DbSet<tblGender> tblGender { get; set; }

    }
}
