NuGet Packages Required

The project should download the following NuGet packages:

PM> Install-Package Dapper
PM> Install-Package Microsoft.Data.SqlClient

For Auto Mapper Utility
PM> Install-Package AutoMapper

For App Utility
PM> Install-Package Microsoft.Extensions.Configuration
PM> Install-Package Microsoft.Extensions.Configuration.Json
PM> Install-Package Microsoft.Extensions.Configuration.Binder




Sample GetConnectionString using App Utility
ICOnfigurationRoot _config = new AppUlitity().configuration;
_config.GetConnectionString("DefaultConnection");

Sample get item in appsetting.json
ICOnfigurationRoot _config = new AppUlitity().configuration;
_config["JWT:Secret"];
