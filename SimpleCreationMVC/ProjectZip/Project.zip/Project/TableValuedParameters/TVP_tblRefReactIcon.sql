
CREATE TYPE TVP_tblRefReactIcon AS TABLE
(
	Id int,
	ReactIconFamilyId int,
	Description nvarchar(MAX),
	IsDeleted bit

)
GO
