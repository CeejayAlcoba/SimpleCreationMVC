
CREATE TYPE TVP_Subjects AS TABLE
(
	Id int,
	SubjectName nvarchar(MAX),
	CreatedAt datetime2,
	IsDeleted bit

)
GO
