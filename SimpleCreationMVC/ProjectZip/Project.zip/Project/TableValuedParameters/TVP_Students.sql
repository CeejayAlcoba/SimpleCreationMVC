
CREATE TYPE TVP_Students AS TABLE
(
	Id int,
	FirstName nvarchar(MAX),
	LastName nvarchar(MAX),
	Gender nvarchar(MAX),
	SubjectId int,
	CreatedAt datetime2,
	IsDeleted bit,
	MiddleName nvarchar(MAX)

)
GO
