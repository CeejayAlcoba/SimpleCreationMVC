
CREATE TYPE TVP_Tasktbl AS TABLE
(
	Id int,
	Description nvarchar(MAX),
	Title nvarchar(MAX)

)
GO
