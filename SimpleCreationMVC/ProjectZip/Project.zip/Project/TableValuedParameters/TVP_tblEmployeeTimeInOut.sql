
CREATE TYPE TVP_tblEmployeeTimeInOut AS TABLE
(
	Id int,
	EmployeeId int,
	Date datetime,
	CheckIn time,
	CheckOut time,
	EmployeeNumber nvarchar(MAX),
	DepartmentId int,
	Department nvarchar(MAX),
	UploadedBy int,
	UploadedDate datetime,
	Note nvarchar(MAX)

)
GO
