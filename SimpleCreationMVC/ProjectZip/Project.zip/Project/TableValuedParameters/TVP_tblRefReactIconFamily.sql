
CREATE TYPE TVP_tblRefReactIconFamily AS TABLE
(
	Id int,
	Description nvarchar(10),
	IsDeleted bit

)
GO
