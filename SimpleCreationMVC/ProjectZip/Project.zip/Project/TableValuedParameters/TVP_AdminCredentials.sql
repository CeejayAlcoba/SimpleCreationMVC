
CREATE TYPE TVP_AdminCredentials AS TABLE
(
	Id int,
	UserName nvarchar(MAX),
	Password nvarchar(MAX)

)
GO
