
CREATE TYPE TVP_Attendances AS TABLE
(
	Id int,
	StudentId int,
	ClassId int,
	AttendanceDate datetime2,
	CreatedAt datetime2,
	IsDeleted bit

)
GO
