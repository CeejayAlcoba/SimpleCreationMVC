
CREATE TYPE TVP_Classes AS TABLE
(
	Id int,
	SubjectId int,
	ClassDate datetime2,
	StartTime time,
	EndTime time,
	CreatedAt datetime2,
	IsDeleted bit

)
GO
