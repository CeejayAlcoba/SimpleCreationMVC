
CREATE TYPE TVP_tblRefRole AS TABLE
(
	Id int,
	Description nvarchar(MAX)

)
GO
